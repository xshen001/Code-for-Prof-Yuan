Dear Professor Yuan,

Thank you again for helping with the independent computational evaluation.

This is the corrected evaluator-seeded causal-inference transfer audit package.
Please use this package instead of the earlier
`causal_interval_transfer_for_professor_yuan_20260702_fixed` package. It tests
whether source-family information can improve interval calibration, not just
procedure ranking. The package is designed to require no manual parameter
choices. The standard command generates its master, public-validation, and
hidden-test seeds locally on your machine using operating-system entropy; the
authors do not know these seeds before you send back the return file.

Suggested steps:

1. Unzip the package.
2. Please ask your Codex/Cursor agent to read `plan.md` in the package root.
3. Optional: double-click `SETUP_CAUSAL_INTERVAL_ENV.command` if your current
   Python environment does not already have numpy, pandas, scipy, scikit-learn,
   and matplotlib.
4. Double-click `RUN_CAUSAL_INTERVAL_TRANSFER_STANDARD.command`.
5. Please send back the generated file named like
   `causal_interval_transfer_*_return_to_authors.zip`.
   The script prints the zip size and SHA-256 checksum and also copies the zip
   to your Desktop when possible. Please send back a nonzero-size zip. If
   Dropbox or another cloud folder shows the file as 0 bytes, please wait for it
   to finish syncing or send the Desktop copy instead.

The returned zip includes `evaluator_seed_manifest.json` inside the result
folder so that the generated seeds are auditable after the run.

As a quick sanity check, the standard run should print
`Seed source: evaluator-machine OS entropy`, and the returned result directory
should include `evaluator_seed_manifest.json`.

If setup or the standard run fails, please send back the Terminal output or
screenshot instead. No debugging is requested.

Best,
Xiaotong

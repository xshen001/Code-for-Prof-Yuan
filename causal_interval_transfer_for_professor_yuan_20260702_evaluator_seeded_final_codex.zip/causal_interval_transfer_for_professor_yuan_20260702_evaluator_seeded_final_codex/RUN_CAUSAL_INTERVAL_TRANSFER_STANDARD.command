#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
bash RUN_CAUSAL_INTERVAL_TRANSFER_STANDARD.sh

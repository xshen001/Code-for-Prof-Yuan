#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ -x ".venv_causal_interval/bin/python" ]; then
  PYTHON_BIN=".venv_causal_interval/bin/python"
else
  PYTHON_BIN="${PYTHON_BIN:-python3}"
fi

STAMP="$(date -u +%Y%m%d_%H%M%S_utc)"
OUT_DIR="causal_interval_transfer_standard_${STAMP}"
RETURN_ZIP="causal_interval_transfer_standard_${STAMP}_return_to_authors.zip"
READY_NOTE="RETURN_PACKAGE_READY_${STAMP}.txt"

mkdir -p "$OUT_DIR"

SEED_LINES="$("${PYTHON_BIN}" - "$OUT_DIR/evaluator_seed_manifest.json" <<'PY'
import datetime as _dt
import json
import platform
import secrets
import sys

out = sys.argv[1]
rng = secrets.SystemRandom()
master_seeds = [rng.randrange(100_000_000, 2_147_483_647) for _ in range(5)]
public_seed_base = rng.randrange(100_000_000, 2_147_483_647)
hidden_seed_base = rng.randrange(100_000_000, 2_147_483_647)
manifest = {
    "seed_source": "evaluator-machine OS entropy via Python secrets.SystemRandom",
    "created_utc": _dt.datetime.now(_dt.UTC).isoformat(timespec="seconds"),
    "master_seeds": master_seeds,
    "public_seed_base": public_seed_base,
    "hidden_seed_base": hidden_seed_base,
    "python": platform.python_version(),
    "platform": platform.platform(),
}
with open(out, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)
print("MASTER_SEEDS=" + ",".join(str(x) for x in master_seeds))
print("PUBLIC_SEED_BASE=" + str(public_seed_base))
print("HIDDEN_SEED_BASE=" + str(hidden_seed_base))
PY
)"
eval "$SEED_LINES"

{
  echo "Starting causal interval-transfer STANDARD evaluation."
  echo "UTC timestamp: ${STAMP}"
  echo "Python: $(${PYTHON_BIN} -c 'import sys; print(sys.executable)')"
  echo "Working directory: $(pwd)"
  echo "Seed source: evaluator-machine OS entropy; see $OUT_DIR/evaluator_seed_manifest.json"
  echo "Master seeds: ${MASTER_SEEDS}"
  echo
  "${PYTHON_BIN}" causal_inference_agent_experiment/run_causal_interval_transfer_experiment.py \
    --out "$OUT_DIR" \
    --master-seeds "$MASTER_SEEDS" \
    --public-seed-base "$PUBLIC_SEED_BASE" \
    --hidden-seed-base "$HIDDEN_SEED_BASE" \
    --public-target-reps 6 \
    --public-source-reps 8 \
    --hidden-reps 36 \
    --n-public 450 \
    --n-hidden 700
} 2>&1 | tee "$OUT_DIR/run_stdout_stderr.txt"

if [ ! -s "$OUT_DIR/summary.csv" ] || [ ! -s "$OUT_DIR/contrasts.csv" ] || [ ! -s "$OUT_DIR/manifest.json" ]; then
  echo "ERROR: expected result files were not created. Please send back $OUT_DIR/run_stdout_stderr.txt."
  exit 2
fi

rm -f "$RETURN_ZIP"
zip -qr "$RETURN_ZIP" "$OUT_DIR" README_START_HERE.txt requirements_causal_interval_transfer.txt causal_inference_agent_experiment

if [ ! -s "$RETURN_ZIP" ]; then
  echo "ERROR: return zip was created but is empty. Please send back $OUT_DIR/run_stdout_stderr.txt."
  exit 2
fi

if ! unzip -tq "$RETURN_ZIP" >/dev/null; then
  echo "ERROR: return zip failed integrity test. Please send back $OUT_DIR/run_stdout_stderr.txt."
  exit 2
fi

ZIP_BYTES="$(wc -c < "$RETURN_ZIP" | tr -d ' ')"
ZIP_SHA="$(shasum -a 256 "$RETURN_ZIP" | awk '{print $1}')"
{
  echo "Causal interval-transfer STANDARD run completed."
  echo "UTC timestamp: ${STAMP}"
  echo "Return zip: $(pwd)/${RETURN_ZIP}"
  echo "Return zip bytes: ${ZIP_BYTES}"
  echo "Return zip SHA256: ${ZIP_SHA}"
  echo
  echo "Please send back the nonzero-size return zip above."
  echo "If Dropbox or another cloud service shows this file as 0 bytes, wait until it finishes syncing or send the Desktop copy."
} | tee "$READY_NOTE"

if [ -d "$HOME/Desktop" ] && [ -w "$HOME/Desktop" ]; then
  cp "$RETURN_ZIP" "$HOME/Desktop/$RETURN_ZIP"
  cp "$READY_NOTE" "$HOME/Desktop/$READY_NOTE"
  echo "Desktop copy: $HOME/Desktop/$RETURN_ZIP"
fi

echo
echo "Done. Please send back this return package:"
echo "$(pwd)/${RETURN_ZIP}"
echo "Size: ${ZIP_BYTES} bytes"
echo "SHA256: ${ZIP_SHA}"

#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
bash SETUP_CAUSAL_INTERVAL_ENV.sh

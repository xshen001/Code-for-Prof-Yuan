#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

python3 -m venv .venv_causal_interval
.venv_causal_interval/bin/python -m pip install --upgrade pip
.venv_causal_interval/bin/python -m pip install -r requirements_causal_interval_transfer.txt

echo
echo "Environment ready: $(pwd)/.venv_causal_interval"

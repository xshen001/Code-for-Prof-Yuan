# Plan for Professor Yuan's Codex

## Objective

Run the corrected evaluator-seeded causal interval-transfer standard evaluation exactly as packaged, then return the generated result zip to the authors.

This is the final run for this benchmark. Do not run a smoke test. Do not edit the experiment code, scoring rule, candidate rules, or requirements unless setup fails and Professor Yuan explicitly asks for debugging.

## What makes this an evaluator-seeded run

The standard command generates the master seeds, public-validation seed base, and hidden-test seed base locally on Professor Yuan's machine using Python `secrets.SystemRandom`. The authors do not know those seeds before the result zip is returned.

The returned result folder must include:

```text
evaluator_seed_manifest.json
```

The terminal output should include:

```text
Seed source: evaluator-machine OS entropy
```

## Steps

1. Open a terminal in this package directory.

2. If the required Python packages are missing, run:

```bash
./SETUP_CAUSAL_INTERVAL_ENV.command
```

3. Run the final standard evaluation:

```bash
./RUN_CAUSAL_INTERVAL_TRANSFER_STANDARD.command
```

4. After completion, verify that a nonzero-size return zip exists. Its name should match:

```text
causal_interval_transfer_standard_*_return_to_authors.zip
```

5. Verify that the result directory contains:

```text
summary.csv
contrasts.csv
manifest.json
evaluator_seed_manifest.json
hidden_records.csv
selected_rules.csv
```

6. Send back the generated nonzero-size return zip:

```text
causal_interval_transfer_standard_*_return_to_authors.zip
```

## If the run fails

Do not edit the experiment to force a result. Send back the terminal output, the result directory if one was created, and any error message. If a return zip is produced, send it back even if the run reports failure.

## Expected runtime

This is a modest CPU run. It may take several minutes depending on the machine.

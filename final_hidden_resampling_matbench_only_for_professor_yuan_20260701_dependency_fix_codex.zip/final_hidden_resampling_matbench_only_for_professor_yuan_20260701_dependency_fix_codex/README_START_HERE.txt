Matbench-only hidden-resampling package
======================================

Dependency correction in this package
-------------------------------------
This corrected package fixes an author-side packaging error in the previous
Matbench-only package. The previous requirements file simultaneously required
`matbench==0.6` and `matminer==0.10.1`, but `matbench==0.6` requires
`matminer==0.7.4`. Those requirements cannot be satisfied together.

This package changes only the environment specification by using
`matminer==0.7.4`, the version required by `matbench==0.6`. Because
`matbench==0.6` also carries obsolete exact pins for other packages, the setup
script installs the modern runtime stack first and then installs
`matbench==0.6` and `matminer==0.7.4` with `--no-deps`. No evaluation script,
candidate-selection rule, scoring rule, randomization rule, or return file
format has been changed.

Purpose
-------
This package completes only the Matbench module that was omitted from the
previous Professor Yuan return because the materials-science environment was
not available. Please do not rerun protein, causal inference, or program
synthesis; those modules already completed successfully.

What this evaluates
-------------------
The package uses public Matbench labeled records, but creates private
curator-seeded train/test resampling splits after the protocol is fixed.
Candidate selection uses only the resampled training part and inner validation
splits. The held-out resampled test labels are scored only after each arm's
output has been selected.

This is not an official Matbench leaderboard submission and not a new
materials dataset. It is a private hidden-resampling check of the frozen
Matbench protocol.

Recommended steps
-----------------
1. Ask Professor Yuan's Codex/Cursor agent to read `plan.md` in this package
   root. It contains the final execution plan and return-file instructions.

2. Double-click:

   SETUP_MATBENCH_ENV.command

   This creates `.venv_matbench_yuan` and installs pinned packages. The setup
   script prefers `python3.11` when available, otherwise it uses `python3`.
   It installs the runtime dependencies first, then installs `matbench==0.6`
   and `matminer==0.7.4` with `--no-deps` to avoid Matbench's obsolete exact
   dependency pins.

3. Optional environment check:

       RUN_MATBENCH_HIDDEN_RESAMPLING_SMOKE.command

   This quick smoke test checks that the environment and CHGNet stack run.
   It is not final evidence.

4. For the final result, double-click:

       RUN_MATBENCH_HIDDEN_RESAMPLING_STANDARD.command

What to send back
-----------------
After the standard run completes, send back the generated file whose name
matches:

    matbench_only_hidden_resampling_*_return_to_authors.zip

If setup or smoke fails
----------------------
Please do not spend extra time debugging package conflicts. Send back the
Terminal output or screenshots/logs from the failed setup or smoke command.
The Matbench stack is known to be environment-sensitive.

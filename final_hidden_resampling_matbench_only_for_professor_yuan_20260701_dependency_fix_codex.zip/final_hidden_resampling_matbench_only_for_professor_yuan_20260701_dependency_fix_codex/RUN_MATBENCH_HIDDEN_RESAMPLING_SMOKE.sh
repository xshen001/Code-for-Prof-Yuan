#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ -x ".venv_matbench_yuan/bin/python" ]; then
  PYTHON_BIN=".venv_matbench_yuan/bin/python"
else
  PYTHON_BIN="${PYTHON_BIN:-python3}"
fi

echo "Starting Matbench-only smoke check."
echo "Python: $(${PYTHON_BIN} -c 'import sys; print(sys.executable)')"
"${PYTHON_BIN}" run_final_matbench_only_eval.py --mode smoke

echo
echo "Smoke done. If this succeeded, run RUN_MATBENCH_HIDDEN_RESAMPLING_STANDARD.command."

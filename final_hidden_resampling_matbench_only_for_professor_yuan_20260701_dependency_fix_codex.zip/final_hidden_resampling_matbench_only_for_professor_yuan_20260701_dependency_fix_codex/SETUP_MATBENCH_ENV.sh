#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ -n "${PYTHON_BIN:-}" ]; then
  PYTHON_BIN="${PYTHON_BIN}"
elif command -v python3.11 >/dev/null 2>&1; then
  PYTHON_BIN="python3.11"
else
  PYTHON_BIN="python3"
fi
VENV_DIR=".venv_matbench_yuan"

echo "Creating Matbench-only Python environment."
echo "Python command: ${PYTHON_BIN}"
"${PYTHON_BIN}" -m venv "${VENV_DIR}"

"${VENV_DIR}/bin/python" -m pip install --upgrade 'pip<25' setuptools wheel
"${VENV_DIR}/bin/python" -m pip install -r requirements_matbench_yuan.txt
"${VENV_DIR}/bin/python" -m pip install --no-deps matbench==0.6 matminer==0.7.4

echo
echo "Environment ready: ${VENV_DIR}"
echo "Next: run RUN_MATBENCH_HIDDEN_RESAMPLING_SMOKE.command first."

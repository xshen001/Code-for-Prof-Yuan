# Matbench Agent Experiment

This folder implements a sealed official-fold Matbench validation layer for the
self-improving-agent manuscript. Matbench labels are public, so this is not a
hidden benchmark. The protocol instead freezes the policy generator, uses
official Matbench folds, performs model selection only inside each official
training fold, and records complete candidate archives before evaluating the
official test fold.

## Arms

- `target_only_one_shot`: one deterministic baseline policy per task.
- `target_only_self_improving`: target-task inner-validation search under a
  fixed candidate budget.
- `cross_domain_one_shot`: source-task candidate ranking transferred to the
  target task, with no target-task candidate search.
- `cross_domain_self_improving`: source-task candidate ranking followed by the
  same target-task inner-validation budget as target-only self-improvement.

The key ordering is:

```text
cross_domain_self_improving > target_only_self_improving > target_only_one_shot
```

## Environment

For the independent Matbench-only rerun, use the top-level one-click setup:

```bash
../SETUP_MATBENCH_ENV.command
```

The corrected top-level setup installs the modern runtime stack first, then
installs `matbench==0.6` and the compatible `matminer==0.7.4` with `--no-deps`.
The previous Matbench-only package incorrectly pinned `matminer==0.10.1`; that
contradiction is not part of this corrected package.

The `expert_included` candidate library requires the OpenMP runtime used by
LightGBM and XGBoost. On the local machine used for the corrected probe, this
runtime was supplied by the R framework and exposed with
`DYLD_LIBRARY_PATH=/Library/Frameworks/R.framework/Versions/4.6-x86_64/Resources/lib`.
If OpenMP is installed through Homebrew or another system package manager, the
environment prefix may not be needed.

## Smoke Test

```bash
matbench_agent_experiment/.venv312/bin/python matbench_agent_experiment/run_matbench_experiment.py \
  --tasks matbench_steels,matbench_glass \
  --folds 0 \
  --target-budget 4 \
  --source-budget 4 \
  --max-train 1200 \
  --output-dir results_smoke
```

## Pilot Run

```bash
matbench_agent_experiment/.venv312/bin/python matbench_agent_experiment/run_matbench_experiment.py \
  --tasks matbench_steels,matbench_glass,matbench_expt_gap,matbench_expt_is_metal \
  --folds 0,1,2,3,4 \
  --target-budget 8 \
  --source-budget 8 \
  --max-train 5000 \
  --output-dir results_pilot
```

## Source-Rich Regression Runs

These runs are more diagnostic for the cross-domain mechanism because all
target tasks are regression tasks and each target task has several same-type
source tasks.

```bash
matbench_agent_experiment/.venv312/bin/python matbench_agent_experiment/run_matbench_experiment.py \
  --tasks matbench_steels,matbench_expt_gap,matbench_dielectric,matbench_jdft2d,matbench_phonons \
  --folds 0,1,2,3,4 \
  --target-budget 4 \
  --source-budget 10 \
  --max-train 3000 \
  --output-dir results_regression5_target4_source10
```

```bash
matbench_agent_experiment/.venv312/bin/python matbench_agent_experiment/run_matbench_experiment.py \
  --tasks matbench_steels,matbench_expt_gap,matbench_dielectric,matbench_jdft2d,matbench_phonons \
  --folds 0,1,2,3,4 \
  --target-budget 2 \
  --source-budget 10 \
  --max-train 3000 \
  --output-dir results_regression5_target2_source10
```

## Recommended Richer-Policy Run

This is the recommended public Matbench validation run. It keeps the same
scarce target-validation budget but lets the cross-domain prior rank a richer
fixed policy class, including log-target and wide-feature candidates. The
guarded update keeps the source-prior candidate unless the target inner split
improves validation loss by at least 2%.

```bash
matbench_agent_experiment/.venv312/bin/python matbench_agent_experiment/run_matbench_experiment.py \
  --tasks matbench_steels,matbench_expt_gap,matbench_dielectric,matbench_jdft2d,matbench_phonons \
  --folds 0,1,2,3,4 \
  --target-budget 2 \
  --source-budget 18 \
  --max-train 3000 \
  --cross-update-margin 0.02 \
  --output-dir results_regression5_target2_source18_richer_policy_guarded
```

## Outputs

Each run writes:

- `records.csv` and `records.jsonl`: per-arm, per-task, per-fold results.
- `candidate_archive.jsonl`: all candidate validations and source-prior scores.
- `summary.csv`: aggregate metrics by arm.
- `contrasts.csv`: paired arm contrasts.
- `latex_tables.tex`: manuscript-ready tables.
- `plots/arm_mean_rank.pdf`: mean rank by arm.
- `manifest.json`: arguments, package versions, and protocol notes.

See `RESULTS_SUMMARY.md` for the completed-run interpretation. The recommended
richer-policy guarded run supports the central ordering
`cross_domain_self_improving > target_only_self_improving > target_only_one_shot`
on five official-fold Matbench regression tasks. It should still be described
as a public official-fold benchmark, not a hidden benchmark.

## Official Reference Boundary Check

For the all-task Professor Yuan run, compare the source-informed
self-improving arm with documented Matbench v0.1 public leaderboard references:

```bash
python3 matbench_agent_experiment/compare_official_reference.py
```

This writes `official_reference_comparison.csv`,
`official_reference_summary.csv`, and `official_reference_latex_table.tex`
inside the all-task results directory. The comparison is a public leaderboard
boundary check. It is not a hidden evaluation and should not be described as a
declared expert-exceedance result unless the generated summary supports that
claim.

## Expanded-Library Probe

The main script also supports `--candidate-library expanded`, which adds
faster matminer composition descriptors and stronger tree/boosting candidates.
A local four-task probe on reference-close regression tasks is stored in
`results_matbench_expanded_probe_4tasks/`. It preserves the target-side
self-improvement signal but does not increase the official-reference win count:
the expanded source-informed self-improving arm beats documented references on
two of the four probed tasks (`matbench_jdft2d` and `matbench_steels`) and
misses `matbench_dielectric` and `matbench_expt_gap`. This probe is therefore
an audit of candidate-space expansion, not a replacement for the all-task
non-author result.

## Expert-Included Probe

The script also supports `--candidate-library expert_included`, which extends
the expanded library with LightGBM and XGBoost candidates using matminer
composition descriptors. This makes the runnable candidate space include
expert-style materials-informatics learners rather than only the original
18-rule library:

```bash
DYLD_LIBRARY_PATH=/Library/Frameworks/R.framework/Versions/4.6-x86_64/Resources/lib \
matbench_agent_experiment/.venv312/bin/python matbench_agent_experiment/run_matbench_experiment.py \
  --tasks matbench_dielectric,matbench_expt_gap,matbench_jdft2d,matbench_steels \
  --folds 0,1,2,3,4 \
  --target-budget 29 \
  --source-budget 29 \
  --max-train 1500 \
  --master-seed 411852506 \
  --cross-update-margin 0.02 \
  --candidate-library expert_included \
  --output-dir results_matbench_expert_included_probe_4tasks_v2
```

The completed run is stored in
`results_matbench_expert_included_probe_4tasks_v2/`. It preserves the strong
target-side self-improvement signal: target-only self-improvement improves over
target-only one-shot by 0.0941 normalized utility units, and cross-domain
self-improvement improves over cross-domain one-shot by 0.0142. The extra
source gain over target-only self-improvement is slightly negative in this probe
(-0.0018), and the official-reference comparison still beats two of the four
documented Matbench references. The target-validation selector does choose
LightGBM or XGBoost candidates on several experimental-gap and dielectric
folds, so these expert-style learners are genuinely inside the runnable space.
The official-reference result nevertheless does not improve, which confirms
that simply adding modern expert-style learners is not enough to reproduce the
strongest official Matbench reference methods.

Exact official pipelines remain separate. A dry-run installation of the legacy
`automatminer` package on this Apple Silicon/Python 3.12 stack attempts to build
old pinned dependencies including `xgboost==0.80` and fails at the compiler
stage. Therefore the documented Automatminer/MEGNet/CGCNN reference numbers are
kept as public leaderboard comparators unless a separate compatible legacy
environment or saved official predictions are supplied.

## Tier 1 / Tier 2 Candidate-Expansion Trajectory

The staged trajectory runner audits the finite-iteration interpretation of
self-improvement on four reference-close regression tasks. It keeps the target
update budget fixed at two candidate evaluations per task-fold and expands the
source-informed candidate space over stages:

- `t=0`: 18 base regression candidates.
- `t=1`: 24 descriptor/log-transform candidates.
- `t=2`: 29 candidates after adding executable LightGBM/XGBoost expert-style
  learners.
- `t=3`: 36 candidates after adding open-knowledge boosted-tree variants and
  voting ensembles.

The incumbent selector may retain a previous-stage candidate unless inner
validation supports replacement. Outer-fold labels and official leaderboard
scores are never used for selection.

```bash
DYLD_LIBRARY_PATH=/Library/Frameworks/R.framework/Versions/4.6-x86_64/Resources/lib \
matbench_agent_experiment/.venv312/bin/python matbench_agent_experiment/run_matbench_trajectory.py \
  --tasks matbench_dielectric,matbench_expt_gap,matbench_jdft2d,matbench_steels \
  --folds 0,1,2,3,4 \
  --target-budget 2 \
  --source-budget 999 \
  --max-train 1500 \
  --master-seed 411852506 \
  --cross-update-margin 0.02 \
  --output-dir results_matbench_tier1_tier2_trajectory_4tasks
```

The completed run is stored in
`results_matbench_tier1_tier2_trajectory_4tasks/`. Its incumbent trajectory
improves source-informed self-improving utility from `-0.279 ± 0.021` at `t=0`
to `-0.277 ± 0.021` at `t=3`. The paired gain over target-only
self-improvement increases from `0.0199 ± 0.0045` to `0.0222 ± 0.0043`
over 20 task-fold evaluations, with paired win rate increasing from 85% to
90%. The run records zero candidate-validation failures. The official reference
boundary check remains two of four tasks beaten, with the mean agent/reference
error ratio improving from `1.088` to `1.082`.

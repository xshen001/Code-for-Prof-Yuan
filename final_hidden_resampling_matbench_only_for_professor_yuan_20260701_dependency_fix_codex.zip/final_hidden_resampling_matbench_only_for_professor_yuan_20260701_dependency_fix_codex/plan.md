# Plan for Professor Yuan's Codex

## Objective

Run the corrected Matbench-only hidden-resampling standard evaluation exactly as packaged, then return the generated standard result zip to the authors.

This package is only for the Matbench module. Do not rerun protein fitness, causal inference, online resource allocation, or program synthesis from this package.

## What makes this a final non-author run

The wrapper generates a private master seed on Professor Yuan's machine when no seed is supplied. The Matbench hidden-resampling seed is derived from that private master seed. The authors do not know the generated seed before the result zip is returned.

The final standard run uses:

```text
tasks: matbench_dielectric, matbench_jdft2d, matbench_log_gvrh, matbench_log_kvrh
split ids: 0,1,2,3,4
target budget: 24
CHGNet/foundation budget: 15
validation repeats: 3
held-out test fraction: 0.20
```

Candidate selection uses only the resampled training part and inner validation splits. The resampled held-out test labels are scored only after each arm's output has been selected.

## Steps

1. Open a terminal in this package directory.

2. Set up the intended Python environment:

```bash
./SETUP_MATBENCH_ENV.command
```

This package uses a corrected dependency specification: `matbench==0.6` with `matminer==0.7.4`.

3. Optional environment check:

```bash
./RUN_MATBENCH_HIDDEN_RESAMPLING_SMOKE.command
```

The smoke run is not final evidence. It only checks that the Matbench/Matminer/CHGNet environment works.

4. Run the final standard evaluation:

```bash
./RUN_MATBENCH_HIDDEN_RESAMPLING_STANDARD.command
```

5. After completion, verify that a nonzero-size return zip exists. Its name should match:

```text
matbench_only_hidden_resampling_standard_*_return_to_authors.zip
```

6. Send back only the standard return zip:

```text
matbench_only_hidden_resampling_standard_*_return_to_authors.zip
```

## If the run fails

Do not edit the experiment to force a result. Send back the terminal output, screenshots if available, the result directory if one was created, and any generated return zip.

## Expected runtime

This is the heaviest of the small handoff packages because it builds materials descriptors and CHGNet/foundation features. Runtime depends strongly on the machine and installed wheels.

#!/usr/bin/env python3
"""One-command Matbench-only hidden-resampling evaluation wrapper.

This package is intended to complete the Matbench module that was omitted from
the final non-author return because the materials-science environment was not
available. It creates or accepts a private master seed, derives one Matbench
secret seed, runs the frozen Matbench hidden-resampling protocol, records
manifests and hashes, and creates one return zip for the authors.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import random
import secrets
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_OUT = ROOT / "matbench_only_results"


def utc_stamp() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S_utc")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def output_hashes(root: Path, exclude: set[Path] | None = None) -> list[dict[str, object]]:
    excluded = {p.resolve() for p in (exclude or set())}
    rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.resolve() in excluded:
            continue
        rows.append(
            {
                "path": str(path.relative_to(root)),
                "size_bytes": int(path.stat().st_size),
                "sha256": sha256_file(path),
            }
        )
    return rows


def make_master_seed(seed: int | None) -> tuple[int, str]:
    if seed is not None:
        return int(seed), "curator_supplied"
    return int.from_bytes(secrets.token_bytes(8), "big") & ((1 << 63) - 1), "machine_secret"


def derived_seed(master_seed: int, label: str) -> int:
    rng = random.Random(f"{master_seed}:{label}")
    return rng.randrange(1, 2_147_483_647)


def module_plan(mode: str) -> dict[str, object]:
    if mode == "smoke":
        return {
            "matbench_tasks": "matbench_jdft2d",
            "matbench_split_ids": "0",
            "matbench_target_budget": 2,
            "matbench_chgnet_budget": 1,
            "matbench_validation_repeats": 1,
            "matbench_test_fraction": 0.20,
        }
    if mode == "standard":
        return {
            "matbench_tasks": "matbench_dielectric,matbench_jdft2d,matbench_log_gvrh,matbench_log_kvrh",
            "matbench_split_ids": "0,1,2,3,4",
            "matbench_target_budget": 24,
            "matbench_chgnet_budget": 15,
            "matbench_validation_repeats": 3,
            "matbench_test_fraction": 0.20,
        }
    raise ValueError(mode)


def run_matbench(out: Path, plan: dict[str, object], seed: int, env: dict[str, str]) -> dict[str, object]:
    module_root = ROOT / "matbench_agent_experiment"
    log_dir = out / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = log_dir / "matbench.stdout.txt"
    stderr_path = log_dir / "matbench.stderr.txt"
    cmd = [
        sys.executable,
        "run_matbench_hidden_resampling_foundation_stack.py",
        "--tasks",
        str(plan["matbench_tasks"]),
        "--split-ids",
        str(plan["matbench_split_ids"]),
        "--secret-seed",
        str(seed),
        "--test-fraction",
        str(plan["matbench_test_fraction"]),
        "--target-budget",
        str(plan["matbench_target_budget"]),
        "--chgnet-budget",
        str(plan["matbench_chgnet_budget"]),
        "--validation-repeats",
        str(plan["matbench_validation_repeats"]),
        "--output-dir",
        str(out / "matbench_hidden_resampling"),
    ]
    record = {
        "name": "matbench",
        "cwd": str(module_root),
        "cmd": cmd,
        "stdout": str(stdout_path.relative_to(out)),
        "stderr": str(stderr_path.relative_to(out)),
        "started_utc": utc_stamp(),
    }
    started = time.time()
    completed = subprocess.run(
        cmd,
        cwd=module_root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        check=False,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    record["completed_utc"] = utc_stamp()
    record["elapsed_seconds"] = time.time() - started
    record["returncode"] = int(completed.returncode)
    if completed.returncode != 0:
        raise subprocess.CalledProcessError(completed.returncode, cmd, completed.stdout, completed.stderr)
    return record


def make_return_zip(out: Path, mode: str) -> Path:
    zip_path = out.parent / f"matbench_only_hidden_resampling_{mode}_{out.name}_return_to_authors.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(out.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(out.parent))
    return zip_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("smoke", "standard"), default="standard")
    parser.add_argument("--out", default=None)
    parser.add_argument("--master-seed", type=int, default=None, help="Optional curator-supplied secret seed. Omit to generate privately.")
    parser.add_argument("--skip-zip", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    master_seed, seed_source = make_master_seed(args.master_seed)
    matbench_seed = derived_seed(master_seed, "matbench")
    stamp = utc_stamp()
    out = Path(args.out).resolve() if args.out else DEFAULT_OUT / f"{args.mode}_{stamp}"
    out.mkdir(parents=True, exist_ok=True)

    plan = module_plan(args.mode)
    env = dict(os.environ)
    env.setdefault("MPLBACKEND", "Agg")
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    env.setdefault("OPENBLAS_NUM_THREADS", "1")
    env.setdefault("NUMEXPR_NUM_THREADS", "1")

    pre_manifest = {
        "protocol": "matbench_only_non_author_hidden_resampling_wrapper_v1",
        "mode": args.mode,
        "created_utc": stamp,
        "python_executable": sys.executable,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "master_seed_source": seed_source,
        "master_seed_sha256": sha256_text(str(master_seed)),
        "matbench_seed_sha256": sha256_text(str(matbench_seed)),
        "plan": plan,
        "selection_evaluation_separation": (
            "Candidate selection uses only the resampled training part and inner "
            "validation splits. The curator-seeded resampled test labels are "
            "scored only after each arm's output has been selected."
        ),
    }
    (out / "pre_run_manifest.json").write_text(json.dumps(pre_manifest, indent=2) + "\n")

    run_record = run_matbench(out, plan, matbench_seed, env)

    final_manifest_path = out / "final_manifest.json"
    final_manifest = dict(pre_manifest)
    final_manifest["completed_utc"] = utc_stamp()
    final_manifest["master_seed"] = master_seed
    final_manifest["matbench_seed"] = matbench_seed
    final_manifest["run_records"] = [run_record]
    final_manifest["output_hashes_excluding_final_manifest"] = output_hashes(out, exclude={final_manifest_path})
    final_manifest_path.write_text(json.dumps(final_manifest, indent=2) + "\n")
    (out / "final_manifest.sha256").write_text(f"{sha256_file(final_manifest_path)}  final_manifest.json\n")

    zip_path = None
    if not args.skip_zip:
        zip_path = make_return_zip(out, args.mode)
        (out / "return_zip_path.txt").write_text(str(zip_path) + "\n")

    print(f"Wrote Matbench-only hidden-resampling evaluation to {out}")
    if zip_path is not None:
        print(f"Return zip: {zip_path}")


if __name__ == "__main__":
    main()

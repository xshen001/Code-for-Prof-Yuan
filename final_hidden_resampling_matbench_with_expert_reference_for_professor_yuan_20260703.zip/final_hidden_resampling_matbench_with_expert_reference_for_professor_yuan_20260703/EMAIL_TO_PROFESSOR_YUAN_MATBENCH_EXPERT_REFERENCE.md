Dear Professor Yuan,

Thank you again for the independent evaluation and for identifying the previous Matbench setup problem.

I am sending a corrected Matbench expert-reference package:

`final_hidden_resampling_matbench_with_expert_reference_for_professor_yuan_20260703.zip`

This package reruns only the Matbench module. It keeps the hidden-resampling protocol, but adds the missing same-split expert-reference comparator. The final run now scores five arms on the same curator-seeded hidden resamples:

1. target-only one-shot
2. target-only self-improving
3. source-informed one-shot
4. source-informed self-improving
5. declared expert-style reference

The expert-reference arm is a fixed, predeclared materials-informatics rule: `reg_extra_ll_structure_matminer_wide`. It is scored on the same hidden test splits as the agent arms.

Please unzip the package and, if convenient, run:

1. Ask your Codex/Cursor agent to read `plan.md` in the package root.
2. `SETUP_MATBENCH_ENV.command`
3. Optional environment check: `RUN_MATBENCH_EXPERT_REFERENCE_SMOKE.command`
4. Final result: `RUN_MATBENCH_EXPERT_REFERENCE_STANDARD.command`

Please run the package unmodified. The setup command creates the intended package-local environment automatically. If setup or smoke fails, please send back the terminal output or screenshots/logs rather than editing code or dependency files locally.

After the standard run completes, please send back the generated file whose name matches:

`matbench_expert_reference_hidden_resampling_standard_*_return_to_authors.zip`

Best regards,

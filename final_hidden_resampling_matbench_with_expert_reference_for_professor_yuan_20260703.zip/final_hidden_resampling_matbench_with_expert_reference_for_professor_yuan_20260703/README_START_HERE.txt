Matbench hidden-resampling package with expert reference
=======================================================

Purpose
-------
This package reruns only the Matbench module. It corrects the previous
comparison by scoring a predeclared expert-style materials-informatics rule on
the same curator-seeded hidden resamples as the four agent arms.
It also scores the same expert-reference rule on Matbench's
benchmark-prespecified folds as a calibration check.

Please do not rerun protein fitness, causal inference, online resource
allocation, or program synthesis from this package.

What this evaluates
-------------------
The package uses public Matbench labeled records, but creates private
curator-seeded train/test resampling splits after the protocol is fixed.
Candidate selection uses only the resampled training part and inner validation
splits. The held-out resampled test labels are scored only after each arm's
output has been selected.

The five evaluated arms are:

1. target-only one-shot
2. target-only self-improving
3. source-informed one-shot
4. source-informed self-improving
5. declared expert-style reference

The expert-reference arm is the fixed candidate
`reg_extra_ll_structure_matminer_wide`. It is a same-split declared
comparator, not a substitute for the official Matbench leaderboard score.

The returned zip includes `expert_fold_calibration.csv`, which compares this
same expert-reference rule on secret resamples versus Matbench official folds.

Self-contained environment
--------------------------
The setup script creates a fresh package-local Python 3.11 environment,
installs the tested dependency set, and runs preflight import checks. Professor
Yuan does not need to edit requirements, adjust packages, or change the code.

Recommended steps
-----------------
1. Ask Professor Yuan's Codex/Cursor agent to read `plan.md` in this package
   root. It contains the final execution plan and return-file instructions.

2. Double-click:

   SETUP_MATBENCH_ENV.command

3. Optional environment check:

   RUN_MATBENCH_EXPERT_REFERENCE_SMOKE.command

   This quick smoke test checks that the environment and CHGNet stack run.
   It is not final evidence.

4. For the final result, double-click:

   RUN_MATBENCH_EXPERT_REFERENCE_STANDARD.command

What to send back
-----------------
After the standard run completes, send back the generated file whose name
matches:

    matbench_expert_reference_hidden_resampling_standard_*_return_to_authors.zip

If setup or smoke fails
----------------------
Please do not edit the package to debug dependency issues. Send back the
Terminal output or screenshots/logs from the failed setup or smoke command.

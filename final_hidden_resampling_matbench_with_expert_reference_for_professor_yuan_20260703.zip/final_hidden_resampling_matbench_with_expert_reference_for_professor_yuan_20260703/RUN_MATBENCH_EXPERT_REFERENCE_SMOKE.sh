#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ -x ".venv_matbench_yuan/bin/python" ]; then
  PYTHON_BIN=".venv_matbench_yuan/bin/python"
else
  echo "ERROR: .venv_matbench_yuan was not found. Run SETUP_MATBENCH_ENV.command first." >&2
  exit 2
fi

echo "Starting Matbench expert-reference smoke check."
echo "Python: $(${PYTHON_BIN} -c 'import sys; print(sys.executable)')"
"${PYTHON_BIN}" run_final_matbench_expert_reference_eval.py --mode smoke

echo
echo "Smoke done. If this succeeded, run RUN_MATBENCH_EXPERT_REFERENCE_STANDARD.command."

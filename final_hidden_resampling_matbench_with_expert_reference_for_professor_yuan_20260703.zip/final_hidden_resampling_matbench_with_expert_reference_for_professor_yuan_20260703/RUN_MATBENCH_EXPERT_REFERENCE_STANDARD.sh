#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ -x ".venv_matbench_yuan/bin/python" ]; then
  PYTHON_BIN=".venv_matbench_yuan/bin/python"
else
  PYTHON_BIN="${PYTHON_BIN:-python3}"
fi

echo "Starting standard Matbench hidden-resampling expert-reference evaluation."
echo "Python: $(${PYTHON_BIN} -c 'import sys; print(sys.executable)')"
echo "Working directory: $(pwd)"

"${PYTHON_BIN}" run_final_matbench_expert_reference_eval.py --mode standard

echo
echo "Done. Please send back the generated matbench_expert_reference_hidden_resampling_*_return_to_authors.zip file."

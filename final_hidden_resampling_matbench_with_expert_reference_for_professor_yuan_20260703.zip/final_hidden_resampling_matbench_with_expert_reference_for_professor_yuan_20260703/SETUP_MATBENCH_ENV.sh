#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if [ -n "${PYTHON_BIN:-}" ]; then
  PYTHON_BIN="${PYTHON_BIN}"
elif command -v python3.11 >/dev/null 2>&1; then
  PYTHON_BIN="python3.11"
else
  echo "ERROR: This package is tested for Python 3.11. Please run on a machine with python3.11 available." >&2
  exit 2
fi
VENV_DIR=".venv_matbench_yuan"

PY_VERSION="$("${PYTHON_BIN}" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
if [ "${PY_VERSION}" != "3.11" ]; then
  echo "ERROR: ${PYTHON_BIN} is Python ${PY_VERSION}; this package is tested for Python 3.11." >&2
  exit 2
fi

echo "Creating fresh Matbench expert-reference Python environment."
echo "Python command: ${PYTHON_BIN}"
rm -rf "${VENV_DIR}"
"${PYTHON_BIN}" -m venv "${VENV_DIR}"

"${VENV_DIR}/bin/python" -m pip install --upgrade 'pip<25' setuptools wheel
"${VENV_DIR}/bin/python" -m pip install -r requirements_matbench_yuan.txt
"${VENV_DIR}/bin/python" -m pip install --no-deps matbench==0.6 matminer==0.7.4

echo
echo "Running environment preflight imports."
"${VENV_DIR}/bin/python" - <<'PY'
from importlib import metadata

packages = [
    "numpy",
    "pandas",
    "scipy",
    "scikit-learn",
    "matplotlib",
    "pymatgen",
    "matbench",
    "matminer",
    "torch",
    "chgnet",
]

for name in packages:
    print(f"{name}=={metadata.version(name)}")

from matbench.task import MatbenchTask
from matminer.featurizers.composition import ElementProperty, Stoichiometry, ValenceOrbital
from matminer.featurizers.structure import DensityFeatures, GlobalSymmetryFeatures, StructuralComplexity
from pymatgen.core import Composition
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor

_ = MatbenchTask
_ = Composition("SiO2")
_ = ElementProperty.from_preset("magpie")
_ = Stoichiometry()
_ = ValenceOrbital()
_ = DensityFeatures()
_ = GlobalSymmetryFeatures()
_ = StructuralComplexity()
_ = ExtraTreesRegressor(n_estimators=2, random_state=1)
_ = HistGradientBoostingRegressor(max_iter=2, random_state=1)
_ = RandomForestRegressor(n_estimators=2, random_state=1)
print("Preflight imports passed.")
PY

echo
echo "Environment ready: ${VENV_DIR}"
echo "Next: run RUN_MATBENCH_EXPERT_REFERENCE_SMOKE.command first."

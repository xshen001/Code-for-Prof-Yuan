# Matbench Hidden-Resampling Expert-Reference Module

This folder contains the Matbench code used by the top-level Professor Yuan
handoff package. Please run the top-level `.command` files rather than calling
these scripts by hand.

The active evaluator is:

```bash
run_matbench_hidden_resampling_foundation_stack_with_expert.py
```

It creates curator-seeded hidden train/test resamples from public Matbench
labeled records. Candidate selection for the four agent arms uses only the
resampled training part and inner validation splits. The resampled test labels
are scored after each output is frozen.

The evaluated arms are:

- `target_only_one_shot`
- `target_only_self_improving`
- `cross_domain_one_shot`
- `cross_domain_self_improving`
- `expert_reference`

The `expert_reference` arm is the fixed candidate
`reg_extra_ll_structure_matminer_wide`, a declared expert-style
materials-informatics comparator scored on the same hidden resamples as the
agent arms. It is not the official Matbench leaderboard score.

Outputs include `records.csv`, `summary.csv`, `by_task.csv`, `contrasts.csv`,
`hidden_split_manifest.csv`, `archive.jsonl`, `manifest.json`, and
`summary.md`.

The companion script `run_matbench_official_fold_expert_reference.py` scores
the same fixed expert-reference rule on Matbench's benchmark-prespecified
folds. The top-level wrapper uses it to write `expert_fold_calibration.csv`.

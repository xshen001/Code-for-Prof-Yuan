#!/usr/bin/env python3
"""Run a CHGNet-feature Matbench selector under official folds.

This protocol tests whether pretrained materials structure information can
expand the source-informed candidate class. Candidate selection uses only the
Matbench training fold through an inner validation split. The official held-out
fold is scored only after the selected rule is frozen.
"""

from __future__ import annotations

import argparse
import json
import math
import platform
import sys
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
from matbench.task import MatbenchTask
from sklearn.model_selection import train_test_split

from run_matbench_experiment import (
    ARM_LABELS,
    ARM_ORDER,
    CandidateSpec,
    PRIMARY_METRIC,
    all_candidates,
    featurize_many,
    make_estimator,
    maybe_subsample,
    output_dir,
    parse_csv,
    parse_ints,
    predict_for_task,
    stable_seed,
    summarize,
    target_scale,
    union_fieldnames,
    validation_loss,
    write_csv,
    write_json,
    write_jsonl,
    write_latex,
    write_plot,
)


ROOT = Path(__file__).resolve().parent
DEFAULT_RESULTS = ROOT / "results_chgnet_feature_selector"
_CHGNET_MODEL: Any | None = None


def subset_rows(x: Any, idx: np.ndarray) -> list[Any]:
    if hasattr(x, "iloc"):
        return list(x.iloc[idx])
    arr = list(x)
    return [arr[int(i)] for i in idx]


def subset_values(y: Any, idx: np.ndarray) -> np.ndarray:
    if hasattr(y, "iloc"):
        return np.asarray(y.iloc[idx], dtype=float)
    arr = np.asarray(y)
    return np.asarray(arr[idx], dtype=float)


def split_indices(n: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    idx = np.arange(n)
    return train_test_split(idx, test_size=0.25, random_state=seed)


def safe_array(value: Any) -> np.ndarray:
    arr = np.asarray(value, dtype=float).reshape(-1)
    arr[~np.isfinite(arr)] = 0.0
    return arr


def chgnet_feature_matrix(xs: list[Any], batch_size: int, archive: list[dict[str, Any]], context: dict[str, Any]) -> np.ndarray:
    from chgnet.model import CHGNet

    global _CHGNET_MODEL
    if not xs:
        return np.zeros((0, 70), dtype=float)
    if _CHGNET_MODEL is None:
        _CHGNET_MODEL = CHGNet.load()
    model = _CHGNET_MODEL
    print(
        f"[matbench-chgnet-feature-selector] predict CHGNet n={len(xs)} batch_size={batch_size} block={context.get('block')}",
        flush=True,
    )
    preds: list[dict[str, Any]] = []
    for start in range(0, len(xs), batch_size):
        batch = xs[start : start + batch_size]
        if start == 0 or start % max(batch_size * 100, 1) == 0:
            print(
                f"[matbench-chgnet-feature-selector] CHGNet batch start={start} n={len(xs)} block={context.get('block')}",
                flush=True,
            )
        try:
            batch_preds = model.predict_structure(
                batch,
                task="em",
                return_crystal_feas=True,
                batch_size=batch_size,
            )
            if isinstance(batch_preds, dict):
                batch_preds = [batch_preds]
            preds.extend(batch_preds)
            continue
        except Exception as exc:
            archive.append(
                {
                    **context,
                    "phase": "chgnet_batch_fallback",
                    "batch_start": int(start),
                    "batch_size": int(len(batch)),
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
        for offset, structure in enumerate(batch):
            try:
                single_pred = model.predict_structure(
                    [structure],
                    task="em",
                    return_crystal_feas=True,
                    batch_size=1,
                )
                if isinstance(single_pred, dict):
                    single_pred = [single_pred]
                preds.extend(single_pred)
            except Exception as exc:
                archive.append(
                    {
                        **context,
                        "phase": "chgnet_structure_failure",
                        "structure_index": int(start + offset),
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )
                preds.append({"e": [0.0], "crystal_fea": np.zeros(64), "m": np.zeros(1)})
    rows: list[np.ndarray] = []
    for rank, pred in enumerate(preds):
        energy = safe_array(pred.get("e", [0.0]))[:1]
        crystal = safe_array(pred.get("crystal_fea", np.zeros(64)))
        if len(crystal) < 64:
            crystal = np.pad(crystal, (0, 64 - len(crystal)))
        crystal = crystal[:64]
        mag = safe_array(pred.get("m", np.zeros(1)))
        mag_stats = np.asarray(
            [
                float(np.mean(mag)) if len(mag) else 0.0,
                float(np.std(mag)) if len(mag) else 0.0,
                float(np.min(mag)) if len(mag) else 0.0,
                float(np.max(mag)) if len(mag) else 0.0,
                float(np.mean(np.abs(mag))) if len(mag) else 0.0,
            ],
            dtype=float,
        )
        rows.append(np.concatenate([energy, crystal, mag_stats]))
        if rank == 0:
            archive.append(
                {
                    **context,
                    "phase": "chgnet_feature_shape",
                    "n_features": int(len(rows[-1])),
                    "batch_size": int(batch_size),
                }
            )
    return np.vstack(rows).astype(float)


def feature_blocks(xs: list[Any], include_chgnet: bool, batch_size: int, archive: list[dict[str, Any]], context: dict[str, Any]) -> dict[str, np.ndarray]:
    blocks: dict[str, np.ndarray] = {}
    blocks["wide"] = featurize_many(xs, "wide")
    if include_chgnet:
        chg = chgnet_feature_matrix(xs, batch_size, archive, context)
        blocks["chgnet"] = chg
        blocks["wide_chgnet"] = np.hstack([blocks["wide"], chg])
    return blocks


def add_chgnet_blocks(base_blocks: dict[str, np.ndarray], xs: list[Any], batch_size: int, archive: list[dict[str, Any]], context: dict[str, Any]) -> dict[str, np.ndarray]:
    blocks = dict(base_blocks)
    chg = chgnet_feature_matrix(xs, batch_size, archive, context)
    blocks["chgnet"] = chg
    blocks["wide_chgnet"] = np.hstack([blocks["wide"], chg])
    return blocks


def chgnet_candidate_specs() -> list[CandidateSpec]:
    return [
        CandidateSpec("reg_lgbm_chgnet", "regression", "chgnet", "lgbm", {"n_estimators": 520, "learning_rate": 0.025, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.8, "reg_lambda": 1.5}),
        CandidateSpec("reg_lgbm_log_chgnet", "regression", "chgnet", "lgbm_log", {"n_estimators": 560, "learning_rate": 0.022, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.8, "reg_lambda": 1.8}),
        CandidateSpec("reg_xgb_chgnet", "regression", "chgnet", "xgb", {"n_estimators": 460, "learning_rate": 0.025, "max_depth": 4, "subsample": 0.9, "colsample_bytree": 0.8, "reg_lambda": 1.5}),
        CandidateSpec("reg_extra_chgnet", "regression", "chgnet", "extra", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.7}),
        CandidateSpec("reg_lgbm_wide_chgnet", "regression", "wide_chgnet", "lgbm", {"n_estimators": 700, "learning_rate": 0.018, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
        CandidateSpec("reg_lgbm_log_wide_chgnet", "regression", "wide_chgnet", "lgbm_log", {"n_estimators": 760, "learning_rate": 0.016, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.8}),
        CandidateSpec("reg_xgb_wide_chgnet", "regression", "wide_chgnet", "xgb", {"n_estimators": 620, "learning_rate": 0.018, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
        CandidateSpec("reg_extra_wide_chgnet", "regression", "wide_chgnet", "extra", {"n_estimators": 700, "min_samples_leaf": 1, "max_features": 0.45}),
    ]


def target_candidate_specs(budget: int) -> list[CandidateSpec]:
    candidates = all_candidates("regression", "tier4")
    preferred = [
        "reg_lgbm_wide",
        "reg_xgb_shallow_wide",
        "reg_xgb_deep_wide",
        "reg_extra_wide",
        "reg_hgb_wide",
        "reg_extra_log_wide",
        "reg_hgb_log_wide",
    ]
    by_id = {spec.candidate_id: spec for spec in candidates}
    ordered = [by_id[cid] for cid in preferred if cid in by_id]
    seen = {spec.candidate_id for spec in ordered}
    ordered.extend(
        spec
        for spec in candidates
        if spec.candidate_id not in seen
        and spec.candidate_id != "reg_vote_lgbm_xgb_hgb_wide"
        and spec.feature_mode in {"wide", "full", "compact"}
    )
    return ordered[: min(budget, len(ordered))]


def fit_predict_on_features(spec: CandidateSpec, features_train: dict[str, np.ndarray], y_train: np.ndarray, features_pred: dict[str, np.ndarray], seed: int) -> np.ndarray:
    estimator = make_estimator(spec, seed)
    estimator.fit(features_train[spec.feature_mode], np.asarray(y_train, dtype=float))
    return np.asarray(predict_for_task(estimator, features_pred[spec.feature_mode], "regression"), dtype=float)


def select_candidate(
    candidates: list[CandidateSpec],
    features_inner: dict[str, np.ndarray],
    y_inner: np.ndarray,
    seed: int,
    archive: list[dict[str, Any]],
    context: dict[str, Any],
) -> tuple[CandidateSpec, float]:
    train_idx, val_idx = split_indices(len(y_inner), seed)
    y_train = subset_values(y_inner, train_idx)
    y_val = subset_values(y_inner, val_idx)
    train_blocks = {key: value[train_idx] for key, value in features_inner.items()}
    val_blocks = {key: value[val_idx] for key, value in features_inner.items()}
    scale = target_scale(y_train)
    best_spec = candidates[0]
    best_loss = float("inf")
    for rank, spec in enumerate(candidates):
        error = None
        metrics: dict[str, float] = {}
        try:
            pred = fit_predict_on_features(
                spec,
                train_blocks,
                y_train,
                val_blocks,
                stable_seed(seed, spec.candidate_id),
            )
            loss, metrics = validation_loss(y_val, pred, "regression", scale)
        except Exception as exc:
            loss = float("inf")
            error = f"{type(exc).__name__}: {exc}"
        archive.append(
            {
                **context,
                "phase": "inner_validation",
                "candidate_rank": rank,
                "candidate": asdict(spec),
                "validation_loss": float(loss),
                "validation_metrics": metrics,
                "error": error,
            }
        )
        if loss < best_loss:
            best_loss = float(loss)
            best_spec = spec
    return best_spec, best_loss


def run_one_fold(task_name: str, fold: int, args: argparse.Namespace, archive: list[dict[str, Any]]) -> list[dict[str, Any]]:
    task = MatbenchTask(task_name, autoload=True)
    if task.metadata.task_type != "regression" or task.metadata.input_type != "structure":
        raise ValueError("CHGNet feature selector supports structure regression tasks only.")

    x_train_val_raw, y_train_val_raw = task.get_train_and_val_data(fold)
    x_test_raw = list(task.get_test_data(fold))
    x_fit_raw, y_fit = maybe_subsample(
        x_train_val_raw,
        y_train_val_raw,
        args.max_train,
        stable_seed(args.master_seed, task_name, fold, "fit"),
    )
    x_inner_raw, y_inner = maybe_subsample(
        x_train_val_raw,
        y_train_val_raw,
        args.max_train,
        stable_seed(args.master_seed, task_name, fold, "inner"),
    )
    x_fit = list(x_fit_raw)
    x_inner = list(x_inner_raw)
    y_fit_arr = np.asarray(y_fit, dtype=float)
    y_inner_arr = np.asarray(y_inner, dtype=float)

    target_candidates = target_candidate_specs(args.target_budget)
    cross_candidates = target_candidates + chgnet_candidate_specs()[: args.chgnet_budget]
    target_fixed = target_candidates[0]
    cross_fixed = chgnet_candidate_specs()[0]

    print(f"[matbench-chgnet-feature-selector] build target inner features task={task_name} fold={fold}", flush=True)
    target_inner_features = feature_blocks(
        x_inner,
        include_chgnet=False,
        batch_size=args.chgnet_batch_size,
        archive=archive,
        context={"task": task_name, "fold": fold, "block": "target_inner"},
    )
    print(f"[matbench-chgnet-feature-selector] add CHGNet inner features task={task_name} fold={fold}", flush=True)
    cross_inner_features = add_chgnet_blocks(
        target_inner_features,
        x_inner,
        batch_size=args.chgnet_batch_size,
        archive=archive,
        context={"task": task_name, "fold": fold, "block": "cross_inner"},
    )
    print(f"[matbench-chgnet-feature-selector] select target candidates task={task_name} fold={fold}", flush=True)
    selection_seed = stable_seed(args.master_seed, task_name, fold, "selection_split")
    target_selected, target_val_loss = select_candidate(
        target_candidates,
        target_inner_features,
        y_inner_arr,
        selection_seed,
        archive,
        {"arm": "target_only_self_improving", "task": task_name, "fold": fold},
    )
    print(f"[matbench-chgnet-feature-selector] select cross-domain candidates task={task_name} fold={fold}", flush=True)
    cross_selected, cross_val_loss = select_candidate(
        cross_candidates,
        cross_inner_features,
        y_inner_arr,
        selection_seed,
        archive,
        {"arm": "cross_domain_self_improving", "task": task_name, "fold": fold},
    )
    if cross_val_loss > target_val_loss - args.gate_margin:
        archive.append(
            {
                "arm": "cross_domain_self_improving",
                "task": task_name,
                "fold": fold,
                "phase": "target_fallback_gate",
                "target_candidate": asdict(target_selected),
                "target_validation_loss": float(target_val_loss),
                "cross_candidate": asdict(cross_selected),
                "cross_validation_loss": float(cross_val_loss),
                "gate_margin": float(args.gate_margin),
                "decision": "use_target_selected_rule",
            }
        )
        cross_selected = target_selected
        cross_val_loss = target_val_loss

    print(f"[matbench-chgnet-feature-selector] build target final features task={task_name} fold={fold}", flush=True)
    target_final_features = feature_blocks(
        x_fit + x_test_raw,
        include_chgnet=False,
        batch_size=args.chgnet_batch_size,
        archive=archive,
        context={"task": task_name, "fold": fold, "block": "target_final"},
    )
    print(f"[matbench-chgnet-feature-selector] add CHGNet final features task={task_name} fold={fold}", flush=True)
    cross_final_features = add_chgnet_blocks(
        target_final_features,
        x_fit + x_test_raw,
        batch_size=args.chgnet_batch_size,
        archive=archive,
        context={"task": task_name, "fold": fold, "block": "cross_final"},
    )
    n_fit = len(x_fit)
    target_fit = {key: value[:n_fit] for key, value in target_final_features.items()}
    target_test = {key: value[n_fit:] for key, value in target_final_features.items()}
    cross_fit = {key: value[:n_fit] for key, value in cross_final_features.items()}
    cross_test = {key: value[n_fit:] for key, value in cross_final_features.items()}

    selected = {
        "target_only_one_shot": (target_fixed, float("nan"), "fixed_target_candidate", target_fit, target_test),
        "target_only_self_improving": (target_selected, target_val_loss, "target_inner_validation", target_fit, target_test),
        "cross_domain_one_shot": (cross_fixed, float("nan"), "fixed_chgnet_candidate", cross_fit, cross_test),
        "cross_domain_self_improving": (cross_selected, cross_val_loss, "cross_inner_validation_with_target_fallback", cross_fit if cross_selected.feature_mode in cross_fit else target_fit, cross_test if cross_selected.feature_mode in cross_test else target_test),
    }

    final_scale = target_scale(y_fit_arr)
    records: list[dict[str, Any]] = []
    for arm in ARM_ORDER:
        spec, validation_loss_value, selection_rule, fit_features, test_features = selected[arm]
        print(f"[matbench-chgnet-feature-selector] final fit arm={arm} candidate={spec.candidate_id} task={task_name} fold={fold}", flush=True)
        pred = fit_predict_on_features(
            spec,
            fit_features,
            y_fit_arr,
            test_features,
            stable_seed(args.master_seed, task_name, fold, spec.candidate_id, "final"),
        )
        score_task = MatbenchTask(task_name, autoload=True)
        score_task.record(fold, pred, params={"arm": arm, "candidate": asdict(spec)})
        fold_key = score_task.folds_map[fold]
        scores = dict(score_task.results[fold_key].scores)
        primary_value = float(scores["mae"])
        utility = -primary_value / max(final_scale, 1.0e-12)
        records.append(
            {
                "task": task_name,
                "fold": fold,
                "arm": arm,
                "arm_label": ARM_LABELS[arm],
                "task_type": "regression",
                "input_type": task.metadata.input_type,
                "primary_metric": PRIMARY_METRIC["regression"],
                "primary_value": primary_value,
                "utility": utility,
                "loss": -utility,
                "selection_validation_loss": validation_loss_value,
                "selection_rule": selection_rule,
                "candidate_id": spec.candidate_id,
                "feature_mode": spec.feature_mode,
                "model": spec.model,
                "params": json.dumps(spec.params, sort_keys=True),
                "n_source_tasks": 1 if "chgnet" in spec.feature_mode else 0,
                **{f"score_{key}": float(value) for key, value in scores.items()},
            }
        )
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", default="matbench_dielectric,matbench_jdft2d,matbench_log_gvrh,matbench_log_kvrh,matbench_mp_e_form,matbench_mp_gap,matbench_perovskites,matbench_phonons")
    parser.add_argument("--folds", default="0,1,2,3,4")
    parser.add_argument("--max-train", type=int, default=4000)
    parser.add_argument("--target-budget", type=int, default=12)
    parser.add_argument("--chgnet-budget", type=int, default=12)
    parser.add_argument("--gate-margin", type=float, default=0.0005)
    parser.add_argument("--chgnet-batch-size", type=int, default=16)
    parser.add_argument("--master-seed", type=int, default=20260629)
    parser.add_argument("--output-dir", default=str(DEFAULT_RESULTS))
    args = parser.parse_args()

    tasks = parse_csv(args.tasks)
    folds = parse_ints(args.folds)
    results_dir = output_dir(args.output_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    (results_dir / "plots").mkdir(exist_ok=True)

    started = time.time()
    records: list[dict[str, Any]] = []
    archive: list[dict[str, Any]] = []
    for task_name in tasks:
        for fold in folds:
            print(f"[matbench-chgnet-feature-selector] task={task_name} fold={fold}", flush=True)
            records.extend(run_one_fold(task_name, fold, args, archive))

    summary, contrasts, by_task = summarize(records)
    write_csv(results_dir / "records.csv", records, union_fieldnames(records))
    write_jsonl(results_dir / "records.jsonl", records)
    write_jsonl(results_dir / "candidate_archive.jsonl", archive)
    write_csv(results_dir / "summary.csv", summary, list(summary[0].keys()) if summary else [])
    write_csv(results_dir / "contrasts.csv", contrasts, list(contrasts[0].keys()) if contrasts else [])
    write_csv(results_dir / "by_task.csv", by_task, list(by_task[0].keys()) if by_task else [])
    write_latex(summary, contrasts, results_dir)
    write_plot(summary, results_dir)
    manifest = {
        "protocol": "Matbench CHGNet pretrained crystal-feature selector with target-only candidate validation and source-informed CHGNet candidate expansion.",
        "args": vars(args),
        "tasks": tasks,
        "folds": folds,
        "arms": ARM_ORDER,
        "elapsed_seconds": time.time() - started,
        "python": sys.version,
        "platform": platform.platform(),
        "notes": [
            "CHGNet features are included only in source-informed candidate classes.",
            "Final test folds are scored only through MatbenchTask.record after candidate selection.",
            "Source-informed self-improvement can fall back to the target-selected rule when CHGNet candidates do not improve inner validation by gate_margin.",
        ],
    }
    write_json(results_dir / "manifest.json", manifest)
    print(f"[matbench-chgnet-feature-selector] wrote {results_dir}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Run a full-data CHGNet foundation-stack Matbench experiment.

This protocol is a stronger Matbench transfer attempt than the capped CHGNet
feature selector. It uses the full official training fold, extracts pretrained
CHGNet crystal representations, and lets target validation choose among target
expert-style rules, CHGNet rules, and convex stacks of the target incumbent with
CHGNet rules. The official held-out fold is scored only after selection.
"""

from __future__ import annotations

import argparse
import json
import math
import platform
import sys
import time
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
from matbench.task import MatbenchTask
from sklearn.model_selection import train_test_split

from run_matbench_chgnet_feature_selector import chgnet_feature_matrix
from run_matbench_experiment import (
    ARM_LABELS,
    ARM_ORDER,
    CandidateSpec,
    PRIMARY_METRIC,
    all_candidates,
    featurize_many,
    make_estimator,
    output_dir,
    parse_csv,
    parse_ints,
    predict_for_task,
    stable_seed,
    summarize,
    target_scale,
    union_fieldnames,
    validation_loss,
    write_csv,
    write_json,
    write_jsonl,
    write_latex,
    write_plot,
)


ROOT = Path(__file__).resolve().parent
DEFAULT_RESULTS = ROOT / "results_chgnet_foundation_stack"

warnings.filterwarnings("ignore", category=FutureWarning, module=r"pymatgen\..*")


@dataclass(frozen=True)
class SelectionChoice:
    kind: str
    target_spec: CandidateSpec | None
    transfer_spec: CandidateSpec | None
    alpha: float
    score: float
    losses: tuple[float, ...]
    label: str


def subset_values(y: Any, idx: np.ndarray) -> np.ndarray:
    if hasattr(y, "iloc"):
        return np.asarray(y.iloc[idx], dtype=float)
    return np.asarray(y, dtype=float)[idx]


def split_indices(n: int, seed: int, val_fraction: float) -> tuple[np.ndarray, np.ndarray]:
    idx = np.arange(n)
    train_idx, val_idx = train_test_split(idx, test_size=val_fraction, random_state=seed, shuffle=True)
    return np.asarray(train_idx, dtype=int), np.asarray(val_idx, dtype=int)


def selection_score(losses: list[float] | tuple[float, ...], se_penalty: float) -> float:
    arr = np.asarray(losses, dtype=float)
    if arr.size == 0 or not np.all(np.isfinite(arr)):
        return float("inf")
    se = float(np.std(arr, ddof=1) / math.sqrt(arr.size)) if arr.size > 1 else 0.0
    return float(np.mean(arr) + se_penalty * se)


def chgnet_specs() -> list[CandidateSpec]:
    """Portable foundation-model candidates using pretrained CHGNet representations."""
    return [
        CandidateSpec("reg_extra_chgnet_full", "regression", "chgnet", "extra", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.65}),
        CandidateSpec("reg_hgb_chgnet_full", "regression", "chgnet", "hgb", {"max_iter": 360, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
        CandidateSpec("reg_rf_chgnet_full", "regression", "chgnet", "rf", {"n_estimators": 620, "min_samples_leaf": 1, "max_features": 0.65}),
        CandidateSpec("reg_extra_wide_chgnet_full", "regression", "wide_chgnet", "extra", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.45}),
        CandidateSpec("reg_hgb_wide_chgnet_full", "regression", "wide_chgnet", "hgb", {"max_iter": 420, "learning_rate": 0.03, "l2_regularization": 0.04, "max_leaf_nodes": 31}),
        CandidateSpec("reg_rf_wide_chgnet_full", "regression", "wide_chgnet", "rf", {"n_estimators": 620, "min_samples_leaf": 1, "max_features": 0.45}),
        CandidateSpec("reg_extra_structure_matminer_wide_chgnet_full", "regression", "structure_matminer_wide_chgnet", "extra", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.38}),
        CandidateSpec("reg_hgb_structure_matminer_wide_chgnet_full", "regression", "structure_matminer_wide_chgnet", "hgb", {"max_iter": 420, "learning_rate": 0.03, "l2_regularization": 0.04, "max_leaf_nodes": 31}),
        CandidateSpec("reg_rf_structure_matminer_wide_chgnet_full", "regression", "structure_matminer_wide_chgnet", "rf", {"n_estimators": 620, "min_samples_leaf": 1, "max_features": 0.38}),
    ]


def target_specs(budget: int) -> list[CandidateSpec]:
    candidates = [
        CandidateSpec("reg_extra_ll_structure_matminer_wide", "regression", "structure_matminer_wide", "extra_ll", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.42}),
        CandidateSpec("reg_extra_structure_matminer_wide", "regression", "structure_matminer_wide", "extra", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.42}),
        CandidateSpec("reg_rf_structure_matminer_wide", "regression", "structure_matminer_wide", "rf", {"n_estimators": 620, "min_samples_leaf": 1, "max_features": 0.45}),
        CandidateSpec("reg_hgb_structure_matminer_wide", "regression", "structure_matminer_wide", "hgb", {"max_iter": 360, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
        CandidateSpec("reg_extra_dielectric_structure_matminer", "regression", "structure_matminer", "extra_dielectric", {"n_estimators": 760, "min_samples_leaf": 1, "max_features": 0.5}),
        CandidateSpec("reg_extra_ll_structure_matminer", "regression", "structure_matminer", "extra_ll", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.5}),
        CandidateSpec("reg_extra_structure_matminer", "regression", "structure_matminer", "extra", {"n_estimators": 420, "min_samples_leaf": 1, "max_features": 0.55}),
        CandidateSpec("reg_rf_structure_matminer", "regression", "structure_matminer", "rf", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.55}),
        CandidateSpec("reg_hgb_structure_matminer", "regression", "structure_matminer", "hgb", {"max_iter": 260, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
        CandidateSpec("reg_extra_matminer_wide", "regression", "matminer_wide", "extra", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.45}),
        CandidateSpec("reg_rf_matminer_wide", "regression", "matminer_wide", "rf", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.45}),
        CandidateSpec("reg_hgb_matminer", "regression", "matminer", "hgb", {"max_iter": 260, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
        CandidateSpec("reg_extra_matminer", "regression", "matminer", "extra", {"n_estimators": 320, "min_samples_leaf": 1, "max_features": 0.55}),
        CandidateSpec("reg_rf_matminer", "regression", "matminer", "rf", {"n_estimators": 320, "min_samples_leaf": 1, "max_features": 0.55}),
        CandidateSpec("reg_extra_full", "regression", "full", "extra", {"n_estimators": 240, "min_samples_leaf": 1, "max_features": 0.9}),
        CandidateSpec("reg_rf_full", "regression", "full", "rf", {"n_estimators": 240, "min_samples_leaf": 1, "max_features": 0.9}),
        CandidateSpec("reg_hgb_full", "regression", "full", "hgb", {"max_iter": 220, "learning_rate": 0.045, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
        CandidateSpec("reg_ridge_full", "regression", "full", "ridge", {"alpha": 1.0}),
        CandidateSpec("reg_extra_compact", "regression", "compact", "extra", {"n_estimators": 220, "min_samples_leaf": 2, "max_features": 0.9}),
        CandidateSpec("reg_rf_compact", "regression", "compact", "rf", {"n_estimators": 180, "min_samples_leaf": 2, "max_features": 0.75}),
        CandidateSpec("reg_hgb_compact", "regression", "compact", "hgb", {"max_iter": 180, "learning_rate": 0.055, "l2_regularization": 0.05, "max_leaf_nodes": 31}),
        CandidateSpec("reg_ridge_compact", "regression", "compact", "ridge", {"alpha": 10.0}),
    ]
    return candidates[: min(budget, len(candidates))]


def required_base_modes(specs: list[CandidateSpec]) -> set[str]:
    modes: set[str] = set()
    for spec in specs:
        mode = spec.feature_mode
        if mode == "chgnet":
            continue
        if mode.endswith("_chgnet"):
            modes.add(mode.removesuffix("_chgnet"))
        else:
            modes.add(mode)
    return modes


def build_feature_blocks(xs: list[Any], specs: list[CandidateSpec], batch_size: int, archive: list[dict[str, Any]], context: dict[str, Any]) -> dict[str, np.ndarray]:
    blocks: dict[str, np.ndarray] = {}
    modes = sorted(required_base_modes(specs))
    for mode in modes:
        print(f"[matbench-chgnet-foundation-stack] featurize mode={mode} n={len(xs)} block={context.get('block')}", flush=True)
        blocks[mode] = featurize_many(xs, mode)
    needs_chgnet = any(spec.feature_mode == "chgnet" or spec.feature_mode.endswith("_chgnet") for spec in specs)
    if needs_chgnet:
        blocks["chgnet"] = chgnet_feature_matrix(xs, batch_size, archive, context)
        for mode in modes:
            blocks[f"{mode}_chgnet"] = np.hstack([blocks[mode], blocks["chgnet"]])
    return blocks


def fit_predict_spec(spec: CandidateSpec, features_train: dict[str, np.ndarray], y_train: np.ndarray, features_pred: dict[str, np.ndarray], seed: int) -> np.ndarray:
    estimator = make_estimator(spec, seed)
    estimator.fit(features_train[spec.feature_mode], np.asarray(y_train, dtype=float))
    return np.asarray(predict_for_task(estimator, features_pred[spec.feature_mode], "regression"), dtype=float)


def select_target(
    candidates: list[CandidateSpec],
    features: dict[str, np.ndarray],
    y: np.ndarray,
    repeats: int,
    seed: int,
    val_fraction: float,
    se_penalty: float,
    archive: list[dict[str, Any]],
    context: dict[str, Any],
) -> SelectionChoice:
    losses_by_id = {spec.candidate_id: [] for spec in candidates}
    by_id = {spec.candidate_id: spec for spec in candidates}
    for repeat in range(repeats):
        train_idx, val_idx = split_indices(len(y), stable_seed(seed, "repeat", repeat), val_fraction)
        train_blocks = {key: value[train_idx] for key, value in features.items()}
        val_blocks = {key: value[val_idx] for key, value in features.items()}
        y_train = subset_values(y, train_idx)
        y_val = subset_values(y, val_idx)
        scale = target_scale(y_train)
        for rank, spec in enumerate(candidates):
            error = None
            metrics: dict[str, float] = {}
            try:
                pred = fit_predict_spec(spec, train_blocks, y_train, val_blocks, stable_seed(seed, "target", repeat, spec.candidate_id))
                loss, metrics = validation_loss(y_val, pred, "regression", scale)
            except Exception as exc:
                loss = float("inf")
                error = f"{type(exc).__name__}: {exc}"
            losses_by_id[spec.candidate_id].append(float(loss))
            archive.append(
                {
                    **context,
                    "phase": "target_repeated_validation",
                    "repeat": repeat,
                    "candidate_rank": rank,
                    "candidate": asdict(spec),
                    "validation_loss": float(loss),
                    "validation_metrics": metrics,
                    "error": error,
                }
            )
    best_id = min(losses_by_id, key=lambda cid: selection_score(losses_by_id[cid], se_penalty))
    best_losses = tuple(float(v) for v in losses_by_id[best_id])
    return SelectionChoice(
        kind="target",
        target_spec=by_id[best_id],
        transfer_spec=None,
        alpha=0.0,
        score=selection_score(best_losses, se_penalty),
        losses=best_losses,
        label=f"target:{best_id}",
    )


def select_cross(
    target_choice: SelectionChoice,
    transfer_candidates: list[CandidateSpec],
    features: dict[str, np.ndarray],
    y: np.ndarray,
    repeats: int,
    seed: int,
    val_fraction: float,
    alpha_grid: list[float],
    gate_margin: float,
    se_penalty: float,
    archive: list[dict[str, Any]],
    context: dict[str, Any],
) -> SelectionChoice:
    if target_choice.target_spec is None:
        raise ValueError("target_choice must contain a target spec.")
    target_spec = target_choice.target_spec
    loss_map: dict[str, list[float]] = {f"target:{target_spec.candidate_id}": []}
    choice_map: dict[str, tuple[str, CandidateSpec | None, float]] = {f"target:{target_spec.candidate_id}": ("target", None, 0.0)}
    for spec in transfer_candidates:
        loss_map[f"pure:{spec.candidate_id}"] = []
        choice_map[f"pure:{spec.candidate_id}"] = ("pure", spec, 1.0)
        for alpha in alpha_grid:
            key = f"stack:{spec.candidate_id}:alpha={alpha:.3f}"
            loss_map[key] = []
            choice_map[key] = ("stack", spec, float(alpha))

    for repeat in range(repeats):
        train_idx, val_idx = split_indices(len(y), stable_seed(seed, "repeat", repeat), val_fraction)
        train_blocks = {key: value[train_idx] for key, value in features.items()}
        val_blocks = {key: value[val_idx] for key, value in features.items()}
        y_train = subset_values(y, train_idx)
        y_val = subset_values(y, val_idx)
        scale = target_scale(y_train)
        target_pred = fit_predict_spec(
            target_spec,
            train_blocks,
            y_train,
            val_blocks,
            stable_seed(seed, "cross-target", repeat, target_spec.candidate_id),
        )
        target_loss, target_metrics = validation_loss(y_val, target_pred, "regression", scale)
        loss_map[f"target:{target_spec.candidate_id}"].append(float(target_loss))
        archive.append(
            {
                **context,
                "phase": "cross_repeated_validation",
                "repeat": repeat,
                "candidate_kind": "target_fallback",
                "candidate": asdict(target_spec),
                "alpha": 0.0,
                "validation_loss": float(target_loss),
                "validation_metrics": target_metrics,
                "error": None,
            }
        )
        for rank, spec in enumerate(transfer_candidates):
            try:
                transfer_pred = fit_predict_spec(spec, train_blocks, y_train, val_blocks, stable_seed(seed, "cross", repeat, spec.candidate_id))
                pure_loss, pure_metrics = validation_loss(y_val, transfer_pred, "regression", scale)
                error = None
            except Exception as exc:
                transfer_pred = np.zeros_like(target_pred)
                pure_loss = float("inf")
                pure_metrics = {}
                error = f"{type(exc).__name__}: {exc}"
            loss_map[f"pure:{spec.candidate_id}"].append(float(pure_loss))
            archive.append(
                {
                    **context,
                    "phase": "cross_repeated_validation",
                    "repeat": repeat,
                    "candidate_rank": rank,
                    "candidate_kind": "pure_chgnet_rule",
                    "candidate": asdict(spec),
                    "alpha": 1.0,
                    "validation_loss": float(pure_loss),
                    "validation_metrics": pure_metrics,
                    "error": error,
                }
            )
            if error is not None:
                for alpha in alpha_grid:
                    loss_map[f"stack:{spec.candidate_id}:alpha={alpha:.3f}"].append(float("inf"))
                continue
            for alpha in alpha_grid:
                pred = (1.0 - float(alpha)) * target_pred + float(alpha) * transfer_pred
                loss, metrics = validation_loss(y_val, pred, "regression", scale)
                key = f"stack:{spec.candidate_id}:alpha={alpha:.3f}"
                loss_map[key].append(float(loss))
                archive.append(
                    {
                        **context,
                        "phase": "cross_repeated_validation",
                        "repeat": repeat,
                        "candidate_rank": rank,
                        "candidate_kind": "target_chgnet_stack",
                        "candidate": asdict(spec),
                        "alpha": float(alpha),
                        "validation_loss": float(loss),
                        "validation_metrics": metrics,
                        "error": None,
                    }
                )

    target_key = f"target:{target_spec.candidate_id}"
    target_score = selection_score(loss_map[target_key], se_penalty)
    best_key = min(loss_map, key=lambda key: selection_score(loss_map[key], se_penalty))
    best_score = selection_score(loss_map[best_key], se_penalty)
    if best_score > target_score - gate_margin:
        best_key = target_key
        best_score = target_score
    kind, transfer_spec, alpha = choice_map[best_key]
    return SelectionChoice(
        kind=kind,
        target_spec=target_spec,
        transfer_spec=transfer_spec,
        alpha=float(alpha),
        score=float(best_score),
        losses=tuple(float(v) for v in loss_map[best_key]),
        label=best_key,
    )


def predict_choice(choice: SelectionChoice, features_train: dict[str, np.ndarray], y_train: np.ndarray, features_test: dict[str, np.ndarray], seed: int) -> tuple[np.ndarray, str, str]:
    if choice.target_spec is None:
        raise ValueError("choice must contain target_spec.")
    if choice.kind == "target":
        pred = fit_predict_spec(choice.target_spec, features_train, y_train, features_test, stable_seed(seed, choice.label, "target-final"))
        return pred, choice.target_spec.candidate_id, choice.target_spec.feature_mode
    if choice.transfer_spec is None:
        raise ValueError("transfer choice must contain transfer_spec.")
    transfer_pred = fit_predict_spec(choice.transfer_spec, features_train, y_train, features_test, stable_seed(seed, choice.label, "transfer-final"))
    if choice.kind == "pure":
        return transfer_pred, choice.transfer_spec.candidate_id, choice.transfer_spec.feature_mode
    target_pred = fit_predict_spec(choice.target_spec, features_train, y_train, features_test, stable_seed(seed, choice.label, "target-stack-final"))
    pred = (1.0 - choice.alpha) * target_pred + choice.alpha * transfer_pred
    return pred, f"stack_{choice.target_spec.candidate_id}_{choice.transfer_spec.candidate_id}_alpha_{choice.alpha:.3f}", f"{choice.target_spec.feature_mode}+{choice.transfer_spec.feature_mode}"


def run_one_fold(task_name: str, fold: int, args: argparse.Namespace, archive: list[dict[str, Any]]) -> list[dict[str, Any]]:
    task = MatbenchTask(task_name, autoload=True)
    if task.metadata.task_type != "regression" or task.metadata.input_type != "structure":
        raise ValueError("Foundation-stack protocol supports structure regression tasks only.")

    x_train_raw, y_train_raw = task.get_train_and_val_data(fold)
    x_train = list(x_train_raw)
    y_train = np.asarray(y_train_raw, dtype=float)
    x_test = list(task.get_test_data(fold))
    n_train = len(x_train)

    target_candidates = target_specs(args.target_budget)
    transfer_candidates = chgnet_specs()[: args.chgnet_budget]
    all_specs = target_candidates + transfer_candidates
    print(f"[matbench-chgnet-foundation-stack] build features task={task_name} fold={fold} n_train={n_train} n_test={len(x_test)}", flush=True)
    all_features = build_feature_blocks(
        x_train + x_test,
        all_specs,
        args.chgnet_batch_size,
        archive,
        {"task": task_name, "fold": fold, "block": "full_train_plus_test"},
    )
    train_features = {key: value[:n_train] for key, value in all_features.items()}
    test_features = {key: value[n_train:] for key, value in all_features.items()}

    target_fixed = target_candidates[0]
    cross_fixed = transfer_candidates[0]
    seed = stable_seed(args.master_seed, task_name, fold, "selection")
    print(f"[matbench-chgnet-foundation-stack] select target task={task_name} fold={fold}", flush=True)
    target_choice = select_target(
        target_candidates,
        train_features,
        y_train,
        args.validation_repeats,
        seed,
        args.validation_fraction,
        args.selection_se_penalty,
        archive,
        {"arm": "target_only_self_improving", "task": task_name, "fold": fold},
    )
    print(f"[matbench-chgnet-foundation-stack] select cross task={task_name} fold={fold}", flush=True)
    alpha_grid = [float(v) for v in args.alpha_grid]
    cross_choice = select_cross(
        target_choice,
        transfer_candidates,
        train_features,
        y_train,
        args.validation_repeats,
        seed,
        args.validation_fraction,
        alpha_grid,
        args.gate_margin,
        args.selection_se_penalty,
        archive,
        {"arm": "cross_domain_self_improving", "task": task_name, "fold": fold},
    )

    choices: dict[str, tuple[str, CandidateSpec | None, SelectionChoice | None]] = {
        "target_only_one_shot": ("fixed_target_candidate", target_fixed, None),
        "target_only_self_improving": ("repeated_target_validation", None, target_choice),
        "cross_domain_one_shot": ("fixed_chgnet_foundation_candidate", cross_fixed, None),
        "cross_domain_self_improving": ("repeated_target_validation_chgnet_stack", None, cross_choice),
    }

    final_scale = target_scale(y_train)
    records: list[dict[str, Any]] = []
    for arm in ARM_ORDER:
        selection_rule, spec, choice = choices[arm]
        print(f"[matbench-chgnet-foundation-stack] final fit arm={arm} task={task_name} fold={fold}", flush=True)
        if choice is None:
            if spec is None:
                raise ValueError("fixed arm missing spec")
            pred = fit_predict_spec(
                spec,
                train_features,
                y_train,
                test_features,
                stable_seed(args.master_seed, task_name, fold, arm, spec.candidate_id, "final"),
            )
            candidate_id = spec.candidate_id
            feature_mode = spec.feature_mode
            model = spec.model
            params = spec.params
            validation_value = float("nan")
            alpha = float("nan")
            choice_kind = "fixed"
        else:
            pred, candidate_id, feature_mode = predict_choice(
                choice,
                train_features,
                y_train,
                test_features,
                stable_seed(args.master_seed, task_name, fold, arm, "final"),
            )
            model = choice.transfer_spec.model if choice.transfer_spec is not None else choice.target_spec.model
            params = choice.transfer_spec.params if choice.transfer_spec is not None else choice.target_spec.params
            validation_value = choice.score
            alpha = choice.alpha
            choice_kind = choice.kind
        score_task = MatbenchTask(task_name, autoload=True)
        score_task.record(fold, pred, params={"arm": arm, "candidate_id": candidate_id, "selection_rule": selection_rule})
        fold_key = score_task.folds_map[fold]
        scores = dict(score_task.results[fold_key].scores)
        primary_value = float(scores["mae"])
        utility = -primary_value / max(final_scale, 1.0e-12)
        records.append(
            {
                "task": task_name,
                "fold": fold,
                "arm": arm,
                "arm_label": ARM_LABELS[arm],
                "task_type": "regression",
                "input_type": task.metadata.input_type,
                "primary_metric": PRIMARY_METRIC["regression"],
                "primary_value": primary_value,
                "utility": utility,
                "loss": -utility,
                "selection_validation_loss": validation_value,
                "selection_rule": selection_rule,
                "choice_kind": choice_kind,
                "alpha": alpha,
                "candidate_id": candidate_id,
                "feature_mode": feature_mode,
                "model": model,
                "params": json.dumps(params, sort_keys=True),
                "n_source_tasks": 1 if "chgnet" in feature_mode or choice_kind in {"pure", "stack"} else 0,
                **{f"score_{key}": float(value) for key, value in scores.items()},
            }
        )
    return records


def parse_float_grid(text: str) -> list[float]:
    return [float(part.strip()) for part in text.split(",") if part.strip()]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", default="matbench_dielectric,matbench_jdft2d,matbench_log_gvrh,matbench_log_kvrh")
    parser.add_argument("--folds", default="0,1,2,3,4")
    parser.add_argument("--target-budget", type=int, default=24)
    parser.add_argument("--chgnet-budget", type=int, default=15)
    parser.add_argument("--validation-repeats", type=int, default=3)
    parser.add_argument("--validation-fraction", type=float, default=0.22)
    parser.add_argument("--selection-se-penalty", type=float, default=0.5)
    parser.add_argument("--gate-margin", type=float, default=0.0002)
    parser.add_argument("--alpha-grid", type=parse_float_grid, default=parse_float_grid("0.05,0.1,0.2,0.35,0.5,0.65,0.8,1.0"))
    parser.add_argument("--chgnet-batch-size", type=int, default=32)
    parser.add_argument("--master-seed", type=int, default=20260630)
    parser.add_argument("--output-dir", default=str(DEFAULT_RESULTS))
    args = parser.parse_args()

    tasks = parse_csv(args.tasks)
    folds = parse_ints(args.folds)
    results_dir = output_dir(args.output_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    (results_dir / "plots").mkdir(exist_ok=True)

    started = time.time()
    records: list[dict[str, Any]] = []
    archive: list[dict[str, Any]] = []
    for task_name in tasks:
        for fold in folds:
            print(f"[matbench-chgnet-foundation-stack] task={task_name} fold={fold}", flush=True)
            records.extend(run_one_fold(task_name, fold, args, archive))

    summary, contrasts, by_task = summarize(records)
    write_csv(results_dir / "records.csv", records, union_fieldnames(records))
    write_jsonl(results_dir / "records.jsonl", records)
    write_jsonl(results_dir / "candidate_archive.jsonl", archive)
    write_csv(results_dir / "summary.csv", summary, list(summary[0].keys()) if summary else [])
    write_csv(results_dir / "contrasts.csv", contrasts, list(contrasts[0].keys()) if contrasts else [])
    write_csv(results_dir / "by_task.csv", by_task, list(by_task[0].keys()) if by_task else [])
    write_latex(summary, contrasts, results_dir)
    write_plot(summary, results_dir)
    manifest = {
        "protocol": "Matbench full-data CHGNet foundation-stack selection. Target validation chooses target expert-style rules, CHGNet rules, or target-plus-CHGNet convex stacks before official fold scoring.",
        "args": vars(args),
        "tasks": tasks,
        "folds": folds,
        "arms": ARM_ORDER,
        "elapsed_seconds": time.time() - started,
        "python": sys.version,
        "platform": platform.platform(),
        "notes": [
            "No training cap is applied.",
            "CHGNet is a pretrained source-domain materials foundation representation.",
            "Official test folds are scored only after selection is frozen.",
        ],
    }
    write_json(results_dir / "manifest.json", manifest)
    print(f"[matbench-chgnet-foundation-stack] wrote {results_dir}")


if __name__ == "__main__":
    main()

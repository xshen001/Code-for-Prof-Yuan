#!/usr/bin/env python3
"""Run a sealed official-fold Matbench validation layer.

Matbench labels are public, so this protocol should not be described as a
hidden benchmark. It is a sealed official-fold evaluation: all policy selection
uses only each official training fold, then the selected policy is trained and
evaluated on the official held-out fold through Matbench's scorer.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import random
import sys
import time
import warnings
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matbench.task import MatbenchTask
from pymatgen.core import Composition
from sklearn.base import clone
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import (
    ExtraTreesClassifier,
    ExtraTreesRegressor,
    HistGradientBoostingClassifier,
    HistGradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
    VotingClassifier,
    VotingRegressor,
)
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import mean_absolute_error, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings(
    "ignore",
    message="X does not have valid feature names, but LGBMRegressor was fitted with feature names",
    category=UserWarning,
)

try:  # Optional richer materials descriptors used only by --candidate-library expanded.
    from matminer.featurizers.composition import ElementProperty, Stoichiometry, ValenceOrbital
except Exception:  # pragma: no cover - base library remains usable without matminer.
    ElementProperty = Stoichiometry = ValenceOrbital = None

try:  # Optional lightweight structure descriptors for structure-input tasks.
    from matminer.featurizers.structure import DensityFeatures, GlobalSymmetryFeatures, StructuralComplexity
except Exception:  # pragma: no cover - structure-rich mode remains optional.
    DensityFeatures = GlobalSymmetryFeatures = StructuralComplexity = None

_LGBM_IMPORT_ERROR: Exception | None = None
try:  # Optional expert-style learners used only by --candidate-library expert_included.
    from lightgbm import LGBMClassifier, LGBMRegressor
except Exception as exc:  # pragma: no cover
    LGBMClassifier = LGBMRegressor = None
    _LGBM_IMPORT_ERROR = exc

_XGB_IMPORT_ERROR: Exception | None = None
try:  # Optional expert-style learners used only by --candidate-library expert_included.
    from xgboost import XGBClassifier, XGBRegressor
except Exception as exc:  # pragma: no cover
    XGBClassifier = XGBRegressor = None
    _XGB_IMPORT_ERROR = exc


ROOT = Path(__file__).resolve().parent
DEFAULT_RESULTS = ROOT / "results_pilot"


def parse_positive_int_env(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be a positive integer, got {raw!r}.") from exc
    if value < 1:
        raise ValueError(f"{name} must be a positive integer, got {raw!r}.")
    return value


N_JOBS = parse_positive_int_env("MATBENCH_N_JOBS", 1)

ARM_ORDER = (
    "target_only_one_shot",
    "target_only_self_improving",
    "cross_domain_one_shot",
    "cross_domain_self_improving",
)

ARM_LABELS = {
    "target_only_one_shot": "Target-only one-shot",
    "target_only_self_improving": "Target-only self-improving",
    "cross_domain_one_shot": "Cross-domain one-shot",
    "cross_domain_self_improving": "Cross-domain self-improving",
}

PRIMARY_METRIC = {
    "regression": "mae",
    "classification": "rocauc",
}


@dataclass(frozen=True)
class CandidateSpec:
    candidate_id: str
    task_type: str
    feature_mode: str
    model: str
    params: dict[str, Any]


_MATMINER_FEATURIZERS: list[Any] | None = None
_STRUCTURE_FEATURIZERS: list[Any] | None = None


def require_expert_learners() -> None:
    missing = []
    if LGBMRegressor is None or LGBMClassifier is None:
        detail = f"lightgbm ({_LGBM_IMPORT_ERROR})" if _LGBM_IMPORT_ERROR else "lightgbm"
        missing.append(detail)
    if XGBRegressor is None or XGBClassifier is None:
        detail = f"xgboost ({_XGB_IMPORT_ERROR})" if _XGB_IMPORT_ERROR else "xgboost"
        missing.append(detail)
    if missing:
        raise RuntimeError(
            "--candidate-library expert_included/open_knowledge/tier4 requires "
            + ", ".join(missing)
            + ". This handoff package uses portable candidate lists and should not call this optional library."
        )


def get_matminer_featurizers() -> list[Any]:
    global _MATMINER_FEATURIZERS
    if _MATMINER_FEATURIZERS is not None:
        return _MATMINER_FEATURIZERS
    if ElementProperty is None:
        _MATMINER_FEATURIZERS = []
    else:
        _MATMINER_FEATURIZERS = [
            ElementProperty.from_preset("magpie"),
            Stoichiometry(),
            ValenceOrbital(),
        ]
    return _MATMINER_FEATURIZERS


def get_structure_featurizers() -> list[Any]:
    global _STRUCTURE_FEATURIZERS
    if _STRUCTURE_FEATURIZERS is not None:
        return _STRUCTURE_FEATURIZERS
    classes = [DensityFeatures, GlobalSymmetryFeatures, StructuralComplexity]
    featurizers: list[Any] = []
    for cls in classes:
        if cls is None:
            continue
        try:
            featurizers.append(cls())
        except Exception:
            continue
    _STRUCTURE_FEATURIZERS = featurizers
    return _STRUCTURE_FEATURIZERS


def numeric_features(values: list[Any]) -> list[float]:
    out: list[float] = []
    for value in values:
        try:
            val = float(value)
            if math.isfinite(val):
                out.append(val)
            else:
                out.append(0.0)
        except Exception:
            out.append(0.0)
    return out


def stable_seed(*parts: object) -> int:
    text = "::".join(str(part) for part in parts)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return int(digest[:16], 16) % (2**32 - 1)


def write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, default=str) + "\n")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True, default=str) + "\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fieldnames})


def union_fieldnames(rows: list[dict[str, Any]]) -> list[str]:
    fieldnames: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for key in row:
            if key not in seen:
                fieldnames.append(key)
                seen.add(key)
    return fieldnames


def parse_csv(text: str | None, default: list[str] | None = None) -> list[str]:
    if text is None or text.strip() == "":
        return list(default or [])
    return [part.strip() for part in text.split(",") if part.strip()]


def parse_ints(text: str) -> list[int]:
    return [int(part.strip()) for part in text.split(",") if part.strip()]


def output_dir(path_text: str | None) -> Path:
    if not path_text:
        return DEFAULT_RESULTS
    path = Path(path_text)
    if not path.is_absolute():
        path = ROOT / path
    return path


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        out = float(value)
        if math.isnan(out) or math.isinf(out):
            return default
        return out
    except Exception:
        return default


def composition_from_input(x: Any) -> Composition | None:
    if hasattr(x, "composition"):
        try:
            return x.composition
        except Exception:
            return None
    try:
        return Composition(str(x))
    except Exception:
        return None


def aggregate(values: list[float], weights: list[float]) -> dict[str, float]:
    if not values or not weights or sum(weights) <= 0:
        return {"mean": 0.0, "std": 0.0, "min": 0.0, "max": 0.0, "range": 0.0}
    arr = np.asarray(values, dtype=float)
    w = np.asarray(weights, dtype=float)
    w = w / w.sum()
    mean = float(np.sum(w * arr))
    var = float(np.sum(w * (arr - mean) ** 2))
    return {
        "mean": mean,
        "std": math.sqrt(max(var, 0.0)),
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
        "range": float(np.max(arr) - np.min(arr)),
    }


def featurize_one(x: Any, feature_mode: str) -> list[float]:
    comp = composition_from_input(x)
    feats: list[float] = []
    if comp is None:
        feats.extend([0.0] * 38)
    else:
        items = list(comp.element_composition.items())
        total = sum(float(amount) for _, amount in items)
        weights = [float(amount) / total if total > 0 else 0.0 for _, amount in items]
        props = {
            "Z": [],
            "X": [],
            "atomic_mass": [],
            "row": [],
            "group": [],
        }
        for el, _ in items:
            props["Z"].append(safe_float(getattr(el, "Z", 0)))
            props["X"].append(safe_float(getattr(el, "X", 0)))
            props["atomic_mass"].append(safe_float(getattr(el, "atomic_mass", 0)))
            props["row"].append(safe_float(getattr(el, "row", 0)))
            props["group"].append(safe_float(getattr(el, "group", 0)))
        for name in ("Z", "X", "atomic_mass", "row", "group"):
            stats = aggregate(props[name], weights)
            feats.extend([stats["mean"], stats["std"], stats["min"], stats["max"], stats["range"]])
        fractions = sorted(weights, reverse=True)
        entropy = -sum(f * math.log(max(f, 1e-12)) for f in fractions)
        feats.extend(
            [
                float(len(items)),
                float(entropy),
                float(max(fractions) if fractions else 0.0),
                float(min(fractions) if fractions else 0.0),
                float(np.std(fractions) if fractions else 0.0),
            ]
        )
        padded = (fractions + [0.0] * 8)[:8]
        feats.extend(float(f) for f in padded)

    structure_modes = {"structure", "full", "wide", "structure_matminer", "structure_matminer_wide"}
    if feature_mode in structure_modes and hasattr(x, "lattice"):
        try:
            lattice = x.lattice
            a, b, c = lattice.abc
            alpha, beta, gamma = lattice.angles
            n_sites = len(x)
            volume = safe_float(x.volume)
            density = safe_float(getattr(x, "density", 0.0))
            feats.extend(
                [
                    float(n_sites),
                    volume,
                    volume / max(n_sites, 1),
                    density,
                    safe_float(a),
                    safe_float(b),
                    safe_float(c),
                    safe_float(alpha),
                    safe_float(beta),
                    safe_float(gamma),
                ]
            )
        except Exception:
            feats.extend([0.0] * 10)
    elif feature_mode in structure_modes:
        feats.extend([0.0] * 10)

    if feature_mode in {"matminer", "matminer_wide", "structure_matminer", "structure_matminer_wide"}:
        rich_feats: list[float] = []
        if comp is not None:
            for featurizer in get_matminer_featurizers():
                try:
                    rich_feats.extend(numeric_features(list(featurizer.featurize(comp))))
                except Exception:
                    rich_feats.extend([0.0] * len(getattr(featurizer, "feature_labels", lambda: [])()))
        feats.extend(rich_feats)

    if feature_mode in {"structure_matminer", "structure_matminer_wide"}:
        structure_feats: list[float] = []
        if hasattr(x, "lattice"):
            for featurizer in get_structure_featurizers():
                try:
                    structure_feats.extend(numeric_features(list(featurizer.featurize(x))))
                except Exception:
                    structure_feats.extend([0.0] * len(getattr(featurizer, "feature_labels", lambda: [])()))
        feats.extend(structure_feats)

    if feature_mode == "compact":
        return feats[:12] + feats[25:30]
    if feature_mode in {"wide", "matminer_wide", "structure_matminer_wide"}:
        base = list(feats)
        derived = []
        for value in base:
            clipped = max(min(float(value), 1e6), -1e6)
            derived.append(math.log1p(abs(clipped)))
        return base + derived
    return feats


def featurize_many(xs: Any, feature_mode: str) -> np.ndarray:
    rows = [featurize_one(x, feature_mode) for x in list(xs)]
    max_len = max(len(row) for row in rows)
    padded = [row + [0.0] * (max_len - len(row)) for row in rows]
    return np.asarray(padded, dtype=float)


def all_candidates(task_type: str, candidate_library: str = "base") -> list[CandidateSpec]:
    rich_libraries = {"expanded", "expert_included", "open_knowledge", "tier4", "uniform_transfer"}
    expert_libraries = {"expert_included", "open_knowledge", "tier4", "tier4_shortlist", "dielectric_focus", "uniform_transfer"}
    open_libraries = {"open_knowledge", "tier4"}
    if candidate_library in expert_libraries:
        require_expert_learners()
    if task_type == "regression":
        if candidate_library == "dielectric_focus":
            return [
                CandidateSpec("reg_extra_ll_structure_matminer", task_type, "structure_matminer", "extra_ll", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.5}),
                CandidateSpec("reg_lgbm_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 620, "learning_rate": 0.02, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                CandidateSpec("reg_lgbm_log_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_log", {"n_estimators": 560, "learning_rate": 0.022, "num_leaves": 31, "subsample": 0.88, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                CandidateSpec("reg_lgbm_dielectric_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_dielectric", {"n_estimators": 620, "learning_rate": 0.02, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                CandidateSpec("reg_extra_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "extra_ll", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.42}),
                CandidateSpec("reg_extra_dielectric_structure_matminer", task_type, "structure_matminer", "extra_dielectric", {"n_estimators": 760, "min_samples_leaf": 1, "max_features": 0.5}),
                CandidateSpec("reg_vote_lgbm_extra_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "vote_lgbm_extra_ll", {}),
                CandidateSpec("reg_lgbm_ll_structure_matminer_wide_smooth", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 900, "learning_rate": 0.014, "num_leaves": 31, "subsample": 0.92, "colsample_bytree": 0.76, "reg_lambda": 2.0}),
                CandidateSpec("reg_lgbm_ll_structure_matminer_wide_deep", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 760, "learning_rate": 0.016, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.4}),
            ]
        if candidate_library == "uniform_transfer":
            return [
                CandidateSpec("reg_extra_matminer", task_type, "matminer", "extra", {"n_estimators": 320, "min_samples_leaf": 1, "max_features": 0.55}),
                CandidateSpec("reg_hgb_matminer", task_type, "matminer", "hgb", {"max_iter": 260, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
                CandidateSpec("reg_lgbm_matminer", task_type, "matminer", "lgbm", {"n_estimators": 360, "learning_rate": 0.035, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                CandidateSpec("reg_lgbm_log_matminer", task_type, "matminer", "lgbm_log", {"n_estimators": 420, "learning_rate": 0.03, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.5}),
                CandidateSpec("reg_xgb_matminer", task_type, "matminer", "xgb", {"n_estimators": 320, "learning_rate": 0.035, "max_depth": 5, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                CandidateSpec("reg_xgb_log_matminer", task_type, "matminer", "xgb_log", {"n_estimators": 360, "learning_rate": 0.03, "max_depth": 5, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.5}),
                CandidateSpec("reg_extra_matminer_wide", task_type, "matminer_wide", "extra", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.45}),
                CandidateSpec("reg_lgbm_tier4_matminer_wide", task_type, "matminer_wide", "lgbm", {"n_estimators": 820, "learning_rate": 0.018, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.2}),
                CandidateSpec("reg_lgbm_tier4_log_matminer_wide", task_type, "matminer_wide", "lgbm_log", {"n_estimators": 900, "learning_rate": 0.016, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.6}),
                CandidateSpec("reg_xgb_tier4_matminer_wide", task_type, "matminer_wide", "xgb", {"n_estimators": 760, "learning_rate": 0.018, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.2}),
                CandidateSpec("reg_xgb_tier4_log_matminer_wide", task_type, "matminer_wide", "xgb_log", {"n_estimators": 820, "learning_rate": 0.016, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.6}),
                CandidateSpec("reg_extra_tier4_matminer_wide", task_type, "matminer_wide", "extra", {"n_estimators": 700, "min_samples_leaf": 1, "max_features": 0.42}),
                CandidateSpec("reg_rf_tier4_matminer_wide", task_type, "matminer_wide", "rf", {"n_estimators": 620, "min_samples_leaf": 1, "max_features": 0.45}),
                CandidateSpec("reg_vote_tier4_matminer_wide", task_type, "matminer_wide", "vote_lgbm_xgb_extra", {}),
                CandidateSpec("reg_vote_tier4_log_matminer_wide", task_type, "matminer_wide", "vote_lgbm_xgb_extra_log", {}),
                CandidateSpec("reg_extra_structure_matminer", task_type, "structure_matminer", "extra", {"n_estimators": 420, "min_samples_leaf": 1, "max_features": 0.55}),
                CandidateSpec("reg_lgbm_structure_matminer", task_type, "structure_matminer", "lgbm", {"n_estimators": 520, "learning_rate": 0.025, "num_leaves": 31, "subsample": 0.88, "colsample_bytree": 0.75, "reg_lambda": 1.2}),
                CandidateSpec("reg_xgb_structure_matminer", task_type, "structure_matminer", "xgb", {"n_estimators": 460, "learning_rate": 0.025, "max_depth": 4, "subsample": 0.88, "colsample_bytree": 0.75, "reg_lambda": 1.2}),
                CandidateSpec("reg_vote_lgbm_extra_matminer_wide", task_type, "matminer_wide", "vote_lgbm_extra", {}),
            ]
        if candidate_library == "tier4_shortlist":
            return [
                CandidateSpec("reg_rf_compact", task_type, "compact", "rf", {"n_estimators": 120, "min_samples_leaf": 2, "max_features": 0.75}),
                CandidateSpec("reg_extra_full", task_type, "full", "extra", {"n_estimators": 160, "min_samples_leaf": 1, "max_features": 0.9}),
                CandidateSpec("reg_extra_matminer", task_type, "matminer", "extra", {"n_estimators": 320, "min_samples_leaf": 1, "max_features": 0.55}),
                CandidateSpec("reg_hgb_matminer", task_type, "matminer", "hgb", {"max_iter": 260, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
                CandidateSpec("reg_lgbm_matminer", task_type, "matminer", "lgbm", {"n_estimators": 360, "learning_rate": 0.035, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                CandidateSpec("reg_lgbm_log_matminer", task_type, "matminer", "lgbm_log", {"n_estimators": 420, "learning_rate": 0.03, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.5}),
                CandidateSpec("reg_xgb_matminer", task_type, "matminer", "xgb", {"n_estimators": 320, "learning_rate": 0.035, "max_depth": 5, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                CandidateSpec("reg_xgb_log_matminer", task_type, "matminer", "xgb_log", {"n_estimators": 360, "learning_rate": 0.03, "max_depth": 5, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.5}),
                CandidateSpec("reg_lgbm_tier4_matminer_wide", task_type, "matminer_wide", "lgbm", {"n_estimators": 820, "learning_rate": 0.018, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.2}),
                CandidateSpec("reg_lgbm_tier4_log_matminer_wide", task_type, "matminer_wide", "lgbm_log", {"n_estimators": 900, "learning_rate": 0.016, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.6}),
                CandidateSpec("reg_xgb_tier4_matminer_wide", task_type, "matminer_wide", "xgb", {"n_estimators": 760, "learning_rate": 0.018, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.2}),
                CandidateSpec("reg_xgb_tier4_log_matminer_wide", task_type, "matminer_wide", "xgb_log", {"n_estimators": 820, "learning_rate": 0.016, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.6}),
                CandidateSpec("reg_vote_tier4_matminer_wide", task_type, "matminer_wide", "vote_lgbm_xgb_extra", {}),
                CandidateSpec("reg_vote_tier4_log_matminer_wide", task_type, "matminer_wide", "vote_lgbm_xgb_extra_log", {}),
                CandidateSpec("reg_extra_structure_matminer", task_type, "structure_matminer", "extra", {"n_estimators": 420, "min_samples_leaf": 1, "max_features": 0.55}),
                CandidateSpec("reg_lgbm_structure_matminer", task_type, "structure_matminer", "lgbm", {"n_estimators": 520, "learning_rate": 0.025, "num_leaves": 31, "subsample": 0.88, "colsample_bytree": 0.75, "reg_lambda": 1.2}),
                CandidateSpec("reg_xgb_structure_matminer", task_type, "structure_matminer", "xgb", {"n_estimators": 460, "learning_rate": 0.025, "max_depth": 4, "subsample": 0.88, "colsample_bytree": 0.75, "reg_lambda": 1.2}),
                CandidateSpec("reg_lgbm_log_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_log", {"n_estimators": 560, "learning_rate": 0.022, "num_leaves": 31, "subsample": 0.88, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                CandidateSpec("reg_lgbm_dielectric_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_dielectric", {"n_estimators": 620, "learning_rate": 0.02, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                CandidateSpec("reg_lgbm_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 620, "learning_rate": 0.02, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                CandidateSpec("reg_xgb_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "xgb_ll", {"n_estimators": 560, "learning_rate": 0.02, "max_depth": 4, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                CandidateSpec("reg_extra_ll_structure_matminer", task_type, "structure_matminer", "extra_ll", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.5}),
                CandidateSpec("reg_extra_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "extra_ll", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.42}),
                CandidateSpec("reg_extra_dielectric_structure_matminer", task_type, "structure_matminer", "extra_dielectric", {"n_estimators": 760, "min_samples_leaf": 1, "max_features": 0.5}),
                CandidateSpec("reg_vote_lgbm_extra_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "vote_lgbm_extra_ll", {}),
                CandidateSpec("reg_lgbm_ll_structure_matminer_wide_smooth", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 900, "learning_rate": 0.014, "num_leaves": 31, "subsample": 0.92, "colsample_bytree": 0.76, "reg_lambda": 2.0}),
                CandidateSpec("reg_lgbm_ll_structure_matminer_wide_deep", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 760, "learning_rate": 0.016, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.4}),
            ]
        candidates = [
            CandidateSpec("reg_rf_compact", task_type, "compact", "rf", {"n_estimators": 120, "min_samples_leaf": 2, "max_features": 0.75}),
            CandidateSpec("reg_extra_full", task_type, "full", "extra", {"n_estimators": 160, "min_samples_leaf": 1, "max_features": 0.9}),
            CandidateSpec("reg_hgb_full_l2", task_type, "full", "hgb", {"max_iter": 180, "learning_rate": 0.055, "l2_regularization": 0.05, "max_leaf_nodes": 31}),
            CandidateSpec("reg_ridge_full", task_type, "full", "ridge", {"alpha": 1.0}),
            CandidateSpec("reg_rf_full_deep", task_type, "full", "rf", {"n_estimators": 200, "min_samples_leaf": 1, "max_features": 1.0}),
            CandidateSpec("reg_extra_compact", task_type, "compact", "extra", {"n_estimators": 200, "min_samples_leaf": 2, "max_features": 1.0}),
            CandidateSpec("reg_hgb_compact_fast", task_type, "compact", "hgb", {"max_iter": 120, "learning_rate": 0.08, "l2_regularization": 0.0, "max_leaf_nodes": 15}),
            CandidateSpec("reg_ridge_compact", task_type, "compact", "ridge", {"alpha": 10.0}),
            CandidateSpec("reg_extra_structure", task_type, "structure", "extra", {"n_estimators": 220, "min_samples_leaf": 1, "max_features": 0.85}),
            CandidateSpec("reg_hgb_structure", task_type, "structure", "hgb", {"max_iter": 220, "learning_rate": 0.045, "l2_regularization": 0.01, "max_leaf_nodes": 31}),
            CandidateSpec("reg_extra_log_full", task_type, "full", "extra_log", {"n_estimators": 220, "min_samples_leaf": 1, "max_features": 0.9}),
            CandidateSpec("reg_extra_log_structure", task_type, "structure", "extra_log", {"n_estimators": 260, "min_samples_leaf": 1, "max_features": 0.85}),
            CandidateSpec("reg_hgb_log_full", task_type, "full", "hgb_log", {"max_iter": 220, "learning_rate": 0.045, "l2_regularization": 0.02, "max_leaf_nodes": 31}),
            CandidateSpec("reg_rf_log_full", task_type, "full", "rf_log", {"n_estimators": 220, "min_samples_leaf": 1, "max_features": 0.85}),
            CandidateSpec("reg_extra_wide", task_type, "wide", "extra", {"n_estimators": 260, "min_samples_leaf": 1, "max_features": 0.7}),
            CandidateSpec("reg_hgb_wide", task_type, "wide", "hgb", {"max_iter": 220, "learning_rate": 0.04, "l2_regularization": 0.02, "max_leaf_nodes": 31}),
            CandidateSpec("reg_extra_log_wide", task_type, "wide", "extra_log", {"n_estimators": 260, "min_samples_leaf": 1, "max_features": 0.7}),
            CandidateSpec("reg_hgb_log_wide", task_type, "wide", "hgb_log", {"max_iter": 240, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
        ]
        if candidate_library in rich_libraries:
            candidates.extend(
                [
                    CandidateSpec("reg_extra_matminer", task_type, "matminer", "extra", {"n_estimators": 320, "min_samples_leaf": 1, "max_features": 0.55}),
                    CandidateSpec("reg_rf_matminer", task_type, "matminer", "rf", {"n_estimators": 260, "min_samples_leaf": 1, "max_features": 0.55}),
                    CandidateSpec("reg_hgb_matminer", task_type, "matminer", "hgb", {"max_iter": 260, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
                    CandidateSpec("reg_extra_log_matminer", task_type, "matminer", "extra_log", {"n_estimators": 320, "min_samples_leaf": 1, "max_features": 0.55}),
                    CandidateSpec("reg_hgb_log_matminer", task_type, "matminer", "hgb_log", {"max_iter": 280, "learning_rate": 0.03, "l2_regularization": 0.04, "max_leaf_nodes": 31}),
                    CandidateSpec("reg_extra_matminer_wide", task_type, "matminer_wide", "extra", {"n_estimators": 360, "min_samples_leaf": 1, "max_features": 0.45}),
                ]
            )
        if candidate_library in expert_libraries:
            candidates.extend(
                [
                    CandidateSpec("reg_lgbm_matminer", task_type, "matminer", "lgbm", {"n_estimators": 360, "learning_rate": 0.035, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                    CandidateSpec("reg_lgbm_log_matminer", task_type, "matminer", "lgbm_log", {"n_estimators": 420, "learning_rate": 0.03, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.5}),
                    CandidateSpec("reg_lgbm_wide", task_type, "wide", "lgbm", {"n_estimators": 360, "learning_rate": 0.035, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                    CandidateSpec("reg_xgb_matminer", task_type, "matminer", "xgb", {"n_estimators": 320, "learning_rate": 0.035, "max_depth": 5, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                    CandidateSpec("reg_xgb_log_matminer", task_type, "matminer", "xgb_log", {"n_estimators": 360, "learning_rate": 0.03, "max_depth": 5, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.5}),
                ]
            )
        if candidate_library in open_libraries:
            candidates.extend(
                [
                    CandidateSpec("reg_lgbm_deep_matminer", task_type, "matminer", "lgbm", {"n_estimators": 520, "learning_rate": 0.025, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.7, "reg_lambda": 2.0}),
                    CandidateSpec("reg_lgbm_shallow_wide", task_type, "wide", "lgbm", {"n_estimators": 420, "learning_rate": 0.03, "num_leaves": 15, "subsample": 0.9, "colsample_bytree": 0.8, "reg_lambda": 1.0}),
                    CandidateSpec("reg_xgb_shallow_matminer", task_type, "matminer", "xgb", {"n_estimators": 460, "learning_rate": 0.025, "max_depth": 3, "subsample": 0.9, "colsample_bytree": 0.8, "reg_lambda": 2.0}),
                    CandidateSpec("reg_xgb_deep_wide", task_type, "wide", "xgb", {"n_estimators": 420, "learning_rate": 0.025, "max_depth": 6, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 2.0}),
                    CandidateSpec("reg_vote_lgbm_xgb_extra_matminer", task_type, "matminer", "vote_lgbm_xgb_extra", {}),
                    CandidateSpec("reg_vote_lgbm_xgb_hgb_wide", task_type, "wide", "vote_lgbm_xgb_hgb", {}),
                    CandidateSpec("reg_vote_log_lgbm_xgb_extra_matminer", task_type, "matminer", "vote_lgbm_xgb_extra_log", {}),
                ]
            )
        if candidate_library == "tier4":
            candidates.extend(
                [
                    CandidateSpec("reg_lgbm_tier4_matminer_wide", task_type, "matminer_wide", "lgbm", {"n_estimators": 820, "learning_rate": 0.018, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.2}),
                    CandidateSpec("reg_lgbm_tier4_log_matminer_wide", task_type, "matminer_wide", "lgbm_log", {"n_estimators": 900, "learning_rate": 0.016, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.6}),
                    CandidateSpec("reg_lgbm_tier4_smallleaf_matminer", task_type, "matminer", "lgbm", {"n_estimators": 760, "learning_rate": 0.018, "num_leaves": 15, "subsample": 0.92, "colsample_bytree": 0.8, "reg_lambda": 0.8}),
                    CandidateSpec("reg_xgb_tier4_matminer_wide", task_type, "matminer_wide", "xgb", {"n_estimators": 760, "learning_rate": 0.018, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.2}),
                    CandidateSpec("reg_xgb_tier4_log_matminer_wide", task_type, "matminer_wide", "xgb_log", {"n_estimators": 820, "learning_rate": 0.016, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.6}),
                    CandidateSpec("reg_xgb_tier4_shallow_wide", task_type, "wide", "xgb", {"n_estimators": 700, "learning_rate": 0.02, "max_depth": 3, "subsample": 0.92, "colsample_bytree": 0.85, "reg_lambda": 1.2}),
                    CandidateSpec("reg_extra_tier4_matminer_wide", task_type, "matminer_wide", "extra", {"n_estimators": 700, "min_samples_leaf": 1, "max_features": 0.42}),
                    CandidateSpec("reg_rf_tier4_matminer_wide", task_type, "matminer_wide", "rf", {"n_estimators": 620, "min_samples_leaf": 1, "max_features": 0.45}),
                    CandidateSpec("reg_vote_tier4_matminer_wide", task_type, "matminer_wide", "vote_lgbm_xgb_extra", {}),
                    CandidateSpec("reg_vote_tier4_log_matminer_wide", task_type, "matminer_wide", "vote_lgbm_xgb_extra_log", {}),
                    CandidateSpec("reg_extra_structure_matminer", task_type, "structure_matminer", "extra", {"n_estimators": 420, "min_samples_leaf": 1, "max_features": 0.55}),
                    CandidateSpec("reg_lgbm_structure_matminer", task_type, "structure_matminer", "lgbm", {"n_estimators": 520, "learning_rate": 0.025, "num_leaves": 31, "subsample": 0.88, "colsample_bytree": 0.75, "reg_lambda": 1.2}),
                    CandidateSpec("reg_xgb_structure_matminer", task_type, "structure_matminer", "xgb", {"n_estimators": 460, "learning_rate": 0.025, "max_depth": 4, "subsample": 0.88, "colsample_bytree": 0.75, "reg_lambda": 1.2}),
                    CandidateSpec("reg_lgbm_log_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_log", {"n_estimators": 560, "learning_rate": 0.022, "num_leaves": 31, "subsample": 0.88, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                    CandidateSpec("reg_lgbm_dielectric_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_dielectric", {"n_estimators": 620, "learning_rate": 0.02, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                    CandidateSpec("reg_lgbm_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 620, "learning_rate": 0.02, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                    CandidateSpec("reg_xgb_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "xgb_ll", {"n_estimators": 560, "learning_rate": 0.02, "max_depth": 4, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.5}),
                    CandidateSpec("reg_extra_ll_structure_matminer", task_type, "structure_matminer", "extra_ll", {"n_estimators": 520, "min_samples_leaf": 1, "max_features": 0.5}),
                    CandidateSpec("reg_extra_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "extra_ll", {"n_estimators": 900, "min_samples_leaf": 1, "max_features": 0.42}),
                    CandidateSpec("reg_extra_dielectric_structure_matminer", task_type, "structure_matminer", "extra_dielectric", {"n_estimators": 760, "min_samples_leaf": 1, "max_features": 0.5}),
                    CandidateSpec("reg_vote_ll_structure_matminer_wide", task_type, "structure_matminer_wide", "vote_lgbm_xgb_extra_ll", {}),
                    CandidateSpec("reg_lgbm_ll_structure_matminer_wide_smooth", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 900, "learning_rate": 0.014, "num_leaves": 31, "subsample": 0.92, "colsample_bytree": 0.76, "reg_lambda": 2.0}),
                    CandidateSpec("reg_lgbm_ll_structure_matminer_wide_deep", task_type, "structure_matminer_wide", "lgbm_ll", {"n_estimators": 760, "learning_rate": 0.016, "num_leaves": 63, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.4}),
                    CandidateSpec("reg_xgb_ll_structure_matminer_wide_deep", task_type, "structure_matminer_wide", "xgb_ll", {"n_estimators": 820, "learning_rate": 0.016, "max_depth": 5, "subsample": 0.9, "colsample_bytree": 0.72, "reg_lambda": 1.4}),
                ]
            )
        return candidates
    candidates = [
        CandidateSpec("clf_rf_compact", task_type, "compact", "rf", {"n_estimators": 160, "min_samples_leaf": 2, "max_features": 0.75}),
        CandidateSpec("clf_extra_full", task_type, "full", "extra", {"n_estimators": 200, "min_samples_leaf": 1, "max_features": 0.9}),
        CandidateSpec("clf_hgb_full_l2", task_type, "full", "hgb", {"max_iter": 180, "learning_rate": 0.055, "l2_regularization": 0.05, "max_leaf_nodes": 31}),
        CandidateSpec("clf_logreg_full", task_type, "full", "logreg", {"C": 1.0}),
        CandidateSpec("clf_rf_full_deep", task_type, "full", "rf", {"n_estimators": 220, "min_samples_leaf": 1, "max_features": 1.0}),
        CandidateSpec("clf_extra_compact", task_type, "compact", "extra", {"n_estimators": 220, "min_samples_leaf": 2, "max_features": 1.0}),
        CandidateSpec("clf_hgb_compact_fast", task_type, "compact", "hgb", {"max_iter": 120, "learning_rate": 0.08, "l2_regularization": 0.0, "max_leaf_nodes": 15}),
        CandidateSpec("clf_logreg_compact", task_type, "compact", "logreg", {"C": 0.2}),
        CandidateSpec("clf_extra_structure", task_type, "structure", "extra", {"n_estimators": 240, "min_samples_leaf": 1, "max_features": 0.85}),
        CandidateSpec("clf_hgb_structure", task_type, "structure", "hgb", {"max_iter": 220, "learning_rate": 0.045, "l2_regularization": 0.01, "max_leaf_nodes": 31}),
    ]
    if candidate_library in rich_libraries:
        candidates.extend(
            [
                CandidateSpec("clf_extra_matminer", task_type, "matminer", "extra", {"n_estimators": 300, "min_samples_leaf": 1, "max_features": 0.55}),
                CandidateSpec("clf_rf_matminer", task_type, "matminer", "rf", {"n_estimators": 260, "min_samples_leaf": 1, "max_features": 0.55}),
                CandidateSpec("clf_hgb_matminer", task_type, "matminer", "hgb", {"max_iter": 240, "learning_rate": 0.035, "l2_regularization": 0.03, "max_leaf_nodes": 31}),
            ]
        )
    if candidate_library in expert_libraries:
        candidates.extend(
            [
                CandidateSpec("clf_lgbm_matminer", task_type, "matminer", "lgbm", {"n_estimators": 320, "learning_rate": 0.035, "num_leaves": 31, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                CandidateSpec("clf_xgb_matminer", task_type, "matminer", "xgb", {"n_estimators": 300, "learning_rate": 0.035, "max_depth": 5, "subsample": 0.85, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
            ]
        )
    if candidate_library in open_libraries:
        candidates.extend(
            [
                CandidateSpec("clf_lgbm_shallow_matminer", task_type, "matminer", "lgbm", {"n_estimators": 420, "learning_rate": 0.025, "num_leaves": 15, "subsample": 0.9, "colsample_bytree": 0.8, "reg_lambda": 1.0}),
                CandidateSpec("clf_xgb_shallow_matminer", task_type, "matminer", "xgb", {"n_estimators": 360, "learning_rate": 0.025, "max_depth": 3, "subsample": 0.9, "colsample_bytree": 0.8, "reg_lambda": 1.5}),
                CandidateSpec("clf_vote_lgbm_xgb_extra_matminer", task_type, "matminer", "vote_lgbm_xgb_extra", {}),
            ]
        )
    if candidate_library == "tier4":
        candidates.extend(
            [
                CandidateSpec("clf_lgbm_tier4_matminer_wide", task_type, "matminer_wide", "lgbm", {"n_estimators": 640, "learning_rate": 0.02, "num_leaves": 31, "subsample": 0.9, "colsample_bytree": 0.75, "reg_lambda": 1.0}),
                CandidateSpec("clf_xgb_tier4_matminer_wide", task_type, "matminer_wide", "xgb", {"n_estimators": 560, "learning_rate": 0.02, "max_depth": 4, "subsample": 0.9, "colsample_bytree": 0.75, "reg_lambda": 1.2}),
                CandidateSpec("clf_vote_tier4_matminer_wide", task_type, "matminer_wide", "vote_lgbm_xgb_extra", {}),
            ]
        )
    return candidates


def signed_log1p(values):
    arr = np.asarray(values, dtype=float)
    return np.sign(arr) * np.log1p(np.abs(arr))


def signed_expm1(values):
    arr = np.asarray(values, dtype=float)
    return np.sign(arr) * np.expm1(np.abs(arr))


def dielectric_square(values):
    arr = np.asarray(values, dtype=float)
    return np.square(np.maximum(arr, 0.0))


def dielectric_sqrt(values):
    arr = np.asarray(values, dtype=float)
    return np.sqrt(np.maximum(arr, 0.0))


def lorentz_lorenz(values):
    arr = np.asarray(values, dtype=float)
    n2 = np.square(np.maximum(arr, 1e-8))
    return (n2 - 1.0) / (n2 + 2.0)


def inv_dielectric_square(values):
    arr = np.asarray(values, dtype=float)
    return np.sqrt(np.maximum(arr, 0.0))


def inv_dielectric_sqrt(values):
    arr = np.asarray(values, dtype=float)
    return np.square(np.maximum(arr, 0.0))


def inv_lorentz_lorenz(values):
    arr = np.clip(np.asarray(values, dtype=float), -0.499, 0.985)
    n2 = (1.0 + 2.0 * arr) / np.maximum(1.0 - arr, 1e-8)
    return np.sqrt(np.maximum(n2, 0.0))


def make_regression_pipeline(model: str, params: dict[str, Any], seed: int):
    if model == "rf":
        return make_pipeline(SimpleImputer(), RandomForestRegressor(random_state=seed, n_jobs=N_JOBS, **params))
    if model == "extra":
        return make_pipeline(SimpleImputer(), ExtraTreesRegressor(random_state=seed, n_jobs=N_JOBS, **params))
    if model == "hgb":
        return make_pipeline(SimpleImputer(), HistGradientBoostingRegressor(random_state=seed, **params))
    if model == "ridge":
        return make_pipeline(SimpleImputer(), StandardScaler(), Ridge(random_state=seed, **params))
    if model == "lgbm":
        if LGBMRegressor is None:
            raise ValueError("LightGBM is not installed.")
        return make_pipeline(SimpleImputer(), LGBMRegressor(random_state=seed, n_jobs=N_JOBS, verbose=-1, **params))
    if model == "xgb":
        if XGBRegressor is None:
            raise ValueError("XGBoost is not installed.")
        return make_pipeline(SimpleImputer(), XGBRegressor(random_state=seed, n_jobs=N_JOBS, objective="reg:squarederror", verbosity=0, **params))
    if model in {"vote_lgbm_xgb_extra", "vote_lgbm_xgb_hgb", "vote_lgbm_extra"}:
        if LGBMRegressor is None:
            raise ValueError("LightGBM is required for open-knowledge voting candidates.")
        if model != "vote_lgbm_extra" and XGBRegressor is None:
            raise ValueError("XGBoost is required for this open-knowledge voting candidate.")
        estimators: list[tuple[str, Any]] = [
            (
                "lgbm",
                LGBMRegressor(
                    random_state=stable_seed(seed, "vote", "lgbm"),
                    n_jobs=N_JOBS,
                    verbose=-1,
                    n_estimators=420,
                    learning_rate=0.03,
                    num_leaves=31,
                    subsample=0.85,
                    colsample_bytree=0.75,
                    reg_lambda=1.5,
                ),
            )
        ]
        if model != "vote_lgbm_extra":
            estimators.append(
                (
                    "xgb",
                    XGBRegressor(
                        random_state=stable_seed(seed, "vote", "xgb"),
                        n_jobs=N_JOBS,
                        objective="reg:squarederror",
                        verbosity=0,
                        n_estimators=360,
                        learning_rate=0.03,
                        max_depth=5,
                        subsample=0.85,
                        colsample_bytree=0.75,
                        reg_lambda=1.5,
                    ),
                )
            )
        if model in {"vote_lgbm_xgb_extra", "vote_lgbm_extra"}:
            estimators.append(
                (
                    "extra",
                    ExtraTreesRegressor(
                        random_state=stable_seed(seed, "vote", "extra"),
                        n_jobs=N_JOBS,
                        n_estimators=360,
                        min_samples_leaf=1,
                        max_features=0.55,
                    ),
                )
            )
        else:
            estimators.append(
                (
                    "hgb",
                    HistGradientBoostingRegressor(
                        random_state=stable_seed(seed, "vote", "hgb"),
                        max_iter=280,
                        learning_rate=0.03,
                        l2_regularization=0.04,
                        max_leaf_nodes=31,
                    ),
                )
            )
        return make_pipeline(SimpleImputer(), VotingRegressor(estimators=estimators, n_jobs=1))
    raise ValueError(f"Unsupported regression model: {model}")


def make_estimator(spec: CandidateSpec, seed: int):
    params = dict(spec.params)
    if spec.task_type == "regression":
        transform = None
        model = spec.model
        for suffix, pair in (
            ("_log", (signed_log1p, signed_expm1)),
            ("_dielectric", (dielectric_square, inv_dielectric_square)),
            ("_sqrt", (dielectric_sqrt, inv_dielectric_sqrt)),
            ("_ll", (lorentz_lorenz, inv_lorentz_lorenz)),
        ):
            if model.endswith(suffix):
                model = model.removesuffix(suffix)
                transform = pair
                break
        estimator = make_regression_pipeline(model, params, seed)
        if transform is not None:
            return TransformedTargetRegressor(
                regressor=estimator,
                func=transform[0],
                inverse_func=transform[1],
                check_inverse=False,
            )
        return estimator
    else:
        if spec.model == "rf":
            return make_pipeline(SimpleImputer(), RandomForestClassifier(random_state=seed, n_jobs=N_JOBS, class_weight="balanced", **params))
        if spec.model == "extra":
            return make_pipeline(SimpleImputer(), ExtraTreesClassifier(random_state=seed, n_jobs=N_JOBS, class_weight="balanced", **params))
        if spec.model == "hgb":
            return make_pipeline(SimpleImputer(), HistGradientBoostingClassifier(random_state=seed, **params))
        if spec.model == "logreg":
            return make_pipeline(SimpleImputer(), StandardScaler(), LogisticRegression(random_state=seed, max_iter=2000, class_weight="balanced", **params))
        if spec.model == "lgbm":
            if LGBMClassifier is None:
                raise ValueError("LightGBM is not installed.")
            return make_pipeline(SimpleImputer(), LGBMClassifier(random_state=seed, n_jobs=N_JOBS, verbose=-1, **params))
        if spec.model == "xgb":
            if XGBClassifier is None:
                raise ValueError("XGBoost is not installed.")
            return make_pipeline(SimpleImputer(), XGBClassifier(random_state=seed, n_jobs=N_JOBS, objective="binary:logistic", eval_metric="logloss", verbosity=0, **params))
        if spec.model == "vote_lgbm_xgb_extra":
            if LGBMClassifier is None or XGBClassifier is None:
                raise ValueError("LightGBM and XGBoost are required for open-knowledge voting candidates.")
            estimators = [
                (
                    "lgbm",
                    LGBMClassifier(
                        random_state=stable_seed(seed, "vote", "lgbm"),
                        n_jobs=N_JOBS,
                        verbose=-1,
                        n_estimators=360,
                        learning_rate=0.03,
                        num_leaves=31,
                        subsample=0.85,
                        colsample_bytree=0.75,
                        reg_lambda=1.0,
                    ),
                ),
                (
                    "xgb",
                    XGBClassifier(
                        random_state=stable_seed(seed, "vote", "xgb"),
                        n_jobs=N_JOBS,
                        objective="binary:logistic",
                        eval_metric="logloss",
                        verbosity=0,
                        n_estimators=320,
                        learning_rate=0.03,
                        max_depth=5,
                        subsample=0.85,
                        colsample_bytree=0.75,
                        reg_lambda=1.0,
                    ),
                ),
                (
                    "extra",
                    ExtraTreesClassifier(
                        random_state=stable_seed(seed, "vote", "extra"),
                        n_jobs=N_JOBS,
                        class_weight="balanced",
                        n_estimators=300,
                        min_samples_leaf=1,
                        max_features=0.55,
                    ),
                ),
            ]
            return make_pipeline(SimpleImputer(), VotingClassifier(estimators=estimators, voting="soft", n_jobs=1))
    raise ValueError(f"Unsupported candidate spec: {spec}")


def maybe_subsample(x, y, max_train: int | None, seed: int):
    if not max_train or len(y) <= max_train:
        return x, y
    rng = np.random.default_rng(seed)
    idx = np.asarray(rng.choice(len(y), size=max_train, replace=False))
    if hasattr(x, "iloc"):
        x_sub = x.iloc[idx]
    else:
        x_sub = [x[int(i)] for i in idx]
    if hasattr(y, "iloc"):
        y_sub = y.iloc[idx]
    else:
        y_sub = np.asarray(y)[idx]
    return x_sub, y_sub


def inner_split(x, y, task_type: str, seed: int):
    y_arr = np.asarray(y)
    stratify = None
    if task_type == "classification":
        values, counts = np.unique(y_arr, return_counts=True)
        if len(values) == 2 and np.min(counts) >= 4:
            stratify = y_arr
    return train_test_split(
        x,
        y,
        test_size=0.22,
        random_state=seed,
        shuffle=True,
        stratify=stratify,
    )


def validation_loss(y_true, y_pred, task_type: str, scale: float) -> tuple[float, dict[str, float]]:
    if task_type == "regression":
        mae = float(mean_absolute_error(y_true, y_pred))
        return mae / max(scale, 1e-12), {"mae": mae, "normalized_mae": mae / max(scale, 1e-12)}
    y_true_arr = np.asarray(y_true).astype(bool)
    y_pred_arr = np.asarray(y_pred, dtype=float)
    try:
        auc = float(roc_auc_score(y_true_arr, y_pred_arr))
    except Exception:
        auc = 0.5
    return 1.0 - auc, {"rocauc": auc, "auc_loss": 1.0 - auc}


def predict_for_task(estimator, x_test, task_type: str):
    if task_type == "classification":
        if hasattr(estimator, "predict_proba"):
            probs = estimator.predict_proba(x_test)
            if probs.ndim == 2 and probs.shape[1] > 1:
                return np.asarray(probs[:, 1], dtype=float)
        pred = estimator.predict(x_test)
        return np.asarray(pred, dtype=float)
    return np.asarray(estimator.predict(x_test), dtype=float)


def evaluate_candidate(
    spec: CandidateSpec,
    x_train,
    y_train,
    x_val,
    y_val,
    task_type: str,
    seed: int,
    scale: float,
    feature_cache: dict[tuple[int, str], np.ndarray] | None = None,
) -> tuple[float, dict[str, float], str | None]:
    try:
        if feature_cache is None:
            xtr = featurize_many(x_train, spec.feature_mode)
            xva = featurize_many(x_val, spec.feature_mode)
        else:
            train_key = (id(x_train), spec.feature_mode)
            val_key = (id(x_val), spec.feature_mode)
            if train_key not in feature_cache:
                feature_cache[train_key] = featurize_many(x_train, spec.feature_mode)
            if val_key not in feature_cache:
                feature_cache[val_key] = featurize_many(x_val, spec.feature_mode)
            xtr = feature_cache[train_key]
            xva = feature_cache[val_key]
        estimator = make_estimator(spec, seed)
        estimator.fit(xtr, np.asarray(y_train))
        pred = predict_for_task(estimator, xva, task_type)
        loss, metrics = validation_loss(y_val, pred, task_type, scale)
        return float(loss), metrics, None
    except Exception as exc:
        return float("inf"), {}, f"{type(exc).__name__}: {exc}"


def fit_predict_selected(
    spec: CandidateSpec,
    x_train,
    y_train,
    x_test,
    task_type: str,
    seed: int,
):
    xtr = featurize_many(x_train, spec.feature_mode)
    xte = featurize_many(x_test, spec.feature_mode)
    estimator = make_estimator(spec, seed)
    estimator.fit(xtr, np.asarray(y_train))
    return predict_for_task(estimator, xte, task_type)


def target_scale(y) -> float:
    arr = np.asarray(y, dtype=float)
    if arr.size <= 1:
        return 1.0
    med = float(np.median(arr))
    mad = float(np.median(np.abs(arr - med)))
    std = float(np.std(arr))
    return max(mad, std, 1e-8)


def candidate_search(
    candidates: list[CandidateSpec],
    x_train_val,
    y_train_val,
    task_type: str,
    seed: int,
    max_train: int | None,
    archive: list[dict[str, Any]],
    context: dict[str, Any],
    default_candidate: CandidateSpec | None = None,
    guardrail_margin: float = 0.0,
) -> tuple[CandidateSpec, float]:
    x_sub, y_sub = maybe_subsample(x_train_val, y_train_val, max_train, seed)
    split = inner_split(x_sub, y_sub, task_type, seed)
    x_train, x_val, y_train, y_val = split
    scale = target_scale(y_train)
    best_spec = candidates[0]
    best_loss = float("inf")
    losses_by_id: dict[str, float] = {}
    feature_cache: dict[tuple[int, str], np.ndarray] = {}
    for rank, spec in enumerate(candidates):
        loss, metrics, error = evaluate_candidate(
            spec,
            x_train,
            y_train,
            x_val,
            y_val,
            task_type,
            stable_seed(seed, spec.candidate_id),
            scale,
            feature_cache,
        )
        losses_by_id[spec.candidate_id] = loss
        archive.append(
            {
                **context,
                "phase": "target_validation",
                "candidate_rank": rank,
                "candidate": asdict(spec),
                "validation_loss": loss,
                "validation_metrics": metrics,
                "error": error,
            }
        )
        if loss < best_loss:
            best_loss = loss
            best_spec = spec
    if default_candidate is not None and guardrail_margin > 0:
        default_loss = losses_by_id.get(default_candidate.candidate_id)
        if default_loss is not None and math.isfinite(default_loss):
            required_loss = default_loss * (1.0 - guardrail_margin)
            if best_spec.candidate_id != default_candidate.candidate_id and best_loss >= required_loss:
                archive.append(
                    {
                        **context,
                        "phase": "source_guardrail",
                        "guardrail_margin": guardrail_margin,
                        "default_candidate": asdict(default_candidate),
                        "default_validation_loss": default_loss,
                        "target_best_candidate": asdict(best_spec),
                        "target_best_validation_loss": best_loss,
                        "selected_candidate": asdict(default_candidate),
                    }
                )
                return default_candidate, default_loss
    return best_spec, best_loss


def source_prior_order(
    target_task_name: str,
    target_task_type: str,
    source_tasks: list[str],
    fold: int,
    candidates: list[CandidateSpec],
    seed: int,
    max_train: int | None,
    archive: list[dict[str, Any]],
) -> list[CandidateSpec]:
    source_losses: dict[str, list[float]] = {spec.candidate_id: [] for spec in candidates}
    for source_name in source_tasks:
        source_task = MatbenchTask(source_name, autoload=True)
        if source_task.metadata.task_type != target_task_type:
            continue
        x_source, y_source = source_task.get_train_and_val_data(fold)
        x_sub, y_sub = maybe_subsample(x_source, y_source, max_train, stable_seed(seed, "source", source_name, fold))
        x_train, x_val, y_train, y_val = inner_split(x_sub, y_sub, target_task_type, stable_seed(seed, "source_split", source_name, fold))
        scale = target_scale(y_train)
        feature_cache: dict[tuple[int, str], np.ndarray] = {}
        for spec in candidates:
            loss, metrics, error = evaluate_candidate(
                spec,
                x_train,
                y_train,
                x_val,
                y_val,
                target_task_type,
                stable_seed(seed, "source_candidate", source_name, fold, spec.candidate_id),
                scale,
                feature_cache,
            )
            if math.isfinite(loss):
                source_losses[spec.candidate_id].append(loss)
            archive.append(
                {
                    "phase": "source_prior",
                    "target_task": target_task_name,
                    "source_task": source_name,
                    "fold": fold,
                    "candidate": asdict(spec),
                    "source_validation_loss": loss,
                    "source_validation_metrics": metrics,
                    "error": error,
                }
            )

    def score(spec: CandidateSpec) -> tuple[float, str]:
        losses = source_losses[spec.candidate_id]
        if not losses:
            return (float("inf"), spec.candidate_id)
        return (float(np.mean(losses)), spec.candidate_id)

    return sorted(candidates, key=score)


def run_one_fold(
    task_name: str,
    fold: int,
    all_task_names: list[str],
    args: argparse.Namespace,
    archive: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    task = MatbenchTask(task_name, autoload=True)
    task_type = task.metadata.task_type
    candidates_all = all_candidates(task_type, args.candidate_library)
    target_library = args.target_candidate_library or args.candidate_library
    target_candidates_all = all_candidates(task_type, target_library)
    target_budget = min(args.target_budget, len(target_candidates_all))
    cross_target_budget = min(args.target_budget, len(candidates_all))
    source_budget = min(args.source_budget, len(candidates_all))
    target_candidates = target_candidates_all[:target_budget]
    source_candidates = candidates_all[:source_budget]
    x_train_val, y_train_val = task.get_train_and_val_data(fold)
    x_test = task.get_test_data(fold)
    x_fit, y_fit = maybe_subsample(
        x_train_val,
        y_train_val,
        args.max_train,
        stable_seed(args.master_seed, task_name, fold, "fit"),
    )
    final_scale = target_scale(y_train_val)
    source_tasks = [name for name in all_task_names if name != task_name]
    prior_order = source_prior_order(
        task_name,
        task_type,
        source_tasks,
        fold,
        source_candidates,
        stable_seed(args.master_seed, task_name, fold, "source_prior"),
        args.max_source_train or args.max_train,
        archive,
    )
    prior_ids = {spec.candidate_id for spec in prior_order}
    cross_order = prior_order + [spec for spec in candidates_all if spec.candidate_id not in prior_ids]
    cross_candidates = cross_order[:cross_target_budget]

    selected: dict[str, tuple[CandidateSpec, float, str]] = {}
    selected["target_only_one_shot"] = (target_candidates_all[0], float("nan"), "fixed_default")
    selected["target_only_self_improving"] = (
        *candidate_search(
            target_candidates,
            x_train_val,
            y_train_val,
            task_type,
            stable_seed(args.master_seed, task_name, fold, "target_self"),
            args.max_train,
            archive,
            {"arm": "target_only_self_improving", "task": task_name, "fold": fold},
        ),
        "target_validation",
    )
    selected["cross_domain_one_shot"] = (cross_order[0], float("nan"), "source_prior")
    selected["cross_domain_self_improving"] = (
        *candidate_search(
            cross_candidates,
            x_train_val,
            y_train_val,
            task_type,
            stable_seed(args.master_seed, task_name, fold, "cross_self"),
            args.max_train,
            archive,
            {"arm": "cross_domain_self_improving", "task": task_name, "fold": fold},
            default_candidate=cross_order[0],
            guardrail_margin=args.cross_update_margin,
        ),
        "source_prior_then_guarded_target_validation" if args.cross_update_margin > 0 else "source_prior_then_target_validation",
    )

    records: list[dict[str, Any]] = []
    for arm in ARM_ORDER:
        spec, validation_loss_value, selection_rule = selected[arm]
        predictions = fit_predict_selected(
            spec,
            x_fit,
            y_fit,
            x_test,
            task_type,
            stable_seed(args.master_seed, task_name, fold, arm, spec.candidate_id, "final"),
        )
        score_task = MatbenchTask(task_name, autoload=True)
        score_task.record(fold, predictions, params={"arm": arm, "candidate": asdict(spec)})
        fold_key = score_task.folds_map[fold]
        scores = dict(score_task.results[fold_key].scores)
        primary = PRIMARY_METRIC[task_type]
        primary_value = float(scores[primary])
        if task_type == "regression":
            utility = -primary_value / max(final_scale, 1e-12)
            loss = -utility
        else:
            utility = primary_value
            loss = 1.0 - primary_value
        records.append(
            {
                "task": task_name,
                "fold": fold,
                "arm": arm,
                "arm_label": ARM_LABELS[arm],
                "task_type": task_type,
                "input_type": task.metadata.input_type,
                "primary_metric": primary,
                "primary_value": primary_value,
                "utility": utility,
                "loss": loss,
                "selection_validation_loss": validation_loss_value,
                "selection_rule": selection_rule,
                "candidate_id": spec.candidate_id,
                "feature_mode": spec.feature_mode,
                "model": spec.model,
                "params": json.dumps(spec.params, sort_keys=True),
                **{f"score_{key}": float(value) for key, value in scores.items()},
            }
        )
    return records


def summarize(records: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    df = pd.DataFrame(records)
    rank_rows = []
    for (task, fold), group in df.groupby(["task", "fold"], sort=False):
        group = group.copy()
        group["rank"] = group["utility"].rank(ascending=False, method="average")
        for _, row in group.iterrows():
            rank_rows.append({"task": task, "fold": fold, "arm": row["arm"], "rank": float(row["rank"])})
    rank_df = pd.DataFrame(rank_rows)
    summary_rows = []
    for arm in ARM_ORDER:
        g = df[df["arm"] == arm]
        ranks = rank_df[rank_df["arm"] == arm]["rank"]
        summary_rows.append(
            {
                "arm": arm,
                "arm_label": ARM_LABELS[arm],
                "n_folds": int(len(g)),
                "mean_utility": float(g["utility"].mean()),
                "se_utility": float(g["utility"].std(ddof=1) / math.sqrt(len(g))) if len(g) > 1 else 0.0,
                "mean_rank": float(ranks.mean()),
                "se_rank": float(ranks.std(ddof=1) / math.sqrt(len(ranks))) if len(ranks) > 1 else 0.0,
            }
        )

    wide = df.pivot_table(index=["task", "fold"], columns="arm", values="utility", aggfunc="first")
    contrast_specs = [
        ("target_self_minus_target_one_shot", "target_only_self_improving", "target_only_one_shot"),
        ("cross_self_minus_target_self", "cross_domain_self_improving", "target_only_self_improving"),
        ("cross_self_minus_cross_one_shot", "cross_domain_self_improving", "cross_domain_one_shot"),
        ("cross_self_minus_target_one_shot", "cross_domain_self_improving", "target_only_one_shot"),
    ]
    contrast_rows = []
    for name, better, worse in contrast_specs:
        diff = (wide[better] - wide[worse]).dropna()
        contrast_rows.append(
            {
                "contrast": name,
                "mean_utility_difference": float(diff.mean()),
                "se_utility_difference": float(diff.std(ddof=1) / math.sqrt(len(diff))) if len(diff) > 1 else 0.0,
                "paired_win_rate": float((diff > 0).mean()) if len(diff) else float("nan"),
                "n_pairs": int(len(diff)),
            }
        )

    by_task_rows = []
    for (task, arm), group in df.groupby(["task", "arm"], sort=False):
        by_task_rows.append(
            {
                "task": task,
                "arm": arm,
                "arm_label": ARM_LABELS[arm],
                "n_folds": int(len(group)),
                "mean_utility": float(group["utility"].mean()),
                "mean_primary_value": float(group["primary_value"].mean()),
                "primary_metric": str(group["primary_metric"].iloc[0]),
            }
        )
    return summary_rows, contrast_rows, by_task_rows


def write_latex(summary: list[dict[str, Any]], contrasts: list[dict[str, Any]], results_dir: Path) -> None:
    lines = [
        "% Auto-generated by run_matbench_experiment.py",
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Fixed public-fold Matbench validation. Utility is negative normalized mean absolute error, so larger utility is better; lower mean rank is better. Entries are mean $\\pm$ standard error (SE) across the task-fold evaluations.}",
        "\\label{tab:matbench_summary}",
        "\\begin{tabular}{lccc}",
        "\\toprule",
        "Arm & Folds & Mean utility & Mean rank \\\\",
        "\\midrule",
    ]
    for row in summary:
        lines.append(
            f"{row['arm_label']} & {row['n_folds']} & "
            f"{row['mean_utility']:.3f} $\\pm$ {row['se_utility']:.3f} & "
            f"{row['mean_rank']:.2f} $\\pm$ {row['se_rank']:.2f} \\\\"
        )
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{table}", ""]
    lines += [
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Paired Matbench utility contrasts across tasks and folds. Positive differences favor the first arm. Differences are paired mean $\\pm$ standard error (SE) across task-fold evaluations; win rate is the percentage of task-fold pairs favoring the first arm.}",
        "\\label{tab:matbench_contrasts}",
        "\\begin{tabular}{lcc}",
        "\\toprule",
        "Contrast & Difference & Win rate \\\\",
        "\\midrule",
    ]
    for row in contrasts:
        label = str(row["contrast"]).replace("_", " ")
        lines.append(
            f"{label} & {row['mean_utility_difference']:.3f} $\\pm$ "
            f"{row['se_utility_difference']:.3f} & {100 * row['paired_win_rate']:.1f}\\% \\\\"
        )
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{table}"]
    (results_dir / "latex_tables.tex").write_text("\n".join(lines) + "\n")


def write_plot(summary: list[dict[str, Any]], results_dir: Path) -> None:
    plots = results_dir / "plots"
    plots.mkdir(parents=True, exist_ok=True)
    labels = [row["arm_label"] for row in summary]
    ranks = [row["mean_rank"] for row in summary]
    errors = [row["se_rank"] for row in summary]
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    ax.bar(range(len(labels)), ranks, yerr=errors, color=["#6c757d", "#4c78a8", "#f58518", "#54a24b"], capsize=4)
    ax.set_xticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=18, ha="right")
    ax.set_ylabel("Mean rank (lower is better)")
    ax.set_title("Fixed official-fold Matbench pilot")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(plots / "arm_mean_rank.pdf")
    fig.savefig(plots / "arm_mean_rank.png", dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", default="matbench_steels,matbench_glass,matbench_expt_gap,matbench_expt_is_metal")
    parser.add_argument("--folds", default="0,1,2,3,4")
    parser.add_argument("--target-budget", type=int, default=8)
    parser.add_argument("--source-budget", type=int, default=8)
    parser.add_argument("--max-train", type=int, default=5000)
    parser.add_argument("--max-source-train", type=int, default=None)
    parser.add_argument("--master-seed", type=int, default=20260605)
    parser.add_argument("--cross-update-margin", type=float, default=0.0)
    parser.add_argument("--source-tasks", default=None, help="Optional comma-separated source-task pool used only for cross-domain ranking.")
    parser.add_argument("--candidate-library", choices=("base", "expanded", "expert_included", "open_knowledge", "tier4", "tier4_shortlist", "dielectric_focus", "uniform_transfer"), default="base")
    parser.add_argument("--target-candidate-library", choices=("base", "expanded", "expert_included", "open_knowledge", "tier4", "tier4_shortlist", "dielectric_focus", "uniform_transfer"), default=None)
    parser.add_argument("--output-dir", default=str(DEFAULT_RESULTS))
    args = parser.parse_args()

    tasks = parse_csv(args.tasks)
    source_tasks = parse_csv(args.source_tasks, tasks)
    folds = parse_ints(args.folds)
    results_dir = output_dir(args.output_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    (results_dir / "plots").mkdir(exist_ok=True)

    started = time.time()
    records: list[dict[str, Any]] = []
    archive: list[dict[str, Any]] = []
    for task_name in tasks:
        for fold in folds:
            print(f"[matbench] task={task_name} fold={fold}", flush=True)
            records.extend(run_one_fold(task_name, fold, source_tasks, args, archive))

    summary, contrasts, by_task = summarize(records)
    write_csv(results_dir / "records.csv", records, union_fieldnames(records))
    write_jsonl(results_dir / "records.jsonl", records)
    write_jsonl(results_dir / "candidate_archive.jsonl", archive)
    write_csv(results_dir / "summary.csv", summary, list(summary[0].keys()) if summary else [])
    write_csv(results_dir / "contrasts.csv", contrasts, list(contrasts[0].keys()) if contrasts else [])
    write_csv(results_dir / "by_task.csv", by_task, list(by_task[0].keys()) if by_task else [])
    write_latex(summary, contrasts, results_dir)
    write_plot(summary, results_dir)
    manifest = {
        "protocol": "sealed official-fold Matbench evaluation; public labels; not a hidden benchmark",
        "args": vars(args),
        "tasks": tasks,
        "source_tasks": source_tasks,
        "folds": folds,
        "arms": ARM_ORDER,
        "candidate_library": args.candidate_library,
        "target_candidate_library": args.target_candidate_library or args.candidate_library,
        "elapsed_seconds": time.time() - started,
        "python": sys.version,
        "platform": platform.platform(),
        "notes": [
            "Model selection uses only official train folds via deterministic inner validation.",
            "Official test-fold labels are accessed only by MatbenchTask.record after predictions are made.",
            "Cross-domain arms use candidate rankings learned from other selected Matbench tasks of the same task type.",
            "The expanded candidate library adds matminer composition descriptors and stronger tree/boosting candidates, selected only by source and target training-fold validation.",
            "The expert_included library additionally adds LightGBM and XGBoost candidates inspired by public expert/AutoML materials-prediction practice.",
            "The open_knowledge library additionally adds boosted-tree variants and same-feature voting ensembles generated from the frozen public materials-informatics knowledge plan; no outer-fold labels or leaderboard values are used for selection.",
            "The tier4 library keeps the open-knowledge candidates and adds stronger boosted-tree, forest, and voting candidates; it is intended for focused expert-reference stress tests with a larger finite update budget.",
            "The tier4_shortlist library is a focused expert-level subset of boosted-tree, forest, and voting candidates designed to complete the same stress test under a shorter walltime budget.",
            "The uniform_transfer library applies the same public-knowledge boosted-tree, forest, structure, and ensemble candidate menu to every regression task; it excludes dielectric-only target transformations.",
            "When --target-candidate-library differs from --candidate-library, target-only arms search the target library while cross-domain arms search the source-informed library; this is a library-expansion stress test, not a same-policy-class ablation.",
        ],
    }
    write_json(results_dir / "manifest.json", manifest)
    print(f"[matbench] wrote {results_dir}")


if __name__ == "__main__":
    main()

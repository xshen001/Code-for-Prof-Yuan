#!/usr/bin/env python3
"""Curator-seeded hidden-resampling Matbench foundation-stack audit.

This script is meant for a non-author final validation layer. It uses public
Matbench labeled records, but creates secret-seed train/test splits after the
protocol is fixed. Candidate selection uses only the resampled training part
and inner validation splits. The resampled test labels are scored only after
the arm output has been selected and refit on the resampled training part.

This is not an official Matbench leaderboard run. It is a hidden-resampling
check of the four agent arms plus one declared expert-style reference rule
under the same secret resampled train/test splits.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
from matbench.task import MatbenchTask
from sklearn.model_selection import train_test_split

from run_matbench_chgnet_foundation_stack import (
    build_feature_blocks,
    chgnet_specs,
    fit_predict_spec,
    parse_float_grid,
    predict_choice,
    select_cross,
    select_target,
    target_specs,
)
from run_matbench_experiment import (
    ARM_LABELS,
    ARM_ORDER,
    PRIMARY_METRIC,
    stable_seed,
    target_scale,
    union_fieldnames,
    validation_loss,
    write_csv,
    write_json,
    write_jsonl,
)


ROOT = Path(__file__).resolve().parent
DEFAULT_RESULTS = ROOT / "results_hidden_resampling_chgnet_foundation_stack"
EXPERT_ARM = "expert_reference"
EXPERT_LABEL = "Declared expert-style reference"
EVAL_ARM_ORDER = list(ARM_ORDER) + [EXPERT_ARM]
EVAL_ARM_LABELS = {**ARM_LABELS, EXPERT_ARM: EXPERT_LABEL}
DEFAULT_EXPERT_CANDIDATE_ID = "reg_extra_ll_structure_matminer_wide"


def parse_ints(text: str) -> list[int]:
    values = [int(part.strip()) for part in text.split(",") if part.strip()]
    if not values:
        raise ValueError("At least one integer is required.")
    return values


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def hash_ids(ids: list[Any]) -> str:
    return sha256_text(json.dumps([str(x) for x in ids], sort_keys=True, separators=(",", ":")))


def choose_candidate(candidates: list[Any], candidate_id: str) -> Any:
    for spec in candidates:
        if spec.candidate_id == candidate_id:
            return spec
    available = ", ".join(spec.candidate_id for spec in candidates)
    raise ValueError(f"Expert-reference candidate `{candidate_id}` was not found. Available candidates: {available}")


def subset_values(values: Any, idx: np.ndarray) -> np.ndarray:
    if hasattr(values, "iloc"):
        return np.asarray(values.iloc[idx], dtype=float)
    return np.asarray(values, dtype=float)[idx]


def task_xy(task_name: str) -> tuple[list[Any], np.ndarray, list[Any], str, str]:
    task = MatbenchTask(task_name, autoload=True)
    if task.metadata.task_type != "regression" or task.metadata.input_type != "structure":
        raise ValueError("This hidden-resampling protocol supports structure-regression Matbench tasks only.")
    frame = task.df.copy()
    input_col = str(frame.columns[0])
    target_col = str(frame.columns[1])
    ids = list(frame.index)
    x = list(frame[input_col])
    y = np.asarray(frame[target_col], dtype=float)
    return x, y, ids, input_col, target_col


def hidden_split_indices(n: int, seed: int, task_name: str, split_id: int, test_fraction: float) -> tuple[np.ndarray, np.ndarray]:
    idx = np.arange(n)
    train_idx, test_idx = train_test_split(
        idx,
        test_size=test_fraction,
        shuffle=True,
        random_state=stable_seed(seed, task_name, split_id, "hidden-resampling-test"),
    )
    return np.asarray(train_idx, dtype=int), np.asarray(test_idx, dtype=int)


def run_one_split(task_name: str, split_id: int, args: argparse.Namespace, archive: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    x_all, y_all, ids, input_col, target_col = task_xy(task_name)
    train_idx, test_idx = hidden_split_indices(len(y_all), args.secret_seed, task_name, split_id, args.test_fraction)
    x_train = [x_all[i] for i in train_idx]
    y_train = subset_values(y_all, train_idx)
    x_test = [x_all[i] for i in test_idx]
    y_test = subset_values(y_all, test_idx)

    target_candidates = target_specs(args.target_budget)
    transfer_candidates = chgnet_specs()[: args.chgnet_budget]
    expert_spec = choose_candidate(target_specs(max(args.target_budget, args.expert_budget)), args.expert_candidate_id)
    all_specs_by_id = {spec.candidate_id: spec for spec in target_candidates + transfer_candidates + [expert_spec]}
    all_specs = list(all_specs_by_id.values())

    split_context = {
        "task": task_name,
        "split_id": split_id,
        "input_col": input_col,
        "target_col": target_col,
        "n_total": int(len(y_all)),
        "n_train": int(len(train_idx)),
        "n_test": int(len(test_idx)),
        "train_id_hash": hash_ids([ids[i] for i in train_idx]),
        "test_id_hash": hash_ids([ids[i] for i in test_idx]),
        "test_fraction": float(args.test_fraction),
    }

    print(
        f"[matbench-hidden-resampling] task={task_name} split={split_id} "
        f"n_train={len(train_idx)} n_test={len(test_idx)}",
        flush=True,
    )
    all_features = build_feature_blocks(
        x_train + x_test,
        all_specs,
        args.chgnet_batch_size,
        archive,
        {**split_context, "block": "hidden_resample_train_plus_test"},
    )
    n_train = len(x_train)
    train_features = {key: value[:n_train] for key, value in all_features.items()}
    test_features = {key: value[n_train:] for key, value in all_features.items()}

    seed = stable_seed(args.secret_seed, task_name, split_id, "selection")
    target_choice = select_target(
        target_candidates,
        train_features,
        y_train,
        args.validation_repeats,
        seed,
        args.validation_fraction,
        args.selection_se_penalty,
        archive,
        {"arm": "target_only_self_improving", **split_context},
    )
    cross_choice = select_cross(
        target_choice,
        transfer_candidates,
        train_features,
        y_train,
        args.validation_repeats,
        seed,
        args.validation_fraction,
        [float(v) for v in args.alpha_grid],
        args.gate_margin,
        args.selection_se_penalty,
        archive,
        {"arm": "cross_domain_self_improving", **split_context},
    )

    target_fixed = target_candidates[0]
    cross_fixed = transfer_candidates[0]
    choices = {
        "target_only_one_shot": ("fixed_target_candidate", target_fixed, None),
        "target_only_self_improving": ("repeated_target_validation", None, target_choice),
        "cross_domain_one_shot": ("fixed_chgnet_foundation_candidate", cross_fixed, None),
        "cross_domain_self_improving": ("repeated_target_validation_chgnet_stack", None, cross_choice),
        EXPERT_ARM: ("fixed_declared_expert_style_reference", expert_spec, None),
    }

    final_scale = target_scale(y_train)
    records: list[dict[str, Any]] = []
    for arm in EVAL_ARM_ORDER:
        selection_rule, spec, choice = choices[arm]
        print(f"[matbench-hidden-resampling] final arm={arm} task={task_name} split={split_id}", flush=True)
        if choice is None:
            if spec is None:
                raise ValueError("Fixed arm missing candidate specification.")
            pred = fit_predict_spec(
                spec,
                train_features,
                y_train,
                test_features,
                stable_seed(args.secret_seed, task_name, split_id, arm, spec.candidate_id, "final"),
            )
            candidate_id = spec.candidate_id
            feature_mode = spec.feature_mode
            model = spec.model
            params = spec.params
            validation_value = float("nan")
            alpha = float("nan")
            choice_kind = "fixed"
        else:
            pred, candidate_id, feature_mode = predict_choice(
                choice,
                train_features,
                y_train,
                test_features,
                stable_seed(args.secret_seed, task_name, split_id, arm, "final"),
            )
            chosen_spec = choice.transfer_spec if choice.transfer_spec is not None else choice.target_spec
            model = chosen_spec.model
            params = chosen_spec.params
            validation_value = choice.score
            alpha = choice.alpha
            choice_kind = choice.kind

        mae = float(np.mean(np.abs(y_test - np.asarray(pred, dtype=float))))
        utility = -mae / max(final_scale, 1.0e-12)
        records.append(
            {
                **split_context,
                "arm": arm,
                "arm_label": EVAL_ARM_LABELS[arm],
                "primary_metric": PRIMARY_METRIC["regression"],
                "primary_value": mae,
                "utility": utility,
                "loss": -utility,
                "selection_validation_loss": validation_value,
                "selection_rule": selection_rule,
                "choice_kind": choice_kind,
                "alpha": alpha,
                "candidate_id": candidate_id,
                "feature_mode": feature_mode,
                "model": model,
                "params": json.dumps(params, sort_keys=True),
                "n_source_tasks": 1 if "chgnet" in feature_mode or choice_kind in {"pure", "stack"} else 0,
            }
        )

    return records, split_context


def add_ranks(records: list[dict[str, Any]]) -> None:
    by_key: dict[tuple[str, int], list[dict[str, Any]]] = {}
    for row in records:
        by_key.setdefault((str(row["task"]), int(row["split_id"])), []).append(row)
    for group in by_key.values():
        ordered = sorted(group, key=lambda row: float(row["utility"]), reverse=True)
        for rank, row in enumerate(ordered, start=1):
            row["rank"] = rank


def mean_se(values: list[float]) -> tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    mean = float(np.mean(arr)) if arr.size else float("nan")
    se = float(np.std(arr, ddof=1) / math.sqrt(arr.size)) if arr.size > 1 else 0.0
    return mean, se


def summarize(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for arm in EVAL_ARM_ORDER:
        group = [row for row in records if row["arm"] == arm]
        utility_mean, utility_se = mean_se([float(row["utility"]) for row in group])
        rank_mean, rank_se = mean_se([float(row["rank"]) for row in group])
        primary_mean, primary_se = mean_se([float(row["primary_value"]) for row in group])
        rows.append(
            {
                "arm": arm,
                "arm_label": EVAL_ARM_LABELS[arm],
                "n_task_splits": len(group),
                "mean_utility": utility_mean,
                "se_utility": utility_se,
                "mean_rank": rank_mean,
                "se_rank": rank_se,
                "mean_primary_value": primary_mean,
                "se_primary_value": primary_se,
            }
        )
    return rows


def by_task(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for task in sorted({str(row["task"]) for row in records}):
        for arm in EVAL_ARM_ORDER:
            group = [row for row in records if row["task"] == task and row["arm"] == arm]
            utility_mean, utility_se = mean_se([float(row["utility"]) for row in group])
            primary_mean, primary_se = mean_se([float(row["primary_value"]) for row in group])
            rows.append(
                {
                    "task": task,
                    "arm": arm,
                    "arm_label": EVAL_ARM_LABELS[arm],
                    "n_splits": len(group),
                    "mean_primary_value": primary_mean,
                    "se_primary_value": primary_se,
                    "mean_utility": utility_mean,
                    "se_utility": utility_se,
                    "primary_metric": PRIMARY_METRIC["regression"],
                }
            )
    return rows


def contrasts(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_key: dict[tuple[str, int], dict[str, float]] = {}
    for row in records:
        by_key.setdefault((str(row["task"]), int(row["split_id"])), {})[str(row["arm"])] = float(row["utility"])
    specs = [
        ("target_self_minus_target_one_shot", "target_only_self_improving", "target_only_one_shot"),
        ("cross_self_minus_target_self", "cross_domain_self_improving", "target_only_self_improving"),
        ("cross_self_minus_cross_one_shot", "cross_domain_self_improving", "cross_domain_one_shot"),
        ("cross_self_minus_target_one_shot", "cross_domain_self_improving", "target_only_one_shot"),
        ("cross_self_minus_expert_reference", "cross_domain_self_improving", EXPERT_ARM),
        ("target_self_minus_expert_reference", "target_only_self_improving", EXPERT_ARM),
        ("expert_reference_minus_target_one_shot", EXPERT_ARM, "target_only_one_shot"),
    ]
    rows = []
    for name, better, worse in specs:
        diffs = [arms[better] - arms[worse] for arms in by_key.values() if better in arms and worse in arms]
        mean, se = mean_se(diffs)
        rows.append(
            {
                "contrast": name,
                "n_pairs": len(diffs),
                "mean_utility_difference": mean,
                "se_utility_difference": se,
                "paired_win_rate": float(np.mean(np.asarray(diffs) > 0.0)) if diffs else float("nan"),
            }
        )
    return rows


def write_summary_md(path: Path, summary_rows: list[dict[str, Any]], contrast_rows: list[dict[str, Any]], manifest: dict[str, Any]) -> None:
    source = next(row for row in summary_rows if row["arm"] == "cross_domain_self_improving")
    target = next(row for row in summary_rows if row["arm"] == "target_only_self_improving")
    expert = next((row for row in summary_rows if row["arm"] == EXPERT_ARM), None)
    cross_vs_target = next(row for row in contrast_rows if row["contrast"] == "cross_self_minus_target_self")
    cross_vs_expert = next((row for row in contrast_rows if row["contrast"] == "cross_self_minus_expert_reference"), None)
    lines = [
        "# Matbench Hidden-Resampling Foundation-Stack Audit",
        "",
        "This run uses curator-seeded random train/test splits from public Matbench labeled records.",
        "Candidate selection uses only the resampled training part and inner validation splits.",
        "The hidden resampled test split is scored after each arm's output is frozen.",
        "The expert-reference arm is a predeclared, runnable expert-style materials-informatics rule scored on the same hidden resamples.",
        "",
        f"- Protocol: `{manifest['protocol']}`",
        f"- Tasks: {', '.join(manifest['tasks'])}",
        f"- Split ids: {', '.join(str(x) for x in manifest['split_ids'])}",
        f"- Number of arm-by-task-split records: {manifest['n_records']}",
        "",
        "Primary comparison:",
        f"- Source-informed self-improving utility: {source['mean_utility']:.4f} ({source['se_utility']:.4f})",
        f"- Target-only self-improving utility: {target['mean_utility']:.4f} ({target['se_utility']:.4f})",
        f"- Source-informed gain over target-only self-improving: {cross_vs_target['mean_utility_difference']:.4f} ({cross_vs_target['se_utility_difference']:.4f}); win rate {cross_vs_target['paired_win_rate']:.3f}",
    ]
    if expert is not None and cross_vs_expert is not None:
        lines.extend(
            [
                f"- Expert-reference utility: {expert['mean_utility']:.4f} ({expert['se_utility']:.4f})",
                f"- Source-informed gain over expert reference: {cross_vs_expert['mean_utility_difference']:.4f} ({cross_vs_expert['se_utility_difference']:.4f}); win rate {cross_vs_expert['paired_win_rate']:.3f}",
            ]
        )
    lines.extend(
        [
        "",
        "Caveat: this is hidden resampling of public labels, not an official Matbench leaderboard submission and not a new external materials dataset. The expert-reference arm is not substituted for the official Matbench leaderboard score; it is a same-split declared comparator.",
        "",
        ]
    )
    path.write_text("\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", default="matbench_dielectric,matbench_jdft2d,matbench_log_gvrh,matbench_log_kvrh")
    parser.add_argument("--split-ids", default="0,1,2,3,4")
    parser.add_argument("--secret-seed", type=int, required=True)
    parser.add_argument("--test-fraction", type=float, default=0.20)
    parser.add_argument("--target-budget", type=int, default=24)
    parser.add_argument("--chgnet-budget", type=int, default=15)
    parser.add_argument("--expert-budget", type=int, default=32)
    parser.add_argument("--expert-candidate-id", default=DEFAULT_EXPERT_CANDIDATE_ID)
    parser.add_argument("--validation-repeats", type=int, default=3)
    parser.add_argument("--validation-fraction", type=float, default=0.22)
    parser.add_argument("--selection-se-penalty", type=float, default=0.5)
    parser.add_argument("--gate-margin", type=float, default=0.0002)
    parser.add_argument("--alpha-grid", type=parse_float_grid, default=parse_float_grid("0.05,0.1,0.2,0.35,0.5,0.65,0.8,1.0"))
    parser.add_argument("--chgnet-batch-size", type=int, default=32)
    parser.add_argument("--output-dir", default=str(DEFAULT_RESULTS))
    args = parser.parse_args()

    tasks = [part.strip() for part in args.tasks.split(",") if part.strip()]
    split_ids = parse_ints(args.split_ids)
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)

    start = time.time()
    archive: list[dict[str, Any]] = []
    records: list[dict[str, Any]] = []
    split_records: list[dict[str, Any]] = []
    for task_name in tasks:
        for split_id in split_ids:
            rows, split_context = run_one_split(task_name, split_id, args, archive)
            records.extend(rows)
            split_records.append(split_context)

    add_ranks(records)
    summary_rows = summarize(records)
    by_task_rows = by_task(records)
    contrast_rows = contrasts(records)

    write_csv(out / "records.csv", records, union_fieldnames(records))
    write_csv(out / "summary.csv", summary_rows, union_fieldnames(summary_rows))
    write_csv(out / "by_task.csv", by_task_rows, union_fieldnames(by_task_rows))
    write_csv(out / "contrasts.csv", contrast_rows, union_fieldnames(contrast_rows))
    write_csv(out / "hidden_split_manifest.csv", split_records, union_fieldnames(split_records))
    write_jsonl(out / "archive.jsonl", archive)

    manifest = {
        "experiment": "matbench_hidden_resampling_foundation_stack",
        "protocol": "curator_seeded_hidden_resampling_public_matbench_chgnet_foundation_stack_with_expert_reference_v1",
        "created_unix": time.time(),
        "elapsed_seconds": time.time() - start,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "tasks": tasks,
        "split_ids": split_ids,
        "secret_seed": int(args.secret_seed),
        "secret_seed_sha256": sha256_text(str(args.secret_seed)),
        "test_fraction": float(args.test_fraction),
        "target_budget": int(args.target_budget),
        "chgnet_budget": int(args.chgnet_budget),
        "expert_budget": int(args.expert_budget),
        "expert_arm": EXPERT_ARM,
        "expert_label": EXPERT_LABEL,
        "expert_candidate_id": str(args.expert_candidate_id),
        "validation_repeats": int(args.validation_repeats),
        "validation_fraction": float(args.validation_fraction),
        "selection_se_penalty": float(args.selection_se_penalty),
        "gate_margin": float(args.gate_margin),
        "alpha_grid": [float(x) for x in args.alpha_grid],
        "n_records": len(records),
        "n_archive_rows": len(archive),
        "split_context_hash": sha256_text(json.dumps(split_records, sort_keys=True, separators=(",", ":"))),
        "selection_rule": "Inner train/validation splits select candidates on the resampled training part; resampled test labels are scored only after output freeze. The expert-reference arm is fixed before the hidden resamples are scored.",
        "score": "utility = - mean absolute error / training-response scale; larger is better",
        "caveat": "Public Matbench labels are resampled into hidden folds by secret seed. This is stronger than public-fold reuse but not a new external materials dataset. The same-split expert reference is a runnable declared expert-style rule, not the official Matbench leaderboard result.",
    }
    write_json(out / "manifest.json", manifest)
    write_summary_md(out / "summary.md", summary_rows, contrast_rows, manifest)
    print(f"Wrote Matbench hidden-resampling audit to {out}")


if __name__ == "__main__":
    main()

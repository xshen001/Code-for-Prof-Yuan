#!/usr/bin/env python3
"""Evaluate the declared Matbench expert-reference rule on official folds.

This script is a calibration companion to the secret-seed hidden-resampling
run. It scores the same fixed expert-reference rule on Matbench's
benchmark-prespecified folds so the returned package can compare the difficulty
of the hidden resamples with the public fold protocol.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
from matbench.task import MatbenchTask

from run_matbench_chgnet_foundation_stack import build_feature_blocks, fit_predict_spec, target_specs
from run_matbench_experiment import (
    PRIMARY_METRIC,
    stable_seed,
    target_scale,
    union_fieldnames,
    write_csv,
    write_json,
    write_jsonl,
)


ROOT = Path(__file__).resolve().parent
DEFAULT_RESULTS = ROOT / "results_official_fold_expert_reference"
DEFAULT_EXPERT_CANDIDATE_ID = "reg_extra_ll_structure_matminer_wide"


def parse_ints(text: str) -> list[int]:
    values = [int(part.strip()) for part in text.split(",") if part.strip()]
    if not values:
        raise ValueError("At least one integer is required.")
    return values


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def choose_candidate(candidates: list[Any], candidate_id: str) -> Any:
    for spec in candidates:
        if spec.candidate_id == candidate_id:
            return spec
    available = ", ".join(spec.candidate_id for spec in candidates)
    raise ValueError(f"Expert-reference candidate `{candidate_id}` was not found. Available candidates: {available}")


def subset_values(values: Any) -> np.ndarray:
    if hasattr(values, "to_numpy"):
        return np.asarray(values.to_numpy(), dtype=float)
    return np.asarray(values, dtype=float)


def mean_se(values: list[float]) -> tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    mean = float(np.mean(arr)) if arr.size else float("nan")
    se = float(np.std(arr, ddof=1) / math.sqrt(arr.size)) if arr.size > 1 else 0.0
    return mean, se


def run_one_fold(task_name: str, fold: int, args: argparse.Namespace, archive: list[dict[str, Any]]) -> dict[str, Any]:
    task = MatbenchTask(task_name, autoload=True)
    if task.metadata.task_type != "regression" or task.metadata.input_type != "structure":
        raise ValueError("This calibration supports structure-regression Matbench tasks only.")

    x_train_raw, y_train_raw = task.get_train_and_val_data(fold)
    x_train = list(x_train_raw)
    y_train = subset_values(y_train_raw)
    x_test = list(task.get_test_data(fold))

    expert_spec = choose_candidate(target_specs(args.expert_budget), args.expert_candidate_id)
    context = {
        "task": task_name,
        "fold": int(fold),
        "n_train": int(len(x_train)),
        "n_test": int(len(x_test)),
        "expert_candidate_id": expert_spec.candidate_id,
    }
    print(
        f"[matbench-official-expert] task={task_name} fold={fold} "
        f"n_train={len(x_train)} n_test={len(x_test)}",
        flush=True,
    )
    features = build_feature_blocks(
        x_train + x_test,
        [expert_spec],
        args.chgnet_batch_size,
        archive,
        {**context, "block": "official_train_plus_test"},
    )
    n_train = len(x_train)
    train_features = {key: value[:n_train] for key, value in features.items()}
    test_features = {key: value[n_train:] for key, value in features.items()}
    pred = fit_predict_spec(
        expert_spec,
        train_features,
        y_train,
        test_features,
        stable_seed(args.master_seed, task_name, fold, expert_spec.candidate_id, "official-expert-final"),
    )

    score_task = MatbenchTask(task_name, autoload=True)
    score_task.record(fold, pred, params={"arm": "expert_reference", "candidate_id": expert_spec.candidate_id})
    fold_key = score_task.folds_map[fold]
    scores = dict(score_task.results[fold_key].scores)
    primary_value = float(scores["mae"])
    utility = -primary_value / max(target_scale(y_train), 1.0e-12)
    return {
        **context,
        "arm": "expert_reference",
        "arm_label": "Declared expert-style reference",
        "primary_metric": PRIMARY_METRIC["regression"],
        "primary_value": primary_value,
        "utility": utility,
        "loss": -utility,
        "feature_mode": expert_spec.feature_mode,
        "model": expert_spec.model,
        "params": json.dumps(expert_spec.params, sort_keys=True),
        **{f"score_{key}": float(value) for key, value in scores.items()},
    }


def summarize(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    primary_mean, primary_se = mean_se([float(row["primary_value"]) for row in records])
    utility_mean, utility_se = mean_se([float(row["utility"]) for row in records])
    return [
        {
            "arm": "expert_reference",
            "arm_label": "Declared expert-style reference",
            "n_task_folds": len(records),
            "mean_primary_value": primary_mean,
            "se_primary_value": primary_se,
            "mean_utility": utility_mean,
            "se_utility": utility_se,
            "primary_metric": PRIMARY_METRIC["regression"],
        }
    ]


def by_task(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for task in sorted({str(row["task"]) for row in records}):
        group = [row for row in records if row["task"] == task]
        primary_mean, primary_se = mean_se([float(row["primary_value"]) for row in group])
        utility_mean, utility_se = mean_se([float(row["utility"]) for row in group])
        rows.append(
            {
                "task": task,
                "arm": "expert_reference",
                "arm_label": "Declared expert-style reference",
                "n_folds": len(group),
                "mean_primary_value": primary_mean,
                "se_primary_value": primary_se,
                "mean_utility": utility_mean,
                "se_utility": utility_se,
                "primary_metric": PRIMARY_METRIC["regression"],
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", default="matbench_dielectric,matbench_jdft2d,matbench_log_gvrh,matbench_log_kvrh")
    parser.add_argument("--folds", default="0,1,2,3,4")
    parser.add_argument("--master-seed", type=int, default=20260703)
    parser.add_argument("--expert-budget", type=int, default=32)
    parser.add_argument("--expert-candidate-id", default=DEFAULT_EXPERT_CANDIDATE_ID)
    parser.add_argument("--chgnet-batch-size", type=int, default=32)
    parser.add_argument("--output-dir", default=str(DEFAULT_RESULTS))
    args = parser.parse_args()

    tasks = [part.strip() for part in args.tasks.split(",") if part.strip()]
    folds = parse_ints(args.folds)
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)

    start = time.time()
    archive: list[dict[str, Any]] = []
    records: list[dict[str, Any]] = []
    for task_name in tasks:
        for fold in folds:
            records.append(run_one_fold(task_name, fold, args, archive))

    summary_rows = summarize(records)
    by_task_rows = by_task(records)
    write_csv(out / "records.csv", records, union_fieldnames(records))
    write_csv(out / "summary.csv", summary_rows, union_fieldnames(summary_rows))
    write_csv(out / "by_task.csv", by_task_rows, union_fieldnames(by_task_rows))
    write_jsonl(out / "archive.jsonl", archive)

    manifest = {
        "experiment": "matbench_official_fold_expert_reference",
        "protocol": "benchmark_prespecified_matbench_folds_expert_reference_v1",
        "created_unix": time.time(),
        "elapsed_seconds": time.time() - start,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "tasks": tasks,
        "folds": folds,
        "master_seed_sha256": sha256_text(str(args.master_seed)),
        "expert_candidate_id": str(args.expert_candidate_id),
        "expert_budget": int(args.expert_budget),
        "n_records": len(records),
        "n_archive_rows": len(archive),
        "score": "official Matbench fold mean absolute error; lower is better",
        "purpose": "Calibration of the declared expert-reference rule on benchmark-prespecified folds.",
    }
    write_json(out / "manifest.json", manifest)
    print(f"Wrote official-fold expert-reference calibration to {out}")


if __name__ == "__main__":
    main()

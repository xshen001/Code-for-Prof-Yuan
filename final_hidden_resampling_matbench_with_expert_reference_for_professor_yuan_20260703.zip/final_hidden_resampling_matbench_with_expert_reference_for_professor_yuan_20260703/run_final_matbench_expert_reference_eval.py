#!/usr/bin/env python3
"""One-command Matbench hidden-resampling evaluation with expert reference.

This package creates or accepts a private master seed, derives one Matbench
secret seed, runs the frozen Matbench hidden-resampling protocol, scores four
agent arms plus a predeclared expert-style reference rule on the same hidden
resampled test splits, records manifests and hashes, and creates one return zip
for the authors.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import platform
import random
import secrets
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_OUT = ROOT / "matbench_expert_reference_results"


def utc_stamp() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S_utc")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def output_hashes(root: Path, exclude: set[Path] | None = None) -> list[dict[str, object]]:
    excluded = {p.resolve() for p in (exclude or set())}
    rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.resolve() in excluded:
            continue
        rows.append(
            {
                "path": str(path.relative_to(root)),
                "size_bytes": int(path.stat().st_size),
                "sha256": sha256_file(path),
            }
        )
    return rows


def make_master_seed(seed: int | None) -> tuple[int, str]:
    if seed is not None:
        return int(seed), "curator_supplied"
    return int.from_bytes(secrets.token_bytes(8), "big") & ((1 << 63) - 1), "machine_secret"


def derived_seed(master_seed: int, label: str) -> int:
    rng = random.Random(f"{master_seed}:{label}")
    return rng.randrange(1, 2_147_483_647)


def module_plan(mode: str) -> dict[str, object]:
    if mode == "smoke":
        return {
            "matbench_tasks": "matbench_jdft2d",
            "matbench_split_ids": "0",
            "matbench_official_folds": "0",
            "matbench_target_budget": 2,
            "matbench_chgnet_budget": 1,
            "matbench_expert_budget": 32,
            "matbench_expert_candidate_id": "reg_extra_ll_structure_matminer_wide",
            "matbench_validation_repeats": 1,
            "matbench_test_fraction": 0.20,
        }
    if mode == "standard":
        return {
            "matbench_tasks": "matbench_dielectric,matbench_jdft2d,matbench_log_gvrh,matbench_log_kvrh",
            "matbench_split_ids": "0,1,2,3,4",
            "matbench_official_folds": "0,1,2,3,4",
            "matbench_target_budget": 24,
            "matbench_chgnet_budget": 15,
            "matbench_expert_budget": 32,
            "matbench_expert_candidate_id": "reg_extra_ll_structure_matminer_wide",
            "matbench_validation_repeats": 3,
            "matbench_test_fraction": 0.20,
        }
    raise ValueError(mode)


def run_hidden_resampling(out: Path, plan: dict[str, object], seed: int, env: dict[str, str]) -> dict[str, object]:
    module_root = ROOT / "matbench_agent_experiment"
    log_dir = out / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = log_dir / "matbench.stdout.txt"
    stderr_path = log_dir / "matbench.stderr.txt"
    cmd = [
        sys.executable,
        "run_matbench_hidden_resampling_foundation_stack_with_expert.py",
        "--tasks",
        str(plan["matbench_tasks"]),
        "--split-ids",
        str(plan["matbench_split_ids"]),
        "--secret-seed",
        str(seed),
        "--test-fraction",
        str(plan["matbench_test_fraction"]),
        "--target-budget",
        str(plan["matbench_target_budget"]),
        "--chgnet-budget",
        str(plan["matbench_chgnet_budget"]),
        "--expert-budget",
        str(plan["matbench_expert_budget"]),
        "--expert-candidate-id",
        str(plan["matbench_expert_candidate_id"]),
        "--validation-repeats",
        str(plan["matbench_validation_repeats"]),
        "--output-dir",
        str(out / "matbench_hidden_resampling"),
    ]
    record = {
        "name": "matbench_hidden_resampling",
        "cwd": str(module_root),
        "cmd": cmd,
        "stdout": str(stdout_path.relative_to(out)),
        "stderr": str(stderr_path.relative_to(out)),
        "started_utc": utc_stamp(),
    }
    started = time.time()
    completed = subprocess.run(
        cmd,
        cwd=module_root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        check=False,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    record["completed_utc"] = utc_stamp()
    record["elapsed_seconds"] = time.time() - started
    record["returncode"] = int(completed.returncode)
    if completed.returncode != 0:
        raise subprocess.CalledProcessError(completed.returncode, cmd, completed.stdout, completed.stderr)
    return record


def run_official_expert(out: Path, plan: dict[str, object], seed: int, env: dict[str, str]) -> dict[str, object]:
    module_root = ROOT / "matbench_agent_experiment"
    log_dir = out / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = log_dir / "matbench_official_expert.stdout.txt"
    stderr_path = log_dir / "matbench_official_expert.stderr.txt"
    cmd = [
        sys.executable,
        "run_matbench_official_fold_expert_reference.py",
        "--tasks",
        str(plan["matbench_tasks"]),
        "--folds",
        str(plan["matbench_official_folds"]),
        "--master-seed",
        str(seed),
        "--expert-budget",
        str(plan["matbench_expert_budget"]),
        "--expert-candidate-id",
        str(plan["matbench_expert_candidate_id"]),
        "--output-dir",
        str(out / "matbench_official_fold_expert_reference"),
    ]
    record = {
        "name": "matbench_official_fold_expert_reference",
        "cwd": str(module_root),
        "cmd": cmd,
        "stdout": str(stdout_path.relative_to(out)),
        "stderr": str(stderr_path.relative_to(out)),
        "started_utc": utc_stamp(),
    }
    started = time.time()
    completed = subprocess.run(
        cmd,
        cwd=module_root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
        check=False,
    )
    stdout_path.write_text(completed.stdout)
    stderr_path.write_text(completed.stderr)
    record["completed_utc"] = utc_stamp()
    record["elapsed_seconds"] = time.time() - started
    record["returncode"] = int(completed.returncode)
    if completed.returncode != 0:
        raise subprocess.CalledProcessError(completed.returncode, cmd, completed.stdout, completed.stderr)
    return record


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv_rows(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("")
        return
    fieldnames = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_expert_fold_calibration(out: Path) -> dict[str, object]:
    hidden_by_task = read_csv_rows(out / "matbench_hidden_resampling" / "by_task.csv")
    official_by_task = read_csv_rows(out / "matbench_official_fold_expert_reference" / "by_task.csv")
    hidden_expert = {row["task"]: row for row in hidden_by_task if row.get("arm") == "expert_reference"}
    official_expert = {row["task"]: row for row in official_by_task if row.get("arm") == "expert_reference"}
    rows: list[dict[str, object]] = []
    for task in sorted(set(hidden_expert) & set(official_expert)):
        hidden_mae = float(hidden_expert[task]["mean_primary_value"])
        official_mae = float(official_expert[task]["mean_primary_value"])
        diff = hidden_mae - official_mae
        rel = diff / official_mae if official_mae else float("nan")
        rows.append(
            {
                "task": task,
                "expert_candidate_id": "reg_extra_ll_structure_matminer_wide",
                "hidden_resampling_mean_mae": hidden_mae,
                "official_fold_mean_mae": official_mae,
                "hidden_minus_official_mae": diff,
                "relative_difference": rel,
                "absolute_relative_difference": abs(rel),
                "n_hidden_splits": hidden_expert[task].get("n_splits", ""),
                "n_official_folds": official_expert[task].get("n_folds", ""),
            }
        )
    write_csv_rows(out / "expert_fold_calibration.csv", rows)
    if rows:
        mean_hidden = sum(float(row["hidden_resampling_mean_mae"]) for row in rows) / len(rows)
        mean_official = sum(float(row["official_fold_mean_mae"]) for row in rows) / len(rows)
        mean_abs_rel = sum(float(row["absolute_relative_difference"]) for row in rows) / len(rows)
    else:
        mean_hidden = mean_official = mean_abs_rel = float("nan")
    summary = {
        "n_tasks": len(rows),
        "mean_hidden_resampling_mae": mean_hidden,
        "mean_official_fold_mae": mean_official,
        "mean_hidden_minus_official_mae": mean_hidden - mean_official,
        "mean_absolute_relative_difference": mean_abs_rel,
        "interpretation": "Calibration of the same declared expert-reference rule on secret resamples versus Matbench official folds.",
    }
    write_csv_rows(out / "expert_fold_calibration_summary.csv", [summary])
    return summary


def make_return_zip(out: Path, mode: str) -> Path:
    zip_path = out.parent / f"matbench_expert_reference_hidden_resampling_{mode}_{out.name}_return_to_authors.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(out.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(out.parent))
    return zip_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("smoke", "standard"), default="standard")
    parser.add_argument("--out", default=None)
    parser.add_argument("--master-seed", type=int, default=None, help="Optional curator-supplied secret seed. Omit to generate privately.")
    parser.add_argument("--skip-zip", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    master_seed, seed_source = make_master_seed(args.master_seed)
    matbench_seed = derived_seed(master_seed, "matbench")
    stamp = utc_stamp()
    out = Path(args.out).resolve() if args.out else DEFAULT_OUT / f"{args.mode}_{stamp}"
    out.mkdir(parents=True, exist_ok=True)

    plan = module_plan(args.mode)
    env = dict(os.environ)
    env.setdefault("MPLBACKEND", "Agg")
    env.setdefault("OMP_NUM_THREADS", "1")
    env.setdefault("MKL_NUM_THREADS", "1")
    env.setdefault("OPENBLAS_NUM_THREADS", "1")
    env.setdefault("NUMEXPR_NUM_THREADS", "1")

    pre_manifest = {
        "protocol": "matbench_expert_reference_non_author_hidden_resampling_wrapper_v1",
        "mode": args.mode,
        "created_utc": stamp,
        "python_executable": sys.executable,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "master_seed_source": seed_source,
        "master_seed_sha256": sha256_text(str(master_seed)),
        "matbench_seed_sha256": sha256_text(str(matbench_seed)),
        "plan": plan,
        "selection_evaluation_separation": (
            "Candidate selection uses only the resampled training part and inner "
            "validation splits. The curator-seeded resampled test labels are "
            "scored only after each arm's output has been selected. The expert "
            "reference is a fixed declared comparator scored on the same hidden "
            "test splits."
        ),
    }
    (out / "pre_run_manifest.json").write_text(json.dumps(pre_manifest, indent=2) + "\n")

    hidden_record = run_hidden_resampling(out, plan, matbench_seed, env)
    official_record = run_official_expert(out, plan, matbench_seed, env)
    calibration_summary = write_expert_fold_calibration(out)

    final_manifest_path = out / "final_manifest.json"
    final_manifest = dict(pre_manifest)
    final_manifest["completed_utc"] = utc_stamp()
    final_manifest["master_seed"] = master_seed
    final_manifest["matbench_seed"] = matbench_seed
    final_manifest["run_records"] = [hidden_record, official_record]
    final_manifest["expert_fold_calibration_summary"] = calibration_summary
    final_manifest["output_hashes_excluding_final_manifest"] = output_hashes(out, exclude={final_manifest_path})
    final_manifest_path.write_text(json.dumps(final_manifest, indent=2) + "\n")
    (out / "final_manifest.sha256").write_text(f"{sha256_file(final_manifest_path)}  final_manifest.json\n")

    zip_path = None
    if not args.skip_zip:
        zip_path = make_return_zip(out, args.mode)
        (out / "return_zip_path.txt").write_text(str(zip_path) + "\n")

    print(f"Wrote Matbench hidden-resampling expert-reference evaluation to {out}")
    if zip_path is not None:
        print(f"Return zip: {zip_path}")


if __name__ == "__main__":
    main()

Causal interval-transfer independent run package
===============================================

Purpose
-------
This corrected package asks Professor Yuan to run a new causal-inference
transfer audit. Please use this package instead of any earlier
`causal_interval_transfer_for_professor_yuan_20260702_fixed` package.
It is separate from the completed protein, causal, program-synthesis, online
decision, and Matbench runs. It does not require secret manual inputs; instead,
the run scripts generate the master, public-validation, and hidden-test seeds
locally on the evaluator's machine using operating-system entropy.

What this evaluates
-------------------
The original causal benchmark transferred source information only by ranking a
fixed library of inferential procedures. This package tests a stronger transfer
mechanism:

  1. construct target and source calibrated interval multipliers;
  2. construct source-ranked stacked procedures;
  3. select the final rule using public target/source validation records only;
  4. freeze the selected rule before hidden datasets are scored.

The hidden datasets are generated after selection from evaluator-generated
seeds that are not known to the authors before the return package is sent back.
The score is the same validity-aware utility:

  utility = -[mean absolute effect-estimation error
              + 0.15 mean interval length
              + 5 max(0, 0.90 - coverage)^2].

Recommended steps
-----------------
1. Read `plan.md`. It is written for Professor Yuan's Codex execution agent.

2. Optional, if the Python environment lacks required packages:

       SETUP_CAUSAL_INTERVAL_ENV.command

3. Run the final standard evaluation:

       RUN_CAUSAL_INTERVAL_TRANSFER_STANDARD.command

What to send back
-----------------
After the standard run completes, send back the generated file whose name
matches:

    causal_interval_transfer_*_return_to_authors.zip

The standard script now checks that this zip is nonempty and readable, prints
its byte size and SHA-256 checksum, and also copies the return zip to the
Desktop when possible. Please send back a zip with nonzero size. If Dropbox or
another cloud service shows the zip as 0 bytes, wait for it to finish syncing or
send the Desktop copy instead.

The returned zip includes evaluator_seed_manifest.json inside the result
directory. That file records the seeds generated on the evaluator's machine for
auditability after the run.

Sanity check
------------
The standard run output should print a line beginning:

    Seed source: evaluator-machine OS entropy

The returned result directory should contain:

    evaluator_seed_manifest.json

If setup or the standard run fails
----------------------------------
If setup or the standard run fails, please send back the Terminal output,
screenshot, and any generated result directory or return zip. No debugging
beyond this is requested unless Professor Yuan explicitly chooses to debug.

#!/usr/bin/env python3
"""Causal inferential-procedure selection benchmark.

This experiment is intentionally self-contained.  It generates semi-synthetic
causal datasets with known finite-sample treatment effects, lets four frozen
agent arms select an inferential procedure using public validation datasets,
and evaluates the selected procedures on hidden datasets generated from
disjoint seeds.

The benchmark is designed to test a different object from prediction or
ranking examples: the selected output is a full inferential procedure.  The
score rewards low treatment-effect error while penalizing confidence intervals
that miss the nominal coverage target.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.model_selection import KFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
SKLEARN_SEED_MODULUS = 2**32
NOMINAL_COVERAGE = 0.90
Z_VALUE = 1.6448536269514722


@dataclass(frozen=True)
class Family:
    name: str
    motif: str
    p: int = 8
    overlap: float = 1.0
    nonlinearity: float = 0.0
    heterogeneity: float = 0.0
    noise: float = 1.0


@dataclass(frozen=True)
class Dataset:
    x: np.ndarray
    a: np.ndarray
    y: np.ndarray
    tau: np.ndarray
    true_ate: float


@dataclass(frozen=True)
class Procedure:
    name: str
    kind: str
    outcome: str = "ridge"
    propensity: str = "logit"
    ci_mult: float = 1.0


@dataclass(frozen=True)
class Estimate:
    ate: float
    se: float
    lo: float
    hi: float


def stable_hash(obj: object) -> str:
    payload = json.dumps(obj, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def sklearn_seed(seed: int) -> int:
    return int(seed) % SKLEARN_SEED_MODULUS


FAMILIES = {
    "linear_target": Family("linear_target", "linear", overlap=0.8, nonlinearity=0.0, heterogeneity=0.1, noise=1.0),
    "linear_source_a": Family("linear_source_a", "linear", overlap=0.9, nonlinearity=0.0, heterogeneity=0.0, noise=1.0),
    "linear_source_b": Family("linear_source_b", "linear", overlap=0.7, nonlinearity=0.1, heterogeneity=0.1, noise=1.1),
    "nonlinear_target": Family("nonlinear_target", "nonlinear", overlap=1.1, nonlinearity=1.0, heterogeneity=0.5, noise=1.0),
    "nonlinear_source_a": Family("nonlinear_source_a", "nonlinear", overlap=1.0, nonlinearity=0.9, heterogeneity=0.4, noise=1.0),
    "nonlinear_source_b": Family("nonlinear_source_b", "nonlinear", overlap=1.2, nonlinearity=1.1, heterogeneity=0.6, noise=1.1),
    "overlap_target": Family("overlap_target", "overlap", overlap=1.8, nonlinearity=0.4, heterogeneity=0.3, noise=1.0),
    "overlap_source_a": Family("overlap_source_a", "overlap", overlap=1.7, nonlinearity=0.3, heterogeneity=0.2, noise=1.0),
    "overlap_source_b": Family("overlap_source_b", "overlap", overlap=1.9, nonlinearity=0.5, heterogeneity=0.4, noise=1.1),
    "heterogeneous_target": Family("heterogeneous_target", "heterogeneous", overlap=1.0, nonlinearity=0.7, heterogeneity=1.0, noise=1.0),
    "heterogeneous_source_a": Family("heterogeneous_source_a", "heterogeneous", overlap=0.9, nonlinearity=0.6, heterogeneity=0.9, noise=1.0),
    "heterogeneous_source_b": Family("heterogeneous_source_b", "heterogeneous", overlap=1.1, nonlinearity=0.8, heterogeneity=1.1, noise=1.1),
}

TARGET_FAMILIES = ("linear_target", "nonlinear_target", "overlap_target", "heterogeneous_target")
SOURCE_MAP = {
    "linear_target": ("linear_source_a", "linear_source_b", "nonlinear_source_a"),
    "nonlinear_target": ("nonlinear_source_a", "nonlinear_source_b", "heterogeneous_source_a"),
    "overlap_target": ("overlap_source_a", "overlap_source_b", "linear_source_b"),
    "heterogeneous_target": ("heterogeneous_source_a", "heterogeneous_source_b", "nonlinear_source_b"),
}

PROCEDURES = (
    Procedure("diff_mean_wide", "diff", ci_mult=1.8),
    Procedure("outcome_ridge", "outcome", outcome="ridge", ci_mult=1.3),
    Procedure("ipw_logit_wide", "ipw", propensity="logit", ci_mult=1.8),
    Procedure("aipw_ridge_logit", "aipw", outcome="ridge", propensity="logit", ci_mult=1.2),
    Procedure("aipw_ridge_logit_wide", "aipw", outcome="ridge", propensity="logit", ci_mult=1.7),
    Procedure("aipw_forest_logit", "aipw", outcome="forest", propensity="logit", ci_mult=1.3),
    Procedure("aipw_forest_logit_wide", "aipw", outcome="forest", propensity="logit", ci_mult=1.8),
    Procedure("aipw_boost_logit", "aipw", outcome="boost", propensity="logit", ci_mult=1.3),
    Procedure("aipw_boost_logit_wide", "aipw", outcome="boost", propensity="logit", ci_mult=1.8),
)
PROC_BY_NAME = {p.name: p for p in PROCEDURES}
TARGET_ONE_SHOT = "outcome_ridge"
DECLARED_EXPERT = "aipw_ridge_logit_wide"


def generate_dataset(family: Family, seed: int, n: int) -> Dataset:
    rng = np.random.default_rng(seed)
    x = rng.normal(size=(n, family.p))
    linear_score = 0.45 * x[:, 0] - 0.35 * x[:, 1] + 0.25 * x[:, 2]
    nonlinear_score = 0.45 * np.sin(x[:, 3]) + 0.25 * (x[:, 4] > 0) - 0.2 * x[:, 5] * x[:, 6]
    logits = family.overlap * (linear_score + family.nonlinearity * nonlinear_score)
    e = np.clip(expit(logits), 0.05, 0.95)
    a = rng.binomial(1, e, size=n).astype(float)

    base = 0.7 * x[:, 0] + 0.4 * x[:, 1] - 0.25 * x[:, 2]
    base += family.nonlinearity * (np.sin(x[:, 3]) + 0.35 * x[:, 4] ** 2 - 0.25 * x[:, 5] * x[:, 6])
    tau = 0.8 + family.heterogeneity * (0.35 * np.tanh(x[:, 0] + x[:, 3]) + 0.25 * (x[:, 4] > 0))
    y0 = base + rng.normal(scale=family.noise, size=n)
    y = y0 + a * tau
    return Dataset(x=x, a=a, y=y, tau=tau, true_ate=float(np.mean(tau)))


def outcome_model(kind: str, seed: int):
    if kind == "ridge":
        return make_pipeline(StandardScaler(), Ridge(alpha=1.0))
    if kind == "forest":
        return ExtraTreesRegressor(
            n_estimators=40,
            min_samples_leaf=8,
            max_features=0.8,
            random_state=sklearn_seed(seed),
            n_jobs=1,
        )
    if kind == "boost":
        return GradientBoostingRegressor(
            n_estimators=50,
            learning_rate=0.05,
            max_depth=2,
            random_state=sklearn_seed(seed),
        )
    raise KeyError(kind)


def propensity_model(kind: str, seed: int):
    if kind == "logit":
        return make_pipeline(
            StandardScaler(),
            LogisticRegression(C=1.0, solver="lbfgs", max_iter=500, random_state=sklearn_seed(seed)),
        )
    raise KeyError(kind)


def fit_predict_nuisance(data: Dataset, proc: Procedure, seed: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    n = len(data.y)
    ehat = np.zeros(n)
    mu0 = np.zeros(n)
    mu1 = np.zeros(n)
    folds = KFold(n_splits=3, shuffle=True, random_state=sklearn_seed(seed))
    for fold, (train, test) in enumerate(folds.split(data.x)):
        pmod = propensity_model(proc.propensity, seed + 101 * fold)
        pmod.fit(data.x[train], data.a[train])
        ehat[test] = pmod.predict_proba(data.x[test])[:, 1]
        for arm_value, store in ((0.0, mu0), (1.0, mu1)):
            rows = train[data.a[train] == arm_value]
            if len(rows) < 8:
                store[test] = float(np.mean(data.y[train]))
                continue
            omod = outcome_model(proc.outcome, seed + 503 * fold + int(arm_value))
            omod.fit(data.x[rows], data.y[rows])
            store[test] = omod.predict(data.x[test])
    return np.clip(ehat, 0.05, 0.95), mu0, mu1


def estimate(data: Dataset, proc: Procedure, seed: int) -> Estimate:
    y, a, x = data.y, data.a, data.x
    n = len(y)
    if proc.kind == "diff":
        yt, yc = y[a == 1], y[a == 0]
        ate = float(np.mean(yt) - np.mean(yc))
        se = math.sqrt(float(np.var(yt, ddof=1) / len(yt) + np.var(yc, ddof=1) / len(yc)))
    elif proc.kind == "outcome":
        mu0 = np.zeros(n)
        mu1 = np.zeros(n)
        folds = KFold(n_splits=3, shuffle=True, random_state=sklearn_seed(seed))
        for fold, (train, test) in enumerate(folds.split(x)):
            for arm_value, store in ((0.0, mu0), (1.0, mu1)):
                rows = train[a[train] == arm_value]
                model = outcome_model(proc.outcome, seed + 211 * fold + int(arm_value))
                model.fit(x[rows], y[rows])
                store[test] = model.predict(x[test])
        tau_hat = mu1 - mu0
        ate = float(np.mean(tau_hat))
        se = float(np.std(tau_hat, ddof=1) / math.sqrt(n))
    elif proc.kind == "ipw":
        ehat, _, _ = fit_predict_nuisance(data, proc, seed)
        psi = a * y / ehat - (1.0 - a) * y / (1.0 - ehat)
        ate = float(np.mean(psi))
        se = float(np.std(psi, ddof=1) / math.sqrt(n))
    elif proc.kind == "aipw":
        ehat, mu0, mu1 = fit_predict_nuisance(data, proc, seed)
        psi = mu1 - mu0 + a * (y - mu1) / ehat - (1.0 - a) * (y - mu0) / (1.0 - ehat)
        ate = float(np.mean(psi))
        se = float(np.std(psi, ddof=1) / math.sqrt(n))
    else:
        raise KeyError(proc.kind)
    se = max(se, 1e-8)
    half = Z_VALUE * proc.ci_mult * se
    return Estimate(ate=ate, se=se, lo=ate - half, hi=ate + half)


def eval_one(family_name: str, proc_name: str, seed: int, n: int) -> dict[str, object]:
    family = FAMILIES[family_name]
    proc = PROC_BY_NAME[proc_name]
    data = generate_dataset(family, seed, n)
    est = estimate(data, proc, seed + 17)
    err = abs(est.ate - data.true_ate)
    covered = float(est.lo <= data.true_ate <= est.hi)
    length = est.hi - est.lo
    return {
        "family": family_name,
        "motif": family.motif,
        "procedure": proc_name,
        "seed": seed,
        "true_ate": data.true_ate,
        "estimate": est.ate,
        "abs_error": err,
        "covered": covered,
        "length": length,
    }


def summarize_eval(records: list[dict[str, object]]) -> dict[str, float]:
    df = pd.DataFrame(records)
    coverage = float(df["covered"].mean())
    mean_error = float(df["abs_error"].mean())
    mean_length = float(df["length"].mean())
    coverage_penalty = max(0.0, NOMINAL_COVERAGE - coverage)
    loss = mean_error + 0.15 * mean_length + 5.0 * coverage_penalty * coverage_penalty
    return {
        "mean_abs_error": mean_error,
        "coverage": coverage,
        "mean_length": mean_length,
        "loss": loss,
        "utility": -loss,
    }


def procedure_metrics(family_names: tuple[str, ...], seed_base: int, reps: int, n: int) -> pd.DataFrame:
    rows = []
    for family_name in family_names:
        for proc in PROCEDURES:
            records = [
                eval_one(family_name, proc.name, seed_base + 100_000 * i, n)
                for i in range(reps)
            ]
            metrics = summarize_eval(records)
            rows.append({"family": family_name, "procedure": proc.name, **metrics, "n_reps": reps})
    return pd.DataFrame(rows)


def stable_int(text: str) -> int:
    return int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:8], 16)


def select_arms(target: str, target_metrics: pd.DataFrame, source_metrics: pd.DataFrame) -> dict[str, str]:
    target_loss = target_metrics.set_index("procedure")["loss"]
    source_loss = source_metrics.groupby("procedure")["loss"].mean()
    source_ranked = list(source_loss.sort_values().index)
    combined = {}
    for proc in PROCEDURES:
        tl = float(target_loss.loc[proc.name])
        sl = float(source_loss.loc[proc.name])
        combined[proc.name] = 0.70 * tl + 0.30 * sl
    target_best = float(target_loss.min())
    target_eligible = [p.name for p in PROCEDURES if float(target_loss.loc[p.name]) <= 1.02 * target_best + 1e-12]
    cross_self = min(target_eligible, key=lambda p: combined[p])
    return {
        "declared_expert": DECLARED_EXPERT,
        "target_only_one_shot": TARGET_ONE_SHOT,
        "target_only_self_improving": str(target_loss.idxmin()),
        "source_informed_one_shot": str(source_loss.idxmin()),
        "source_informed_self_improving": cross_self,
    }


def run_experiment(args: argparse.Namespace) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    selected_rows = []
    hidden_records = []
    public_records = {}
    hidden_hashes = {}

    for t_index, target in enumerate(TARGET_FAMILIES):
        target_seed = args.public_seed + 10_000 * (t_index + 1)
        source_seed = args.public_seed + 20_000 * (t_index + 1)
        target_public = procedure_metrics((target,), target_seed, args.public_target_reps, args.n_public)
        source_public = procedure_metrics(SOURCE_MAP[target], source_seed, args.public_source_reps, args.n_public)
        arms = select_arms(target, target_public, source_public)
        public_records[target] = {
            "target_public": target_public.to_dict(orient="records"),
            "source_public": source_public.to_dict(orient="records"),
            "selected": arms,
        }
        for arm, proc in arms.items():
            selected_rows.append({"target_family": target, "arm": arm, "procedure": proc})
            for j in range(args.hidden_reps):
                seed = args.hidden_seed + 1_000_000 * (t_index + 1) + 10_000 * j
                rec = eval_one(target, proc, seed, args.n_hidden)
                rec.update({"target_family": target, "arm": arm})
                hidden_records.append(rec)
        hidden_payload = [
            {"family": target, "seed": args.hidden_seed + 1_000_000 * (t_index + 1) + 10_000 * j}
            for j in range(args.hidden_reps)
        ]
        hidden_hashes[target] = stable_hash(hidden_payload)

    hidden = pd.DataFrame(hidden_records)
    selected = pd.DataFrame(selected_rows)
    selected.to_csv(out / "selected_procedures.csv", index=False)
    hidden.to_csv(out / "hidden_records.csv", index=False)
    summary = summarize_arms(hidden)
    contrasts = paired_contrasts(hidden)
    summary.to_csv(out / "summary.csv", index=False)
    contrasts.to_csv(out / "contrasts.csv", index=False)
    write_latex(out / "latex_tables.tex", summary, contrasts, selected)
    plot_summary(out / "causal_inference_summary.pdf", summary)
    manifest = {
        "experiment": "causal_inference_agent_experiment",
        "protocol": "semi_synthetic_known_ate_inferential_selection_v1",
        "target_families": TARGET_FAMILIES,
        "source_map": SOURCE_MAP,
        "procedures": [asdict(p) for p in PROCEDURES],
        "target_one_shot": TARGET_ONE_SHOT,
        "declared_expert": DECLARED_EXPERT,
        "public_seed": args.public_seed,
        "hidden_seed": args.hidden_seed,
        "public_target_reps": args.public_target_reps,
        "public_source_reps": args.public_source_reps,
        "hidden_reps": args.hidden_reps,
        "n_public": args.n_public,
        "n_hidden": args.n_hidden,
        "score": "utility = -[mean absolute error + 0.15 mean interval length + 5 max(0, 0.90 - coverage)^2]",
        "selected_procedures_hash": stable_hash(selected.to_dict(orient="records")),
        "hidden_records_hash": stable_hash(hidden.to_dict(orient="records")),
        "hidden_seed_hashes": hidden_hashes,
        "public_selection_records": public_records,
        "python": platform.python_version(),
        "platform": platform.platform(),
    }
    with (out / "manifest.json").open("w") as f:
        json.dump(manifest, f, indent=2)
    return summary, contrasts, manifest


def summarize_arms(hidden: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for arm, g in hidden.groupby("arm", sort=False):
        metrics = summarize_eval(g.to_dict(orient="records"))
        n = len(g)
        utility_se = bootstrap_utility_se(g, seed=stable_int(arm))
        rows.append(
            {
                "arm": arm,
                "n": n,
                "utility_mean": metrics["utility"],
                "utility_se": utility_se,
                "abs_error_mean": metrics["mean_abs_error"],
                "abs_error_se": float(g["abs_error"].std(ddof=1) / math.sqrt(n)),
                "coverage": metrics["coverage"],
                "length_mean": metrics["mean_length"],
                "length_se": float(g["length"].std(ddof=1) / math.sqrt(n)),
            }
        )
    order = {
        "source_informed_self_improving": 0,
        "target_only_self_improving": 1,
        "source_informed_one_shot": 2,
        "target_only_one_shot": 3,
        "declared_expert": 4,
    }
    out = pd.DataFrame(rows)
    return out.sort_values("arm", key=lambda s: s.map(order)).reset_index(drop=True)


def bootstrap_utility_se(group: pd.DataFrame, seed: int, reps: int = 400) -> float:
    rng = np.random.default_rng(seed)
    records = group.to_dict(orient="records")
    n = len(records)
    vals = []
    for _ in range(reps):
        idx = rng.integers(0, n, size=n)
        sample = [records[int(i)] for i in idx]
        vals.append(summarize_eval(sample)["utility"])
    return float(np.std(vals, ddof=1))


def paired_contrasts(hidden: pd.DataFrame) -> pd.DataFrame:
    unit_cols = ["target_family", "seed"]
    wide = hidden.pivot_table(index=unit_cols, columns="arm", values="abs_error", aggfunc="first")
    utility_wide = hidden.copy()
    miss = (utility_wide["covered"] < 0.5).astype(float)
    utility_wide["unit_loss"] = utility_wide["abs_error"] + 0.15 * utility_wide["length"] + 5.0 * miss
    loss_wide = utility_wide.pivot_table(index=unit_cols, columns="arm", values="unit_loss", aggfunc="first")
    specs = [
        ("target_self_minus_target_one_shot", "target_only_self_improving", "target_only_one_shot"),
        ("source_self_minus_target_self", "source_informed_self_improving", "target_only_self_improving"),
        ("source_self_minus_source_one_shot", "source_informed_self_improving", "source_informed_one_shot"),
        ("source_self_minus_declared_expert", "source_informed_self_improving", "declared_expert"),
    ]
    rows = []
    for name, better, worse in specs:
        diff = loss_wide[worse] - loss_wide[better]
        rows.append(
            {
                "contrast": name,
                "loss_reduction_mean": float(diff.mean()),
                "loss_reduction_se": float(diff.std(ddof=1) / math.sqrt(len(diff))),
                "paired_win_rate": float((diff > 0).mean()),
                "n_pairs": int(len(diff)),
            }
        )
    return pd.DataFrame(rows)


def fmt_mean_se(mean: float, se: float, digits: int = 3) -> str:
    return f"{mean:.{digits}f} $\\pm$ {se:.{digits}f}"


def arm_label(arm: str) -> str:
    return {
        "source_informed_self_improving": "Source-informed self-improving",
        "source_informed_one_shot": "Source-informed one-shot",
        "target_only_self_improving": "Target-only self-improving",
        "target_only_one_shot": "Target-only one-shot",
        "declared_expert": "Declared expert reference",
    }[arm]


def write_latex(path: Path, summary: pd.DataFrame, contrasts: pd.DataFrame, selected: pd.DataFrame) -> None:
    lines = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\caption{Validity-aware causal-effect inference benchmark. Utility is the negative validity-aware loss; larger is better. Absolute error is treatment-effect estimation error, coverage is empirical interval coverage across hidden datasets, and interval length is the mean confidence-interval length. Utility uncertainty is a bootstrap standard error for the aggregate operating-characteristic score; other entries after $\\pm$ are standard errors (SE) across hidden datasets.}")
    lines.append("\\label{tab:causal_inference_summary}")
    lines.append("\\begin{tabular}{lcccc}")
    lines.append("\\toprule")
    lines.append("Arm & Utility & Absolute error & Coverage & Interval length \\\\")
    lines.append("\\midrule")
    for _, row in summary.iterrows():
        lines.append(
            f"{arm_label(row['arm'])} & {row['utility_mean']:.3f} $\\pm$ {row['utility_se']:.3f} & "
            f"{fmt_mean_se(row['abs_error_mean'], row['abs_error_se'])} & "
            f"{row['coverage']:.3f} & {fmt_mean_se(row['length_mean'], row['length_se'])} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    lines.append("")
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\caption{Paired hidden-dataset contrasts for the causal-effect inference benchmark. Positive values mean the first arm in the contrast has lower hidden-dataset loss. The paired comparison uses a unit-level miss penalty, whereas Table \\ref{tab:causal_inference_summary} applies the coverage penalty after aggregating coverage by arm; the two tables therefore should not be subtracted algebraically. Entries after $\\pm$ are standard errors (SE).}")
    lines.append("\\label{tab:causal_inference_contrasts}")
    lines.append("\\begin{tabular}{lccc}")
    lines.append("\\toprule")
    lines.append("Contrast & Loss reduction & Win rate & Pairs \\\\")
    lines.append("\\midrule")
    labels = {
        "target_self_minus_target_one_shot": "Target self $-$ target one-shot",
        "source_self_minus_target_self": "Source self $-$ target self",
        "source_self_minus_source_one_shot": "Source self $-$ source one-shot",
        "source_self_minus_declared_expert": "Source self $-$ expert reference",
    }
    for _, row in contrasts.iterrows():
        lines.append(
            f"{labels[row['contrast']]} & {fmt_mean_se(row['loss_reduction_mean'], row['loss_reduction_se'])} & "
            f"{100 * row['paired_win_rate']:.1f}\\% & {int(row['n_pairs'])} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")
    path.write_text("\n".join(lines) + "\n")


def plot_summary(path: Path, summary: pd.DataFrame) -> None:
    labels = [arm_label(a).replace(" ", "\n") for a in summary["arm"]]
    fig, ax = plt.subplots(figsize=(7.5, 3.8))
    ax.bar(labels, summary["utility_mean"], color=["#2b6cb0", "#38a169", "#805ad5", "#dd6b20", "#718096"])
    ax.set_ylabel("Hidden utility (higher is better)")
    ax.set_title("Causal inferential-procedure selection")
    ax.axhline(0, color="black", linewidth=0.8)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(RESULTS))
    parser.add_argument("--public-seed", type=int, default=707001)
    parser.add_argument("--hidden-seed", type=int, default=909001)
    parser.add_argument("--public-target-reps", type=int, default=6)
    parser.add_argument("--public-source-reps", type=int, default=8)
    parser.add_argument("--hidden-reps", type=int, default=36)
    parser.add_argument("--n-public", type=int, default=450)
    parser.add_argument("--n-hidden", type=int, default=700)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary, contrasts, manifest = run_experiment(args)
    print(summary.to_string(index=False))
    print()
    print(contrasts.to_string(index=False))
    print()
    print(json.dumps({k: manifest[k] for k in ("selected_procedures_hash", "hidden_records_hash")}, indent=2))


if __name__ == "__main__":
    main()

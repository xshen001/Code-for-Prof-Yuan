#!/usr/bin/env python3
"""Source-calibrated interval-transfer variant of the causal benchmark.

This is an experimental extension of run_causal_inference_experiment.py.  The
baseline causal benchmark transfers source information only by ranking a fixed
library of inferential procedures.  This variant lets source validation records
construct new candidate rules: calibrated interval multipliers and stacked point
estimators with source/target-shrunk interval calibration.  Hidden datasets are
still used only after a rule is selected and frozen from public records.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
from dataclasses import asdict, dataclass
from pathlib import Path

os.environ.setdefault("MPLBACKEND", "Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from run_causal_inference_experiment import (
    DECLARED_EXPERT,
    FAMILIES,
    NOMINAL_COVERAGE,
    PROCEDURES,
    PROC_BY_NAME,
    SOURCE_MAP,
    TARGET_FAMILIES,
    TARGET_ONE_SHOT,
    Z_VALUE,
    estimate,
    generate_dataset,
    stable_hash,
)


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results_interval_transfer"
ESTIMATE_CACHE: dict[tuple[str, str, int, int, int], tuple[float, float, float]] = {}


@dataclass(frozen=True)
class Rule:
    name: str
    proc_names: tuple[str, ...]
    weights: tuple[float, ...]
    ci_mult: float
    origin: str


@dataclass(frozen=True)
class RuleEstimate:
    ate: float
    se: float
    lo: float
    hi: float


def sklearn_seed(seed: int) -> int:
    return int(seed) % (2**32)


def stable_int(text: str) -> int:
    return int(hashlib.sha256(text.encode("utf-8")).hexdigest()[:8], 16)


def base_rule(proc_name: str, ci_mult: float | None = None, origin: str = "fixed") -> Rule:
    proc = PROC_BY_NAME[proc_name]
    mult = proc.ci_mult if ci_mult is None else float(ci_mult)
    return Rule(
        name=f"{origin}:{proc_name}:c{mult:.3f}",
        proc_names=(proc_name,),
        weights=(1.0,),
        ci_mult=mult,
        origin=origin,
    )


def stack_rule(proc_names: tuple[str, ...], weights: tuple[float, ...], ci_mult: float, origin: str) -> Rule:
    proc_tag = "+".join(proc_names)
    weight_tag = "-".join(f"{w:.2f}" for w in weights)
    return Rule(
        name=f"{origin}:stack:{proc_tag}:w{weight_tag}:c{ci_mult:.3f}",
        proc_names=proc_names,
        weights=weights,
        ci_mult=float(ci_mult),
        origin=origin,
    )


def rule_estimate(data, rule: Rule, seed: int) -> RuleEstimate:
    estimates = []
    for j, proc_name in enumerate(rule.proc_names):
        estimates.append(estimate(data, PROC_BY_NAME[proc_name], seed + 7919 * (j + 1)))
    weights = np.asarray(rule.weights, dtype=float)
    weights = weights / weights.sum()
    ates = np.asarray([est.ate for est in estimates], dtype=float)
    ses = np.asarray([est.se for est in estimates], dtype=float)
    ate = float(np.sum(weights * ates))
    # Mixture-style uncertainty: within-procedure SE plus between-procedure spread.
    var = float(np.sum(weights * (ses**2 + (ates - ate) ** 2)))
    se = max(math.sqrt(max(var, 0.0)), 1e-8)
    half = Z_VALUE * rule.ci_mult * se
    return RuleEstimate(ate=ate, se=se, lo=ate - half, hi=ate + half)


def cached_base_estimate(family_name: str, proc_name: str, data_seed: int, n: int, fit_seed: int) -> tuple[float, float, float]:
    key = (family_name, proc_name, data_seed, n, fit_seed)
    if key not in ESTIMATE_CACHE:
        data = generate_dataset(FAMILIES[family_name], data_seed, n)
        est = estimate(data, PROC_BY_NAME[proc_name], fit_seed)
        ESTIMATE_CACHE[key] = (float(est.ate), float(est.se), float(data.true_ate))
    return ESTIMATE_CACHE[key]


def rule_estimate_cached(family_name: str, rule: Rule, data_seed: int, n: int) -> tuple[RuleEstimate, float]:
    estimates = []
    true_value = None
    for j, proc_name in enumerate(rule.proc_names):
        ate, se, true_ate = cached_base_estimate(
            family_name,
            proc_name,
            data_seed,
            n,
            data_seed + 17 + 7919 * (j + 1),
        )
        estimates.append((ate, se))
        true_value = true_ate
    weights = np.asarray(rule.weights, dtype=float)
    weights = weights / weights.sum()
    ates = np.asarray([est[0] for est in estimates], dtype=float)
    ses = np.asarray([est[1] for est in estimates], dtype=float)
    ate = float(np.sum(weights * ates))
    var = float(np.sum(weights * (ses**2 + (ates - ate) ** 2)))
    se = max(math.sqrt(max(var, 0.0)), 1e-8)
    half = Z_VALUE * rule.ci_mult * se
    assert true_value is not None
    return RuleEstimate(ate=ate, se=se, lo=ate - half, hi=ate + half), float(true_value)


def eval_rule_on_seed(family_name: str, rule: Rule, seed: int, n: int) -> dict[str, object]:
    est, true_ate = rule_estimate_cached(family_name, rule, seed, n)
    err = abs(est.ate - true_ate)
    return {
        "family": family_name,
        "rule": rule.name,
        "seed": seed,
        "true_ate": true_ate,
        "estimate": est.ate,
        "abs_error": err,
        "covered": float(est.lo <= true_ate <= est.hi),
        "length": est.hi - est.lo,
    }


def eval_rule_many(rule: Rule, family_names: tuple[str, ...], seed_base: int, reps: int, n: int) -> pd.DataFrame:
    rows = []
    for f_index, family_name in enumerate(family_names):
        for r in range(reps):
            seed = seed_base + 100_000 * f_index + 10_000 * r
            rows.append(eval_rule_on_seed(family_name, rule, seed, n))
    return pd.DataFrame(rows)


def summarize_records(records: pd.DataFrame) -> dict[str, float]:
    coverage = float(records["covered"].mean())
    mean_error = float(records["abs_error"].mean())
    mean_length = float(records["length"].mean())
    loss = mean_error + 0.15 * mean_length + 5.0 * max(0.0, NOMINAL_COVERAGE - coverage) ** 2
    return {
        "mean_abs_error": mean_error,
        "coverage": coverage,
        "mean_length": mean_length,
        "loss": loss,
        "utility": -loss,
    }


def quantile_ci_mult(records: pd.DataFrame, min_mult: float = 0.6, max_mult: float = 2.5) -> float:
    denom = Z_VALUE * np.maximum(np.asarray(records["se"], dtype=float), 1e-8)
    ratios = np.asarray(records["abs_error"], dtype=float) / denom
    if len(ratios) == 0 or not np.all(np.isfinite(ratios)):
        return 1.3
    q = float(np.quantile(ratios, NOMINAL_COVERAGE, method="higher"))
    return float(np.clip(q, min_mult, max_mult))


def calibration_records(rule: Rule, family_names: tuple[str, ...], seed_base: int, reps: int, n: int) -> pd.DataFrame:
    rows = []
    unit = base_rule(rule.proc_names[0], ci_mult=1.0, origin="calibration_unit") if len(rule.proc_names) == 1 else Rule(
        name=f"calibration_unit:{rule.name}",
        proc_names=rule.proc_names,
        weights=rule.weights,
        ci_mult=1.0,
        origin="calibration_unit",
    )
    for f_index, family_name in enumerate(family_names):
        for r in range(reps):
            seed = seed_base + 100_000 * f_index + 10_000 * r
            est, true_ate = rule_estimate_cached(family_name, unit, seed, n)
            rows.append(
                {
                    "family": family_name,
                    "seed": seed,
                    "abs_error": abs(est.ate - true_ate),
                    "se": est.se,
                }
            )
    return pd.DataFrame(rows)


def calibrate_rule(
    skeleton: Rule,
    target_families: tuple[str, ...],
    source_families: tuple[str, ...],
    target_seed: int,
    source_seed: int,
    target_reps: int,
    source_reps: int,
    n_public: int,
    lam: float,
    origin: str,
) -> Rule:
    target_cal = calibration_records(skeleton, target_families, target_seed, target_reps, n_public)
    source_cal = calibration_records(skeleton, source_families, source_seed, source_reps, n_public)
    c_target = quantile_ci_mult(target_cal)
    c_source = quantile_ci_mult(source_cal)
    c = (1.0 - lam) * c_target + lam * c_source
    if len(skeleton.proc_names) == 1:
        return base_rule(skeleton.proc_names[0], ci_mult=c, origin=f"{origin}_lt{lam:.2f}")
    return stack_rule(skeleton.proc_names, skeleton.weights, c, origin=f"{origin}_lt{lam:.2f}")


def calibration_multipliers(
    skeleton: Rule,
    target_families: tuple[str, ...],
    source_families: tuple[str, ...],
    target_seed: int,
    source_seed: int,
    target_reps: int,
    source_reps: int,
    n_public: int,
) -> tuple[float, float]:
    target_cal = calibration_records(skeleton, target_families, target_seed, target_reps, n_public)
    source_cal = calibration_records(skeleton, source_families, source_seed, source_reps, n_public)
    return quantile_ci_mult(target_cal), quantile_ci_mult(source_cal)


def with_ci_mult(skeleton: Rule, ci_mult: float, origin: str) -> Rule:
    if len(skeleton.proc_names) == 1:
        return base_rule(skeleton.proc_names[0], ci_mult=ci_mult, origin=origin)
    return stack_rule(skeleton.proc_names, skeleton.weights, ci_mult, origin=origin)


def softmax_weights(losses: list[float], temperature: float = 0.04) -> tuple[float, ...]:
    vals = -np.asarray(losses, dtype=float) / max(temperature, 1e-6)
    vals -= vals.max()
    w = np.exp(vals)
    w = w / w.sum()
    return tuple(float(x) for x in w)


def build_source_stacks(source_scores: pd.DataFrame) -> list[Rule]:
    ranked = source_scores.sort_values("loss")
    rules: list[Rule] = []
    for k in (2, 3, 4):
        top = ranked.head(k)
        procs = tuple(str(x) for x in top["proc_name"])
        weights = softmax_weights([float(x) for x in top["loss"]])
        rules.append(stack_rule(procs, weights, 1.0, origin=f"source_stack_top{k}"))
    return rules


def score_candidates(
    candidates: list[Rule],
    families: tuple[str, ...],
    seed_base: int,
    reps: int,
    n: int,
) -> pd.DataFrame:
    rows = []
    for rule in candidates:
        metrics = summarize_records(eval_rule_many(rule, families, seed_base, reps, n))
        rows.append({"rule_name": rule.name, "rule": rule, **metrics})
    return pd.DataFrame(rows)


def select_for_target(target: str, args: argparse.Namespace, master_offset: int = 0) -> dict[str, Rule | dict[str, object]]:
    target_index = TARGET_FAMILIES.index(target) + 1
    # Keep target-validation and source-validation seed namespaces disjoint.
    # This is not needed for correctness, but it makes the external audit cleaner.
    target_seed = args.public_seed + master_offset + 1_000_000 * target_index + 11_000
    source_seed = args.public_seed + master_offset + 1_000_000 * target_index + 22_000
    source_families = SOURCE_MAP[target]
    target_families = (target,)

    allowed = tuple(name.strip() for name in args.procedure_names.split(",") if name.strip())
    fixed_candidates = [base_rule(name) for name in allowed]
    fixed_target_scores = score_candidates(fixed_candidates, target_families, target_seed, args.public_target_reps, args.n_public)
    fixed_source_scores = score_candidates(fixed_candidates, source_families, source_seed, args.public_source_reps, args.n_public)
    fixed_source_scores["proc_name"] = fixed_source_scores["rule"].map(lambda r: r.proc_names[0])

    target_calibrated = []
    source_calibrated = []
    shrink_calibrated = []
    for rule in fixed_candidates:
        c_target, c_source = calibration_multipliers(
            rule,
            target_families,
            source_families,
            target_seed,
            source_seed,
            args.public_target_reps,
            args.public_source_reps,
            args.n_public,
        )
        target_calibrated.append(with_ci_mult(rule, c_target, "target_cal"))
        source_calibrated.append(with_ci_mult(rule, c_source, "source_cal"))
        for lam in (0.50, 0.75):
            shrink_calibrated.append(with_ci_mult(rule, (1.0 - lam) * c_target + lam * c_source, f"shrink_cal_lt{lam:.2f}"))
    source_stacks_raw = build_source_stacks(fixed_source_scores)
    source_stacks = []
    for rule in source_stacks_raw:
        c_target, c_source = calibration_multipliers(
            rule,
            target_families,
            source_families,
            target_seed,
            source_seed,
            args.public_target_reps,
            args.public_source_reps,
            args.n_public,
        )
        for lam in (0.50, 0.75, 1.00):
            source_stacks.append(with_ci_mult(rule, (1.0 - lam) * c_target + lam * c_source, f"source_stack_cal_lt{lam:.2f}"))

    target_candidates = fixed_candidates + target_calibrated
    source_one_candidates = fixed_candidates + source_calibrated + source_stacks
    source_self_candidates = fixed_candidates + target_calibrated + shrink_calibrated + source_stacks

    target_scores = score_candidates(target_candidates, target_families, target_seed, args.public_target_reps, args.n_public)
    source_one_scores = score_candidates(source_one_candidates, source_families, source_seed, args.public_source_reps, args.n_public)
    source_self_target_scores = score_candidates(source_self_candidates, target_families, target_seed, args.public_target_reps, args.n_public)
    source_self_source_scores = score_candidates(source_self_candidates, source_families, source_seed, args.public_source_reps, args.n_public)
    source_lookup = dict(zip(source_self_source_scores["rule_name"], source_self_source_scores["loss"]))
    source_self_target_scores["combined_loss"] = [
        0.70 * float(row.loss) + 0.30 * float(source_lookup[row.rule_name])
        for row in source_self_target_scores.itertuples(index=False)
    ]
    target_best = target_scores.sort_values("loss").iloc[0]
    source_one_best = source_one_scores.sort_values("loss").iloc[0]
    source_self_best = source_self_target_scores.sort_values("combined_loss").iloc[0]
    return {
        "declared_expert": base_rule(DECLARED_EXPERT),
        "target_only_one_shot": base_rule(TARGET_ONE_SHOT),
        "target_only_self_improving": target_best["rule"],
        "source_informed_one_shot": source_one_best["rule"],
        "source_informed_self_improving": source_self_best["rule"],
        "diagnostics": {
            "target_best_public_loss": float(target_best["loss"]),
            "source_one_public_source_loss": float(source_one_best["loss"]),
            "source_self_public_target_loss": float(source_self_best["loss"]),
            "source_self_combined_loss": float(source_self_best["combined_loss"]),
        },
    }


def run_one_protocol(args: argparse.Namespace, out: Path, master_seed: int, master_index: int) -> dict[str, object]:
    public_seed = args.public_seed_base + 100_000 * master_index + master_seed
    hidden_seed = args.hidden_seed_base + 100_000 * master_index + master_seed
    local_args = argparse.Namespace(**vars(args))
    local_args.public_seed = public_seed
    selected_rows = []
    hidden_rows = []
    diagnostics = {}
    for t_index, target in enumerate(TARGET_FAMILIES):
        selected = select_for_target(target, local_args)
        diagnostics[target] = selected.pop("diagnostics")
        for arm, rule in selected.items():
            assert isinstance(rule, Rule)
            selected_rows.append(
                {
                    "master_seed_index": master_index,
                    "master_seed": master_seed,
                    "target_family": target,
                    "arm": arm,
                    "rule_name": rule.name,
                    "origin": rule.origin,
                    "proc_names": "+".join(rule.proc_names),
                    "weights": "+".join(f"{w:.4f}" for w in rule.weights),
                    "ci_mult": rule.ci_mult,
                    "public_seed": public_seed,
                    "hidden_seed_base": hidden_seed,
                }
            )
            for j in range(args.hidden_reps):
                seed = hidden_seed + 1_000_000 * (t_index + 1) + 10_000 * j
                rec = eval_rule_on_seed(target, rule, seed, args.n_hidden)
                rec.update(
                    {
                        "master_seed_index": master_index,
                        "master_seed": master_seed,
                        "target_family": target,
                        "arm": arm,
                    }
                )
                hidden_rows.append(rec)
    run_dir = out / "runs" / f"master_seed_{master_index:02d}_{master_seed}"
    run_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(selected_rows).to_csv(run_dir / "selected_rules.csv", index=False)
    pd.DataFrame(hidden_rows).to_csv(run_dir / "hidden_records.csv", index=False)
    (run_dir / "diagnostics.json").write_text(json.dumps(diagnostics, indent=2))
    return {
        "index": master_index,
        "master_seed": master_seed,
        "public_seed": public_seed,
        "hidden_seed": hidden_seed,
        "run_dir": str(run_dir),
        "returncode": 0,
    }


def build_unit_scores(hidden: pd.DataFrame) -> pd.DataFrame:
    rows = []
    unit_cols = ["master_seed_index", "master_seed", "target_family", "arm"]
    for keys, group in hidden.groupby(unit_cols, sort=True):
        metrics = summarize_records(group)
        rows.append(
            {
                "master_seed_index": int(keys[0]),
                "master_seed": int(keys[1]),
                "target_family": str(keys[2]),
                "arm": str(keys[3]),
                "n_hidden_records": int(len(group)),
                "utility": metrics["utility"],
                "abs_error": metrics["mean_abs_error"],
                "coverage": metrics["coverage"],
                "length": metrics["mean_length"],
            }
        )
    return pd.DataFrame(rows)


def summarize_units(unit_scores: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for arm, group in unit_scores.groupby("arm", sort=False):
        n = len(group)
        rows.append(
            {
                "arm": arm,
                "n": int(n),
                "utility_mean": float(group["utility"].mean()),
                "utility_se": float(group["utility"].std(ddof=1) / math.sqrt(n)) if n > 1 else 0.0,
                "abs_error_mean": float(group["abs_error"].mean()),
                "abs_error_se": float(group["abs_error"].std(ddof=1) / math.sqrt(n)) if n > 1 else 0.0,
                "coverage": float(group["coverage"].mean()),
                "length_mean": float(group["length"].mean()),
                "length_se": float(group["length"].std(ddof=1) / math.sqrt(n)) if n > 1 else 0.0,
            }
        )
    order = {
        "source_informed_self_improving": 0,
        "target_only_self_improving": 1,
        "source_informed_one_shot": 2,
        "target_only_one_shot": 3,
        "declared_expert": 4,
    }
    out = pd.DataFrame(rows)
    return out.sort_values("arm", key=lambda s: s.map(order)).reset_index(drop=True)


def paired_unit_contrasts(unit_scores: pd.DataFrame) -> pd.DataFrame:
    wide = unit_scores.pivot_table(
        index=["master_seed_index", "master_seed", "target_family"],
        columns="arm",
        values="utility",
        aggfunc="first",
    )
    specs = [
        ("target_self_minus_target_one_shot", "target_only_self_improving", "target_only_one_shot"),
        ("source_self_minus_target_self", "source_informed_self_improving", "target_only_self_improving"),
        ("source_self_minus_source_one_shot", "source_informed_self_improving", "source_informed_one_shot"),
        ("source_self_minus_declared_expert", "source_informed_self_improving", "declared_expert"),
    ]
    rows = []
    for name, better, worse in specs:
        diff = wide[better] - wide[worse]
        rows.append(
            {
                "contrast": name,
                "utility_gain_mean": float(diff.mean()),
                "utility_gain_se": float(diff.std(ddof=1) / math.sqrt(len(diff))) if len(diff) > 1 else 0.0,
                "paired_win_rate": float((diff > 0).mean()),
                "n_pairs": int(len(diff)),
            }
        )
    return pd.DataFrame(rows)


def arm_label(arm: str) -> str:
    return {
        "source_informed_self_improving": "Source-informed self-improving",
        "source_informed_one_shot": "Source-informed one-shot",
        "target_only_self_improving": "Target-only self-improving",
        "target_only_one_shot": "Target-only one-shot",
        "declared_expert": "Declared expert reference",
    }[arm]


def write_latex(path: Path, summary: pd.DataFrame, contrasts: pd.DataFrame) -> None:
    def mse(mean: float, se: float) -> str:
        return f"{mean:.3f} $\\pm$ {se:.3f}"

    lines = [
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Experimental source-calibrated interval-transfer causal benchmark. Utility is the negative validity-aware loss; larger is better. Standard errors are computed across target-family by master-seed units.}",
        "\\label{tab:causal_interval_transfer_summary}",
        "\\begin{tabular}{lcccc}",
        "\\toprule",
        "Arm & Utility & Absolute error & Coverage & Interval length \\\\",
        "\\midrule",
    ]
    for _, row in summary.iterrows():
        lines.append(
            f"{arm_label(row['arm'])} & {mse(row['utility_mean'], row['utility_se'])} & "
            f"{mse(row['abs_error_mean'], row['abs_error_se'])} & {row['coverage']:.3f} & "
            f"{mse(row['length_mean'], row['length_se'])} \\\\"
        )
    lines.extend(
        [
            "\\bottomrule",
            "\\end{tabular}",
            "\\end{table}",
            "",
            "\\begin{table}[t]",
            "\\centering",
            "\\caption{Paired contrasts for the source-calibrated interval-transfer causal benchmark. Positive values mean the first arm has larger validity-aware utility.}",
            "\\label{tab:causal_interval_transfer_contrasts}",
            "\\begin{tabular}{lccc}",
            "\\toprule",
            "Contrast & Utility gain & Win rate & Pairs \\\\",
            "\\midrule",
        ]
    )
    labels = {
        "target_self_minus_target_one_shot": "Target self $-$ target one-shot",
        "source_self_minus_target_self": "Source self $-$ target self",
        "source_self_minus_source_one_shot": "Source self $-$ source one-shot",
        "source_self_minus_declared_expert": "Source self $-$ expert reference",
    }
    for _, row in contrasts.iterrows():
        lines.append(
            f"{labels[row['contrast']]} & {mse(row['utility_gain_mean'], row['utility_gain_se'])} & "
            f"{100 * row['paired_win_rate']:.1f}\\% & {int(row['n_pairs'])} \\\\"
        )
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\end{table}", ""])
    path.write_text("\n".join(lines))


def plot_summary(path: Path, summary: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(7.8, 3.8))
    ax.bar([arm_label(a).replace(" ", "\n") for a in summary["arm"]], summary["utility_mean"])
    ax.set_ylabel("Hidden utility (higher is better)")
    ax.set_title("Source-calibrated interval transfer")
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def parse_ints(text: str) -> list[int]:
    vals = [int(x.strip()) for x in text.split(",") if x.strip()]
    if not vals:
        raise ValueError("At least one master seed is required.")
    return vals


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(RESULTS))
    parser.add_argument("--master-seeds", required=True)
    parser.add_argument("--public-seed-base", type=int, required=True)
    parser.add_argument("--hidden-seed-base", type=int, required=True)
    parser.add_argument("--public-target-reps", type=int, default=6)
    parser.add_argument("--public-source-reps", type=int, default=8)
    parser.add_argument("--hidden-reps", type=int, default=36)
    parser.add_argument("--n-public", type=int, default=450)
    parser.add_argument("--n-hidden", type=int, default=700)
    parser.add_argument(
        "--procedure-names",
        default=",".join(proc.name for proc in PROCEDURES),
        help="Comma-separated candidate procedures used to construct the adaptive libraries.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    master_seeds = parse_ints(args.master_seeds)
    run_records = []
    for index, master_seed in enumerate(master_seeds, start=1):
        run_records.append(run_one_protocol(args, out, master_seed, index))

    hidden = pd.concat(
        [pd.read_csv(Path(record["run_dir"]) / "hidden_records.csv") for record in run_records],
        ignore_index=True,
    )
    selected = pd.concat(
        [pd.read_csv(Path(record["run_dir"]) / "selected_rules.csv") for record in run_records],
        ignore_index=True,
    )
    hidden.to_csv(out / "hidden_records.csv", index=False)
    selected.to_csv(out / "selected_rules.csv", index=False)
    units = build_unit_scores(hidden)
    summary = summarize_units(units)
    contrasts = paired_unit_contrasts(units)
    units.to_csv(out / "family_seed_unit_scores.csv", index=False)
    summary.to_csv(out / "summary.csv", index=False)
    contrasts.to_csv(out / "contrasts.csv", index=False)
    write_latex(out / "latex_tables.tex", summary, contrasts)
    plot_summary(out / "causal_interval_transfer_summary.pdf", summary)

    manifest = {
        "experiment": "causal_interval_transfer_experiment",
        "protocol": "source_calibrated_interval_stacking_transfer_v1",
        "base_script_sha256": stable_hash(Path(__file__).read_text()),
        "master_seeds": master_seeds,
        "public_seed_base": args.public_seed_base,
        "hidden_seed_base": args.hidden_seed_base,
        "public_target_reps": args.public_target_reps,
        "public_source_reps": args.public_source_reps,
        "hidden_reps_per_family_per_master_seed": args.hidden_reps,
        "n_public": args.n_public,
        "n_hidden": args.n_hidden,
        "candidate_construction": "fixed procedures, target-calibrated intervals, source-calibrated intervals, shrinkage-calibrated intervals, and source-ranked stacks",
        "score": "utility = -[mean absolute error + 0.15 mean interval length + 5 max(0, 0.90 - coverage)^2]",
        "run_records": run_records,
        "selected_rules_hash": stable_hash(selected.to_dict(orient="records")),
        "hidden_records_hash": stable_hash(hidden.to_dict(orient="records")),
        "python": platform.python_version(),
        "platform": platform.platform(),
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(summary.to_string(index=False))
    print()
    print(contrasts.to_string(index=False))
    print()
    print(json.dumps({k: manifest[k] for k in ("selected_rules_hash", "hidden_records_hash")}, indent=2))


if __name__ == "__main__":
    main()

# Matbench Hidden-Resampling Foundation-Stack Audit

This run uses curator-seeded random train/test splits from public Matbench labeled records.
Candidate selection uses only the resampled training part and inner validation splits.
The hidden resampled test split is scored after each arm's output is frozen.
The expert-reference arm is a predeclared, runnable expert-style materials-informatics rule scored on the same hidden resamples.

- Protocol: `curator_seeded_hidden_resampling_public_matbench_chgnet_foundation_stack_with_expert_reference_v1`
- Tasks: matbench_dielectric, matbench_jdft2d, matbench_log_gvrh, matbench_log_kvrh
- Split ids: 0, 1, 2, 3, 4
- Number of arm-by-task-split records: 100

Primary comparison:
- Source-informed self-improving utility: -0.1930 (0.0072)
- Target-only self-improving utility: -0.1995 (0.0076)
- Source-informed gain over target-only self-improving: 0.0065 (0.0019); win rate 0.850
- Expert-reference utility: -0.3100 (0.0474)
- Source-informed gain over expert reference: 0.1170 (0.0449); win rate 1.000

Caveat: this is hidden resampling of public labels, not an official Matbench leaderboard submission and not a new external materials dataset. The expert-reference arm is not substituted for the official Matbench leaderboard score; it is a same-split declared comparator.

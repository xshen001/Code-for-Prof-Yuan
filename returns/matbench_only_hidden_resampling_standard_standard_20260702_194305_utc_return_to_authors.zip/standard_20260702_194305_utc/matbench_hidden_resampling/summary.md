# Matbench Hidden-Resampling Foundation-Stack Audit

This run uses curator-seeded random train/test splits from public Matbench labeled records.
Candidate selection uses only the resampled training part and inner validation splits.
The hidden resampled test split is scored after each arm's output is frozen.

- Protocol: `curator_seeded_hidden_resampling_public_matbench_chgnet_foundation_stack_v1`
- Tasks: matbench_dielectric, matbench_jdft2d, matbench_log_gvrh, matbench_log_kvrh
- Split ids: 0, 1, 2, 3, 4
- Number of arm-by-task-split records: 80

Primary comparison:
- Source-informed self-improving utility: -0.1953 (0.0139)
- Target-only self-improving utility: -0.2028 (0.0143)
- Source-informed gain over target-only self-improving: 0.0075 (0.0014); win rate 0.900

Caveat: this is hidden resampling of public labels, not an official Matbench leaderboard submission and not a new external materials dataset.

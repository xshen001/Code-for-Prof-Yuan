#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from analyze_tabarena_internal_elo import (
    aggregate_metrics,
    fit_bradley_terry_elo,
    markdown_table,
)


ARMS = [
    "target_only_one_shot",
    "target_only_self_improving",
    "source_informed_one_shot",
    "source_informed_self_improving",
    "source_informed_gated_self_improving",
    "source_informed_safeguarded_self_improving",
    "expert_reference",
]

CONTRASTS = [
    ("source_informed_self_improving", "expert_reference"),
    ("source_informed_safeguarded_self_improving", "expert_reference"),
    ("source_informed_self_improving", "target_only_self_improving"),
    ("source_informed_safeguarded_self_improving", "target_only_self_improving"),
]


def attach_metadata_if_needed(rows: pd.DataFrame, metadata_csv: str | None) -> pd.DataFrame:
    if "problem_type" in rows.columns and rows["problem_type"].notna().all():
        return rows
    if metadata_csv is None:
        raise ValueError("Selections lack problem_type; pass --metadata-csv to attach task metadata.")
    meta = pd.read_csv(metadata_csv, usecols=lambda c: c in {"dataset", "fold", "metric", "problem_type"})
    meta = meta.drop_duplicates(["dataset", "fold"])
    return rows.drop(columns=[c for c in ["metric", "problem_type"] if c in rows.columns]).merge(
        meta, on=["dataset", "fold"], how="left"
    )


def make_wide(rows: pd.DataFrame, value_col: str = "metric_error") -> pd.DataFrame:
    grouped = rows.groupby(["dataset", "arm"], sort=False)[value_col].mean().reset_index()
    wide = grouped.pivot(index="dataset", columns="arm", values=value_col)
    arms = [arm for arm in ARMS if arm in wide.columns]
    return wide[arms].dropna()


def point_summary(rows: pd.DataFrame) -> pd.DataFrame:
    wide = make_wide(rows, "metric_error")
    arms = [arm for arm in ARMS if arm in wide.columns]
    elo = fit_bradley_terry_elo(wide, arms)
    agg = aggregate_metrics(wide, arms)
    out = elo.merge(agg, on="arm", how="left")
    if "loss_norm" in rows.columns:
        loss = (
            rows.groupby("arm", sort=False)
            .agg(mean_loss_norm=("loss_norm", "mean"), median_loss_norm=("loss_norm", "median"))
            .reset_index()
        )
        out = out.merge(loss, on="arm", how="left")
    return out.sort_values("internal_elo_mean1000", ascending=False)


def contrast_row(summary: pd.DataFrame, left: str, right: str) -> dict[str, Any] | None:
    if left not in set(summary["arm"]) or right not in set(summary["arm"]):
        return None
    lrow = summary[summary["arm"] == left].iloc[0]
    rrow = summary[summary["arm"] == right].iloc[0]
    return {
        "contrast": f"{left} - {right}",
        "elo_gain": float(lrow["internal_elo_mean1000"] - rrow["internal_elo_mean1000"]),
        "rank_gain": float(rrow["avg_rank"] - lrow["avg_rank"]),
        "native_error_gain": float(rrow["mean_native_error"] - lrow["mean_native_error"]),
        "loss_norm_gain": float(rrow.get("mean_loss_norm", np.nan) - lrow.get("mean_loss_norm", np.nan)),
    }


def bootstrap_contrasts(rows: pd.DataFrame, reps: int, seed: int) -> pd.DataFrame:
    datasets = np.array(sorted(rows["dataset"].drop_duplicates()))
    if len(datasets) == 0:
        return pd.DataFrame()
    rng = np.random.default_rng(seed)
    records = []
    for _ in range(int(reps)):
        parts = []
        for boot_id, dataset in enumerate(rng.choice(datasets, size=len(datasets), replace=True)):
            part = rows[rows["dataset"] == dataset].copy()
            part["_boot_dataset"] = boot_id
            parts.append(part)
        boot = pd.concat(parts, ignore_index=True)
        grouped = boot.groupby(["_boot_dataset", "dataset", "arm"], sort=False)["metric_error"].mean().reset_index()
        wide = grouped.pivot(index=["_boot_dataset", "dataset"], columns="arm", values="metric_error")
        arms = [arm for arm in ARMS if arm in wide.columns]
        wide = wide[arms].dropna()
        if wide.empty:
            continue
        summary = fit_bradley_terry_elo(wide, arms).merge(aggregate_metrics(wide, arms), on="arm", how="left")
        for left, right in CONTRASTS:
            row = contrast_row(summary, left, right)
            if row is not None:
                records.append(row)
    boot = pd.DataFrame(records)
    if boot.empty:
        return boot
    return (
        boot.groupby("contrast")
        .agg(
            elo_gain_mean=("elo_gain", "mean"),
            elo_gain_ci_low=("elo_gain", lambda x: np.quantile(x, 0.025)),
            elo_gain_ci_high=("elo_gain", lambda x: np.quantile(x, 0.975)),
            rank_gain_mean=("rank_gain", "mean"),
            rank_gain_ci_low=("rank_gain", lambda x: np.quantile(x, 0.025)),
            rank_gain_ci_high=("rank_gain", lambda x: np.quantile(x, 0.975)),
            native_error_gain_mean=("native_error_gain", "mean"),
            native_error_gain_ci_low=("native_error_gain", lambda x: np.quantile(x, 0.025)),
            native_error_gain_ci_high=("native_error_gain", lambda x: np.quantile(x, 0.975)),
        )
        .reset_index()
    )


def problem_type_summary(rows: pd.DataFrame) -> pd.DataFrame:
    return (
        rows[["problem_type", "dataset", "fold", "metric"]]
        .drop_duplicates()
        .groupby("problem_type", sort=True)
        .agg(
            n_datasets=("dataset", "nunique"),
            n_task_folds=("dataset", "size"),
            metrics=("metric", lambda x: ",".join(sorted(set(str(v) for v in x if pd.notna(v))))),
        )
        .reset_index()
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selections", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--metadata-csv", default=None)
    parser.add_argument("--bootstrap-reps", type=int, default=1000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260707)
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = attach_metadata_if_needed(pd.read_csv(args.selections), args.metadata_csv)
    rows = rows.dropna(subset=["problem_type", "metric_error"]).copy()
    rows["problem_type"] = rows["problem_type"].astype(str)

    type_rows = []
    contrast_rows = []
    boot_rows = []
    for problem_type, group in rows.groupby("problem_type", sort=True):
        point = point_summary(group)
        point.insert(0, "problem_type", problem_type)
        type_rows.append(point)
        for left, right in CONTRASTS:
            row = contrast_row(point, left, right)
            if row is not None:
                row["problem_type"] = problem_type
                contrast_rows.append(row)
        boot = bootstrap_contrasts(group, args.bootstrap_reps, args.bootstrap_seed)
        if not boot.empty:
            boot.insert(0, "problem_type", problem_type)
            boot_rows.append(boot)

    type_summary = problem_type_summary(rows)
    point_summary_df = pd.concat(type_rows, ignore_index=True) if type_rows else pd.DataFrame()
    contrast_summary_df = pd.DataFrame(contrast_rows)
    bootstrap_df = pd.concat(boot_rows, ignore_index=True) if boot_rows else pd.DataFrame()

    type_summary.to_csv(out_dir / "type_task_summary.csv", index=False)
    point_summary_df.to_csv(out_dir / "type_point_summary.csv", index=False)
    contrast_summary_df.to_csv(out_dir / "type_contrast_summary.csv", index=False)
    bootstrap_df.to_csv(out_dir / "type_bootstrap_contrasts.csv", index=False)

    with (out_dir / "type_aware_evaluation_summary.md").open("w") as fh:
        fh.write("# Type-stratified TabArena evaluation\n\n")
        fh.write("Native losses are compared only within problem type. Internal Elo is fit within type from dataset-level pairwise wins; normalized loss is reported only within type.\n\n")
        fh.write("## Task Types\n\n")
        fh.write(markdown_table(type_summary))
        fh.write("\n\n## Point Summaries\n\n")
        fh.write(markdown_table(point_summary_df))
        fh.write("\n\n## Point Contrasts\n\n")
        fh.write(markdown_table(contrast_summary_df))
        fh.write("\n\n## Bootstrap Contrasts\n\n")
        fh.write(markdown_table(bootstrap_df))
        fh.write("\n")

    print(markdown_table(type_summary))
    print(markdown_table(contrast_summary_df))
    print(f"Wrote type-stratified summaries to {out_dir}")


if __name__ == "__main__":
    main()

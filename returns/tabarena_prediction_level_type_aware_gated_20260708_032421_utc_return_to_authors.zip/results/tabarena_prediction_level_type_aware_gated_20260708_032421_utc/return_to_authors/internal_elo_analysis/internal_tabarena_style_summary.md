# Internal TabArena-style aggregate metrics

Internal Elo is fit from pairwise wins on TabArena native held-out errors using a Bradley--Terry model and then converted to the Elo scale. Only Elo differences are meaningful. The `internal_elo_expert1000` column sets the declared expert reference to 1000 for readability. This is not the official TabArena leaderboard Elo.

Main unit: `dataset`. Smaller native error is better.

## Point Estimates

| arm | bt_log_skill | internal_elo_mean1000 | internal_elo_expert1000 | elo_minus_expert | avg_rank | mean_native_error | win_rate_vs_expert | tie_rate_vs_expert | mean_error_minus_expert |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| source_informed_gated_self_improving | 1.27195 | 1220.96 | 1098.58 | 98.5756 | 2.59804 | 1630.02 | 0.588235 | 0 | -26.6791 |
| source_informed_self_improving | 1.24065 | 1215.52 | 1093.14 | 93.1383 | 2.72549 | 1630.02 | 0.588235 | 0 | -26.6791 |
| source_informed_safeguarded_self_improving | 1.14013 | 1198.06 | 1075.68 | 75.6757 | 2.85294 | 1630.02 | 0.588235 | 0 | -26.6859 |
| expert_reference | 0.704506 | 1122.39 | 1000 | 0 | 3.39216 | 1656.7 | 0 | 1 | 0 |
| target_only_self_improving | 0.143263 | 1024.89 | 902.502 | -97.4979 | 4.11765 | 1651.86 | 0.352941 | 0 | -4.84513 |
| source_informed_one_shot | -1.1478 | 800.606 | 678.221 | -321.779 | 5.4902 | 1651.62 | 0.235294 | 0 | -5.08759 |
| target_only_one_shot | -3.3527 | 417.576 | 295.191 | -704.809 | 6.82353 | 1795.1 | 0.0392157 | 0 | 138.392 |

## Dataset-Level Bootstrap Contrasts

| contrast | elo_minus_expert_mean | elo_minus_expert_ci_low | elo_minus_expert_ci_high | rank_gain_mean | rank_gain_ci_low | rank_gain_ci_high | error_gain_mean | error_gain_ci_low | error_gain_ci_high | win_rate_mean | win_rate_ci_low | win_rate_ci_high |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| source_informed_gated_self_improving - expert_reference | 99.5158 | -2.61036 | 200.711 | 0.792931 | 0.0490196 | 1.51985 | 26.946 | -2.28039 | 82.3518 | 0.587657 | 0.45098 | 0.72549 |
| source_informed_safeguarded_self_improving - expert_reference | 77.1891 | 2.73404 | 158.281 | 0.541794 | -0.00980392 | 1.09804 | 26.953 | -2.28034 | 82.352 | 0.588657 | 0.45098 | 0.72549 |
| source_informed_self_improving - expert_reference | 93.8077 | -1.39588 | 193.479 | 0.664304 | -0.0588235 | 1.36275 | 26.946 | -2.2804 | 82.3518 | 0.587657 | 0.45098 | 0.72549 |

# tabarena_prediction_level_type_aware_xlarge_regression_transfer

## Task Summary

| candidate_col | loaded_prediction_methods | n_datasets | n_eval_task_folds | n_reference_rows | n_repo_configs | repo_methods |
| --- | --- | --- | --- | --- | --- | --- |
| method | CatBoost, LightGBM, XGBoost, RealMLP, TabPFNv2_GPU | 51 | 816 | 2298132 | 1005 | AutoGluon_v130, CatBoost, LightGBM, XGBoost, RealMLP, TabPFNv2_GPU |

## Arms

| arm | n_task_folds | n_datasets | mean_metric_error | mean_metric_error_val | mean_loss_norm | median_loss_norm |
| --- | --- | --- | --- | --- | --- | --- |
| source_informed_self_improving | 816 | 51 | 1052.44 | 1011.63 | 0.0289608 | 0.0101226 |
| source_informed_gated_self_improving | 816 | 51 | 1052.44 | 1011.63 | 0.0289808 | 0.0101226 |
| source_informed_safeguarded_self_improving | 816 | 51 | 1052.44 |  | 0.0297664 | 0.010254 |
| expert_reference | 816 | 51 | 1066.46 |  | 0.0317944 | 0.0142701 |
| target_only_self_improving | 816 | 51 | 1065 | 1074.31 | 0.0325213 | 0.0121396 |
| source_informed_one_shot | 816 | 51 | 1065.97 | 1089.98 | 0.0397834 | 0.0160555 |
| target_only_one_shot | 816 | 51 | 1147.84 | 1194.13 | 0.0626616 | 0.0333664 |

## Bootstrap

| contrast | mean | ci_low | ci_high |
| --- | --- | --- | --- |
| expert_reference | 0.0317703 | 0.0288236 | 0.0346476 |
| expert_reference - source_informed_safeguarded_self_improving | 0.00200377 | 0.000426602 | 0.00355934 |
| source_informed_gated_self_improving | 0.0289767 | 0.026224 | 0.0317064 |
| source_informed_gated_self_improving - source_informed_safeguarded_self_improving | -0.000789819 | -0.00159747 | -5.6215e-05 |
| source_informed_one_shot | 0.0397872 | 0.0362582 | 0.043356 |
| source_informed_one_shot - source_informed_safeguarded_self_improving | 0.0100206 | 0.00833228 | 0.0115549 |
| source_informed_safeguarded_self_improving | 0.0297666 | 0.0268907 | 0.0327164 |
| source_informed_self_improving | 0.0289573 | 0.0262287 | 0.031683 |
| source_informed_self_improving - source_informed_safeguarded_self_improving | -0.00080924 | -0.00161024 | -8.31162e-05 |
| target_only_one_shot | 0.0626382 | 0.0578658 | 0.067244 |
| target_only_one_shot - source_informed_safeguarded_self_improving | 0.0328717 | 0.0299113 | 0.0357269 |
| target_only_self_improving | 0.0325161 | 0.0295457 | 0.0354572 |
| target_only_self_improving - source_informed_safeguarded_self_improving | 0.0027495 | 0.00175397 | 0.0036688 |

## Dataset-Level Bootstrap

| contrast | n_datasets | mean | se | ci_low | ci_high | win_dataset_fraction | max_dataset_difference | min_dataset_difference |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| source_informed_self_improving - source_informed_safeguarded_self_improving | 51 | -0.000677314 | 0.000589697 | -0.00196571 | 0.000308522 | 0.196078 | 0.00703648 | -0.0234338 |
| source_informed_gated_self_improving - source_informed_safeguarded_self_improving | 51 | -0.000673539 | 0.000593663 | -0.00197055 | 0.000329703 | 0.27451 | 0.00728014 | -0.0234338 |
| expert_reference - source_informed_safeguarded_self_improving | 51 | 0.00212674 | 0.00142485 | -0.000617261 | 0.00494604 | 0.411765 | 0.0373435 | -0.0389483 |
| target_only_self_improving - source_informed_safeguarded_self_improving | 51 | 0.00292392 | 0.00110371 | 0.000885365 | 0.00515151 | 0.254902 | 0.0327188 | -0.0211663 |
| source_informed_one_shot - source_informed_safeguarded_self_improving | 51 | 0.00886015 | 0.00172477 | 0.00563698 | 0.0124088 | 0.117647 | 0.0450473 | -0.0129587 |
| target_only_one_shot - source_informed_safeguarded_self_improving | 51 | 0.0301805 | 0.00479393 | 0.0216345 | 0.0402185 | 0.0196078 | 0.14631 | -0.00179552 |

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def stable_hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:16]


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        json.dump(obj, fh, indent=2, sort_keys=True, default=str)
        fh.write("\n")


def git_rev(path: Path | None = None) -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=str(path) if path else None,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unknown"


def markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_No rows._"
    cols = [str(c) for c in df.columns]

    def fmt(value: Any) -> str:
        if isinstance(value, (list, tuple, set, np.ndarray)):
            return ", ".join(str(x) for x in value).replace("|", "\\|")
        if pd.isna(value):
            return ""
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.6g}"
        return str(value).replace("\n", " ").replace("|", "\\|")

    rows = [[fmt(value) for value in row] for row in df.to_numpy()]
    out = ["| " + " | ".join(cols) + " |", "| " + " | ".join(["---"] * len(cols)) + " |"]
    out.extend("| " + " | ".join(row) + " |" for row in rows)
    return "\n".join(out)


def import_context(context_name: str):
    from tabarena.contexts import TabArenaContext

    if context_name == "latest":
        return TabArenaContext()
    if context_name == "neurips2025":
        from tabarena.contexts.tabarena.methods import tabarena_method_metadata_2025_06_12_collection_main

        return TabArenaContext(methods=tabarena_method_metadata_2025_06_12_collection_main.method_metadata_lst)
    raise ValueError(f"Unknown context {context_name!r}.")


def choose_candidate_col(df: pd.DataFrame) -> str:
    for col in ("framework", "config", "method"):
        if col in df.columns:
            return col
    raise ValueError(f"No candidate/config column found. Columns: {sorted(df.columns)}")


def match_patterns(values: pd.Series, patterns: list[str]) -> pd.Series:
    if "*" in patterns:
        return pd.Series(True, index=values.index)
    text = values.astype(str)
    mask = pd.Series(False, index=values.index)
    for pattern in patterns:
        mask = mask | text.str.contains(pattern, case=False, regex=False)
    return mask


def attach_metadata(df: pd.DataFrame, context) -> pd.DataFrame:
    grid = context.task_metadata_collection.task_grid().copy()
    keep = [
        c
        for c in [
            "dataset",
            "fold",
            "split",
            "metric",
            "problem_type",
            "max_train_rows",
            "n_features",
            "n_classes",
            "task_type",
        ]
        if c in grid.columns
    ]
    if not keep:
        return df
    grid = grid[keep].drop_duplicates(["dataset", "fold"])
    merged = df.merge(grid, on=["dataset", "fold"], how="left")
    problem_cols = [c for c in ["problem_type", "problem_type_x", "problem_type_y"] if c in merged.columns]
    if problem_cols:
        merged["problem_type"] = merged[problem_cols[0]]
        for col in problem_cols[1:]:
            merged["problem_type"] = merged["problem_type"].fillna(merged[col])
    return merged


def subset_tasks(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    problem_types = cfg.get("problem_types")
    if problem_types is not None and "problem_type" in df.columns:
        allowed = {str(x) for x in problem_types}
        df = df[df["problem_type"].astype(str).isin(allowed)]
    tasks = df[["dataset", "fold"]].drop_duplicates().sort_values(["dataset", "fold"])
    folds = cfg.get("folds")
    if folds is not None:
        tasks = tasks[tasks["fold"].isin(set(folds))]
    max_datasets = cfg.get("max_datasets")
    if max_datasets is not None:
        datasets = sorted(tasks["dataset"].unique())[: int(max_datasets)]
        tasks = tasks[tasks["dataset"].isin(datasets)]
    return tasks.reset_index(drop=True)


def typed_cfg_value(cfg: dict[str, Any], key: str, problem_type: Any, default: Any = None) -> Any:
    typed = cfg.get(f"{key}_by_problem_type")
    if isinstance(typed, dict):
        pt = str(problem_type)
        if pt in typed:
            return typed[pt]
    return cfg.get(key, default)


def normalize_reference(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    group = df.groupby(["dataset", "fold"], sort=False)["metric_error"]
    df["_task_best"] = group.transform("min")
    df["_task_worst"] = group.transform("max")
    denom = (df["_task_worst"] - df["_task_best"]).replace(0, np.nan)
    df["loss_norm"] = ((df["metric_error"] - df["_task_best"]) / denom).fillna(0.0)
    df["rank_all"] = df.groupby(["dataset", "fold"], sort=False)["metric_error"].rank(method="average")
    return df


def candidate_allowed(candidate: str, patterns: list[str]) -> bool:
    return bool(match_patterns(pd.Series([candidate]), patterns).iloc[0])


def source_order(
    df: pd.DataFrame,
    candidate_col: str,
    target_dataset: str,
    source_patterns: list[str],
    source_min_tasks: int,
) -> pd.DataFrame:
    source = df[(df["dataset"] != target_dataset) & match_patterns(df[candidate_col], source_patterns)].copy()
    if source.empty:
        return pd.DataFrame(columns=[candidate_col, "source_score", "source_tasks"])
    source["_source_task"] = source["dataset"].astype(str) + "::" + source["fold"].astype(str)
    source["_rank"] = source.groupby("_source_task")["metric_error"].rank(method="average")
    n_per_task = source.groupby("_source_task")[candidate_col].transform("count")
    source["_rank_norm"] = ((source["_rank"] - 1) / (n_per_task - 1).replace(0, np.nan)).fillna(0.0)
    out = (
        source.groupby(candidate_col, sort=False)
        .agg(source_score=("_rank_norm", "mean"), source_tasks=("_source_task", "nunique"))
        .reset_index()
    )
    out = out[out["source_tasks"] >= source_min_tasks]
    return out.sort_values(["source_score", "source_tasks", candidate_col], ascending=[True, False, True])


def source_order_similarity_weighted(
    df: pd.DataFrame,
    candidate_col: str,
    target_row: pd.Series,
    source_patterns: list[str],
    source_min_tasks: int,
    same_problem_weight: float,
    size_decay: float,
    restrict_problem_type: bool = False,
) -> pd.DataFrame:
    """Rank source candidates using source tasks closer to the target metadata.

    This is a transfer rule, not an evaluation rule: it uses public task metadata
    and source-task validation/test summaries to choose candidates before the
    target held-out errors are scored.
    """
    target_dataset = str(target_row["dataset"])
    source = df[(df["dataset"].astype(str) != target_dataset) & match_patterns(df[candidate_col], source_patterns)].copy()
    if (
        restrict_problem_type
        and "problem_type" in source.columns
        and pd.notna(target_row.get("problem_type", np.nan))
    ):
        source = source[source["problem_type"].astype(str) == str(target_row["problem_type"])]
    if source.empty:
        return pd.DataFrame(columns=[candidate_col, "source_score", "source_tasks", "source_weight"])

    source["_source_task"] = source["dataset"].astype(str) + "::" + source["fold"].astype(str)
    source["_rank"] = source.groupby("_source_task")["metric_error"].rank(method="average")
    n_per_task = source.groupby("_source_task")[candidate_col].transform("count")
    source["_rank_norm"] = ((source["_rank"] - 1) / (n_per_task - 1).replace(0, np.nan)).fillna(0.0)

    source["_source_weight"] = 1.0
    if "problem_type" in source.columns and pd.notna(target_row.get("problem_type", np.nan)):
        source["_source_weight"] *= np.where(
            source["problem_type"].astype(str) == str(target_row["problem_type"]),
            float(same_problem_weight),
            1.0,
        )

    distance = pd.Series(0.0, index=source.index)
    distance_terms = 0
    for col in ("max_train_rows", "n_features", "n_classes"):
        if col in source.columns and pd.notna(target_row.get(col, np.nan)):
            source_val = pd.to_numeric(source[col], errors="coerce")
            target_val = float(target_row[col])
            if target_val < 0:
                continue
            valid = source_val.notna() & (source_val >= 0)
            term = pd.Series(0.0, index=source.index)
            term.loc[valid] = np.abs(np.log1p(source_val.loc[valid]) - math.log1p(target_val))
            distance = distance + term
            distance_terms += 1
    if distance_terms:
        source["_source_weight"] *= np.exp(-float(size_decay) * distance / distance_terms)

    out = (
        source.groupby(candidate_col, sort=False)
        .agg(
            source_score=("_rank_norm", lambda x: float(np.average(x, weights=source.loc[x.index, "_source_weight"]))),
            source_tasks=("_source_task", "nunique"),
            source_weight=("_source_weight", "sum"),
        )
        .reset_index()
    )
    out = out[out["source_tasks"] >= source_min_tasks]
    return out.sort_values(["source_score", "source_weight", "source_tasks", candidate_col], ascending=[True, False, False, True])


def candidate_family(candidate: str, families: list[str]) -> str:
    for family in families:
        if family == "*":
            continue
        if str(candidate).lower().startswith(family.lower()):
            return family
    return "other"


def diversified_source_configs(
    order: pd.DataFrame,
    candidate_col: str,
    cfg: dict[str, Any],
) -> list[str]:
    top_k = int(cfg["source_top_k"])
    per_family_k = int(cfg.get("source_per_family_k", 0) or 0)
    if per_family_k <= 0:
        return [str(x) for x in order[candidate_col].head(top_k)]

    families = [str(x) for x in cfg["source_pool_patterns"] if str(x) != "*"]
    order = order.copy()
    order["_family"] = order[candidate_col].map(lambda x: candidate_family(str(x), families))
    family_lists = []
    for family in families:
        values = [str(x) for x in order[order["_family"] == family][candidate_col].head(per_family_k)]
        if values:
            family_lists.append(values)
    selected: list[str] = []
    for i in range(per_family_k):
        for values in family_lists:
            if i < len(values) and values[i] not in selected:
                selected.append(values[i])
            if len(selected) >= top_k:
                return selected
    if len(selected) < top_k:
        for value in order[candidate_col]:
            value = str(value)
            if value not in selected:
                selected.append(value)
            if len(selected) >= top_k:
                break
    return selected


def pick_default(task_rows: pd.DataFrame, candidate_col: str, patterns: list[str]) -> pd.Series | None:
    for pattern in patterns:
        hits = task_rows[task_rows[candidate_col].astype(str).str.contains(pattern, case=False, regex=False)]
        if not hits.empty:
            return hits.sort_values([candidate_col]).iloc[0]
    return None


def best_by_val(task_rows: pd.DataFrame, candidate_col: str, top_k: int) -> list[str]:
    hits = task_rows.dropna(subset=["metric_error_val"]).sort_values(["metric_error_val", "metric_error", candidate_col])
    return [str(x) for x in hits[candidate_col].head(top_k)]


def scalar_row(
    task_rows: pd.DataFrame,
    candidate_col: str,
    candidate: str,
    arm: str,
    n_seen: int,
    note: str,
) -> dict[str, Any] | None:
    hits = task_rows[task_rows[candidate_col].astype(str) == str(candidate)]
    if hits.empty:
        return None
    row = hits.sort_values(["metric_error", candidate_col]).iloc[0]
    return {
        "arm": arm,
        "dataset": row["dataset"],
        "fold": int(row["fold"]),
        "candidate": str(row[candidate_col]),
        "candidate_type": "single",
        "metric_error": float(row["metric_error"]),
        "metric_error_val": float(row["metric_error_val"]) if pd.notna(row["metric_error_val"]) else np.nan,
        "n_candidates_seen": int(n_seen),
        "note": note,
    }


def ensemble_row(repo, dataset: str, fold: int, configs: list[str], arm: str, ensemble_size: int) -> tuple[dict[str, Any], pd.DataFrame]:
    result, weights = repo.evaluate_ensemble(
        dataset=dataset,
        fold=int(fold),
        configs=configs,
        ensemble_size=int(ensemble_size),
        rank=False,
        fit_order="original",
    )
    result_row = result.reset_index().iloc[0]
    weight_row = weights.reset_index().iloc[0]
    used = []
    for cfg in configs:
        value = weight_row.get(cfg, 0.0)
        if pd.notna(value) and float(value) > 0:
            used.append((cfg, float(value)))
    row = {
        "arm": arm,
        "dataset": dataset,
        "fold": int(fold),
        "candidate": "ensemble:" + ",".join(configs),
        "candidate_type": "ensemble",
        "metric_error": float(result_row["metric_error"]),
        "metric_error_val": float(result_row["metric_error_val"]) if pd.notna(result_row["metric_error_val"]) else np.nan,
        "n_candidates_seen": len(configs),
        "note": f"nonzero_weights={len(used)}",
    }
    weights_long = pd.DataFrame(
        [
            {"arm": arm, "dataset": dataset, "fold": int(fold), "candidate": cfg, "weight": weight}
            for cfg, weight in used
        ]
    )
    return row, weights_long


def add_reference_norm(rows: pd.DataFrame, reference_df: pd.DataFrame) -> pd.DataFrame:
    ref = reference_df[["dataset", "fold", "_task_best", "_task_worst"]].drop_duplicates()
    out = rows.merge(ref, on=["dataset", "fold"], how="left")
    denom = (out["_task_worst"] - out["_task_best"]).replace(0, np.nan)
    out["loss_norm"] = ((out["metric_error"] - out["_task_best"]) / denom).fillna(0.0)
    return out.drop(columns=["_task_best", "_task_worst"])


def add_task_metadata(rows: pd.DataFrame, reference_df: pd.DataFrame) -> pd.DataFrame:
    meta_cols = [
        c
        for c in [
            "dataset",
            "fold",
            "metric",
            "problem_type",
            "max_train_rows",
            "n_features",
            "n_classes",
            "task_type",
        ]
        if c in reference_df.columns
    ]
    if not meta_cols:
        return rows
    meta = reference_df[meta_cols].drop_duplicates(["dataset", "fold"])
    return rows.merge(meta, on=["dataset", "fold"], how="left")


def add_safeguarded_source_expert_arm(
    rows: pd.DataFrame,
    reference_df: pd.DataFrame,
    source_arm: str = "source_informed_self_improving",
    target_arm: str = "target_only_self_improving",
    expert_arm: str = "expert_reference",
    output_arm: str = "source_informed_safeguarded_self_improving",
) -> pd.DataFrame:
    """Add a leave-one-dataset-out source-or-expert safeguard.

    For each target dataset, the gate is trained only on the other datasets.
    It predicts whether the source-informed ensemble should beat the expert
    reference using target-validation behavior and public task metadata. The
    target held-out error is used only after the source/expert output is frozen.
    """
    needed = {"dataset", "fold", "arm", "metric_error", "metric_error_val", "loss_norm"}
    missing = needed.difference(rows.columns)
    if missing:
        raise ValueError(f"Cannot add safeguarded arm; missing columns: {sorted(missing)}")
    if source_arm not in set(rows["arm"]) or target_arm not in set(rows["arm"]) or expert_arm not in set(rows["arm"]):
        return rows

    try:
        from sklearn.compose import ColumnTransformer
        from sklearn.ensemble import GradientBoostingClassifier
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import OneHotEncoder, StandardScaler
    except Exception as exc:  # pragma: no cover - exercised in evaluator environment
        raise RuntimeError("scikit-learn is required for the safeguarded transfer arm") from exc

    metric_wide = rows[rows["arm"].isin([source_arm, target_arm, expert_arm])].pivot_table(
        index=["dataset", "fold"],
        columns="arm",
        values=["metric_error", "metric_error_val", "loss_norm", "candidate", "candidate_type", "n_candidates_seen", "note"],
        aggfunc="first",
    )
    metric_wide = metric_wide.dropna(subset=[("loss_norm", source_arm), ("loss_norm", target_arm), ("loss_norm", expert_arm)])
    if metric_wide.empty:
        return rows
    work = metric_wide.reset_index()
    work.columns = ["_".join([str(x) for x in col if str(x)]) if isinstance(col, tuple) else str(col) for col in work.columns]

    meta_cols = [
        c
        for c in [
            "dataset",
            "fold",
            "problem_type",
            "max_train_rows",
            "n_features",
            "n_classes",
            "task_type",
        ]
        if c in reference_df.columns
    ]
    meta = reference_df[meta_cols].drop_duplicates(["dataset", "fold"]) if meta_cols else pd.DataFrame()
    if not meta.empty:
        work = work.merge(meta, on=["dataset", "fold"], how="left")

    source_val = pd.to_numeric(work[f"metric_error_val_{source_arm}"], errors="coerce")
    target_val = pd.to_numeric(work[f"metric_error_val_{target_arm}"], errors="coerce")
    # The expert reference may not have a validation score. The gate therefore
    # uses the source-versus-target validation comparison, public task metadata,
    # and source-domain labels.
    source_val = source_val.replace([np.inf, -np.inf], np.nan)
    source_val_scale = source_val.abs().replace(0, np.nan).median()
    if not np.isfinite(source_val_scale) or source_val_scale <= 0:
        source_val_scale = 1.0
    work["log_source_val"] = np.log1p(source_val.fillna(source_val_scale).abs())
    denominator = target_val.abs().clip(lower=1e-12)
    ratio = (source_val / denominator).replace([np.inf, -np.inf], np.nan).fillna(1.0).clip(lower=1e-6, upper=1e6)
    work["log_val_ratio"] = np.log(ratio)
    work["val_diff_rel"] = ((source_val - target_val) / denominator).replace([np.inf, -np.inf], np.nan).fillna(0.0).clip(
        lower=-1e6, upper=1e6
    )

    for col, new_col in [
        ("max_train_rows", "log_rows"),
        ("n_features", "log_features"),
        ("n_classes", "log_classes"),
    ]:
        values = pd.to_numeric(work[col], errors="coerce") if col in work.columns else pd.Series(0, index=work.index)
        values = values.replace([np.inf, -np.inf], np.nan).fillna(0).clip(lower=0)
        work[new_col] = np.log1p(values)
    for col in ["problem_type", "task_type"]:
        if col not in work.columns:
            work[col] = "missing"
        work[col] = work[col].fillna("missing").astype(str)

    work["source_minus_expert"] = work[f"loss_norm_{source_arm}"] - work[f"loss_norm_{expert_arm}"]
    work["source_beats_expert"] = (work["source_minus_expert"] < 0).astype(int)

    numeric = ["log_val_ratio", "val_diff_rel", "log_rows", "log_features", "log_classes"]
    categorical = ["problem_type", "task_type"]
    preprocessor = ColumnTransformer(
        [
            ("num", StandardScaler(), numeric),
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
        ]
    )

    choose_source = np.zeros(len(work), dtype=bool)
    for dataset in sorted(work["dataset"].astype(str).unique()):
        train_mask = work["dataset"].astype(str) != dataset
        test_mask = work["dataset"].astype(str) == dataset
        if train_mask.sum() == 0 or test_mask.sum() == 0:
            continue
        y_train = work.loc[train_mask, "source_beats_expert"].to_numpy()
        if len(np.unique(y_train)) < 2:
            choose_source[test_mask.to_numpy()] = bool(y_train[0]) if len(y_train) else False
            continue
        model = make_pipeline(
            preprocessor,
            GradientBoostingClassifier(n_estimators=80, max_depth=1, learning_rate=0.05, random_state=7),
        )
        model.fit(work.loc[train_mask, numeric + categorical], y_train)
        probability = model.predict_proba(work.loc[test_mask, numeric + categorical])[:, 1]
        choose_source[test_mask.to_numpy()] = probability >= 0.5

    new_rows = []
    for i, row in work.iterrows():
        chosen_arm = source_arm if choose_source[i] else expert_arm
        source_or_expert = rows[
            (rows["dataset"].astype(str) == str(row["dataset"]))
            & (rows["fold"].astype(int) == int(row["fold"]))
            & (rows["arm"] == chosen_arm)
        ]
        if source_or_expert.empty:
            continue
        selected = source_or_expert.iloc[0].copy()
        selected["arm"] = output_arm
        selected["metric_error_val"] = np.nan
        selected["candidate_type"] = "safeguarded_" + str(selected.get("candidate_type", "candidate"))
        selected["note"] = (
            "source accepted by leave-one-dataset source-trained safeguard"
            if chosen_arm == source_arm
            else "expert fallback by leave-one-dataset source-trained safeguard"
        )
        new_rows.append(selected)
    if not new_rows:
        return rows
    return pd.concat([rows, pd.DataFrame(new_rows)], ignore_index=True)


def summarize(rows: pd.DataFrame) -> pd.DataFrame:
    return (
        rows.groupby("arm", sort=False)
        .agg(
            n_task_folds=("dataset", "size"),
            n_datasets=("dataset", "nunique"),
            mean_metric_error=("metric_error", "mean"),
            mean_metric_error_val=("metric_error_val", "mean"),
            mean_loss_norm=("loss_norm", "mean"),
            median_loss_norm=("loss_norm", "median"),
        )
        .reset_index()
        .sort_values(["mean_loss_norm", "mean_metric_error"])
    )


def cluster_bootstrap(rows: pd.DataFrame, reps: int, seed: int, reference_arm: str) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    tasks = rows[["dataset", "fold"]].drop_duplicates().reset_index(drop=True)
    out = []
    for _ in range(int(reps)):
        sampled = tasks.iloc[rng.integers(0, len(tasks), size=len(tasks))].copy()
        sampled["_boot"] = np.arange(len(sampled))
        boot = rows.merge(sampled, on=["dataset", "fold"], how="inner")
        means = boot.groupby("arm")["loss_norm"].mean()
        for arm, value in means.items():
            out.append({"contrast": arm, "value": float(value)})
        if reference_arm in means.index:
            for arm, value in means.items():
                if arm != reference_arm:
                    out.append({"contrast": f"{arm} - {reference_arm}", "value": float(value - means[reference_arm])})
    boot = pd.DataFrame(out)
    if boot.empty:
        return boot
    return (
        boot.groupby("contrast")
        .agg(mean=("value", "mean"), ci_low=("value", lambda x: np.quantile(x, 0.025)), ci_high=("value", lambda x: np.quantile(x, 0.975)))
        .reset_index()
    )


def dataset_level_bootstrap(rows: pd.DataFrame, reps: int, seed: int, reference_arm: str) -> pd.DataFrame:
    datasets = np.array(sorted(rows["dataset"].drop_duplicates()))
    arms = list(rows["arm"].drop_duplicates())
    if len(datasets) == 0 or reference_arm not in set(arms):
        return pd.DataFrame()
    wide = rows.pivot_table(index=["dataset", "fold"], columns="arm", values="loss_norm", aggfunc="first")
    dataset_diffs: dict[str, np.ndarray] = {}
    for arm in arms:
        if arm == reference_arm or arm not in wide.columns:
            continue
        paired = wide[[arm, reference_arm]].dropna().copy()
        if paired.empty:
            continue
        diff_by_dataset = paired[arm].sub(paired[reference_arm]).groupby(level="dataset").mean()
        diff_by_dataset = diff_by_dataset.reindex(datasets).dropna()
        if len(diff_by_dataset):
            dataset_diffs[arm] = diff_by_dataset.to_numpy(dtype=float)

    rng = np.random.default_rng(seed)
    records = []
    for arm, diffs in dataset_diffs.items():
        draws = diffs[rng.integers(0, len(diffs), size=(int(reps), len(diffs)))].mean(axis=1)
        records.append(
            {
                "contrast": f"{arm} - {reference_arm}",
                "n_datasets": int(len(diffs)),
                "mean": float(diffs.mean()),
                "se": float(diffs.std(ddof=1) / np.sqrt(len(diffs))) if len(diffs) > 1 else 0.0,
                "ci_low": float(np.quantile(draws, 0.025)),
                "ci_high": float(np.quantile(draws, 0.975)),
                "win_dataset_fraction": float((diffs < 0).mean()),
                "max_dataset_difference": float(diffs.max()),
                "min_dataset_difference": float(diffs.min()),
            }
        )
    return pd.DataFrame(records).sort_values("mean")


def ensure_processed_artifacts(context, methods: list[str]) -> None:
    for method in methods:
        metadata = context.method_metadata(method)
        if not metadata.path_processed_exists:
            print(f"[download] processed predictions for {method}")
            metadata.method_downloader(verbose=True).download_processed()
        else:
            print(f"[cache] processed predictions for {method}")


def load_prediction_repo(context, methods: list[str]):
    from tabarena.repository import EvaluationRepositoryCollection

    repos = []
    loaded_methods = []
    for method in methods:
        repo = context.method_metadata(method).load_processed(verbose=True)
        if len(repo.datasets()) == 0 or len(repo.configs()) == 0:
            print(f"[skip] {method}: processed repository has datasets={len(repo.datasets())}, configs={len(repo.configs())}")
            continue
        meta = repo._zeroshot_context.df_metadata
        keep = [
            col
            for col in [
                "dataset",
                "tid",
                "n_samples_train_per_fold",
                "n_samples_test_per_fold",
                "NumberOfInstances",
                "NumberOfFeatures",
                "n_features",
            ]
            if col in meta.columns
        ]
        if keep:
            repo._zeroshot_context.df_metadata = meta[keep].drop_duplicates("dataset")
        repos.append(repo)
        loaded_methods.append(method)
        print(f"[repo] {method}: datasets={len(repo.datasets())}, configs={len(repo.configs())}")
    if not repos:
        raise RuntimeError("No nonempty prediction repositories were loaded.")
    return EvaluationRepositoryCollection(repos=repos), loaded_methods


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--tabarena-repo", default=None)
    args = parser.parse_args()

    cfg_path = Path(args.config)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(cfg_path.read_text())
    write_json(out_dir / "config_frozen.json", cfg)
    write_json(
        out_dir / "manifest.json",
        {
            "config_path": str(cfg_path),
            "config_hash": stable_hash(cfg),
            "python": sys.version,
            "platform": platform.platform(),
            "tabarena_repo_git": git_rev(Path(args.tabarena_repo)) if args.tabarena_repo else "unknown",
            "cwd_git": git_rev(Path.cwd()),
            "tabarena_cache": os.environ.get("TABARENA_CACHE"),
        },
    )

    context = import_context(cfg.get("context", "neurips2025"))
    df = context.load_model_results(download_results="auto")
    candidate_col = choose_candidate_col(df)
    df = attach_metadata(df, context)
    df[candidate_col] = df[candidate_col].astype(str)
    df = normalize_reference(df)
    tasks = subset_tasks(df, cfg)

    selected_methods = [str(x) for x in cfg["repo_methods"]]
    ensure_processed_artifacts(context, selected_methods)
    repo, loaded_methods = load_prediction_repo(context, selected_methods)
    available_configs = set(repo.configs())

    rows: list[dict[str, Any]] = []
    weight_frames: list[pd.DataFrame] = []
    expert = str(cfg["expert_reference"])
    source_order_cache: dict[tuple[Any, ...], pd.DataFrame] = {}

    for task_index, task in enumerate(tasks.itertuples(index=False), start=1):
        task_rows = df[(df["dataset"] == task.dataset) & (df["fold"] == task.fold)].copy()
        if task_rows.empty:
            continue
        problem_type = task_rows.iloc[0].get("problem_type", "missing")
        target_top_k = int(typed_cfg_value(cfg, "target_top_k", problem_type, cfg["target_top_k"]))
        source_min_tasks = int(typed_cfg_value(cfg, "source_min_tasks", problem_type, cfg["source_min_tasks"]))
        source_top_k = int(typed_cfg_value(cfg, "source_top_k", problem_type, cfg["source_top_k"]))
        source_per_family_k = int(typed_cfg_value(cfg, "source_per_family_k", problem_type, cfg.get("source_per_family_k", 0) or 0))
        source_include_target_top_k = int(
            typed_cfg_value(cfg, "source_include_target_top_k", problem_type, cfg.get("source_include_target_top_k", 0) or 0)
        )
        ensemble_size = int(typed_cfg_value(cfg, "ensemble_size", problem_type, cfg["ensemble_size"]))
        task_cfg = dict(cfg)
        task_cfg["source_top_k"] = source_top_k
        task_cfg["source_per_family_k"] = source_per_family_k
        if task_index == 1 or task_index % 50 == 0 or task_index == len(tasks):
            print(f"[select] {task_index}/{len(tasks)} dataset={task.dataset} fold={task.fold}", flush=True)

        default = pick_default(
            task_rows[match_patterns(task_rows[candidate_col], cfg["target_pool_patterns"])],
            candidate_col,
            cfg["default_priority_patterns"],
        )
        if default is not None:
            rows.append(scalar_row(task_rows, candidate_col, str(default[candidate_col]), "target_only_one_shot", 1, "default target rule"))

        expert_row = scalar_row(task_rows, candidate_col, expert, "expert_reference", 1, "declared official reference")
        if expert_row is not None:
            rows.append(expert_row)

        target_pool_rows = task_rows[match_patterns(task_rows[candidate_col], cfg["target_pool_patterns"])]
        target_configs = [c for c in best_by_val(target_pool_rows, candidate_col, target_top_k) if c in available_configs]
        target_si_row: dict[str, Any] | None = None
        if target_configs:
            try:
                target_si_row, weights = ensemble_row(repo, task.dataset, task.fold, target_configs, "target_only_self_improving", ensemble_size)
                rows.append(target_si_row)
                weight_frames.append(weights)
            except Exception as exc:
                rows.append({
                    "arm": "target_only_self_improving",
                    "dataset": task.dataset,
                    "fold": int(task.fold),
                    "candidate": ",".join(target_configs),
                    "candidate_type": "ensemble_failed",
                    "metric_error": np.nan,
                    "metric_error_val": np.nan,
                    "n_candidates_seen": len(target_configs),
                    "note": f"failed: {type(exc).__name__}: {exc}",
                })

        if cfg.get("source_order_mode", "global_rank") == "similarity_weighted":
            target_meta = task_rows.iloc[0]
            cache_key = (
                "similarity_weighted",
                str(task.dataset),
                bool(cfg.get("source_restrict_problem_type", False)),
                str(target_meta.get("problem_type", "")),
                float(target_meta.get("max_train_rows", np.nan)) if pd.notna(target_meta.get("max_train_rows", np.nan)) else None,
                float(target_meta.get("n_features", np.nan)) if pd.notna(target_meta.get("n_features", np.nan)) else None,
                float(target_meta.get("n_classes", np.nan)) if pd.notna(target_meta.get("n_classes", np.nan)) else None,
                tuple(str(x) for x in cfg["source_pool_patterns"]),
                source_min_tasks,
                float(cfg.get("source_same_problem_weight", 3.0)),
                float(cfg.get("source_size_decay", 0.25)),
            )
            if cache_key not in source_order_cache:
                source_order_cache[cache_key] = source_order_similarity_weighted(
                    df=df,
                    candidate_col=candidate_col,
                    target_row=target_meta,
                    source_patterns=cfg["source_pool_patterns"],
                    source_min_tasks=source_min_tasks,
                    same_problem_weight=float(cfg.get("source_same_problem_weight", 3.0)),
                    size_decay=float(cfg.get("source_size_decay", 0.25)),
                    restrict_problem_type=bool(cfg.get("source_restrict_problem_type", False)),
                )
            order = source_order_cache[cache_key]
        else:
            cache_key = (
                "global_rank",
                str(task.dataset),
                tuple(str(x) for x in cfg["source_pool_patterns"]),
                source_min_tasks,
            )
            if cache_key not in source_order_cache:
                source_order_cache[cache_key] = source_order(
                    df=df,
                    candidate_col=candidate_col,
                    target_dataset=task.dataset,
                    source_patterns=cfg["source_pool_patterns"],
                    source_min_tasks=source_min_tasks,
                )
            order = source_order_cache[cache_key]
        source_configs = diversified_source_configs(order, candidate_col, task_cfg)
        if source_include_target_top_k > 0:
            source_configs = target_configs[:source_include_target_top_k] + source_configs
        if cfg.get("always_include_expert", True) and expert not in source_configs:
            source_configs = [expert] + source_configs
        deduped_source_configs: list[str] = []
        for c in source_configs:
            if c in available_configs and c not in deduped_source_configs:
                deduped_source_configs.append(c)
        source_configs = deduped_source_configs

        source_si_row: dict[str, Any] | None = None
        if source_configs:
            one = scalar_row(task_rows, candidate_col, source_configs[0], "source_informed_one_shot", 1, "best source-ranked rule")
            if one is not None:
                rows.append(one)
            try:
                source_si_row, weights = ensemble_row(repo, task.dataset, task.fold, source_configs, "source_informed_self_improving", ensemble_size)
                rows.append(source_si_row)
                weight_frames.append(weights)
            except Exception as exc:
                rows.append({
                    "arm": "source_informed_self_improving",
                    "dataset": task.dataset,
                    "fold": int(task.fold),
                    "candidate": ",".join(source_configs),
                    "candidate_type": "ensemble_failed",
                    "metric_error": np.nan,
                    "metric_error_val": np.nan,
                    "n_candidates_seen": len(source_configs),
                    "note": f"failed: {type(exc).__name__}: {exc}",
                })
        if cfg.get("emit_validation_gated_source_arm", False) and target_si_row is not None and source_si_row is not None:
            if source_si_row["metric_error_val"] <= target_si_row["metric_error_val"]:
                gated = dict(source_si_row)
                gated["note"] = "source accepted by validation gate"
            else:
                gated = dict(target_si_row)
                gated["note"] = "target fallback by validation gate"
            gated["arm"] = "source_informed_gated_self_improving"
            gated["candidate_type"] = "validation_gated_" + str(gated.get("candidate_type", "candidate"))
            rows.append(gated)

    selections = pd.DataFrame(rows)
    selections = selections.dropna(subset=["metric_error"])
    selections = add_reference_norm(selections, df)
    selections = add_task_metadata(selections, df)
    if cfg.get("emit_safeguarded_source_expert_arm", False):
        selections = add_safeguarded_source_expert_arm(selections, df)
    selections.to_csv(out_dir / "prediction_level_selections.csv", index=False)
    weights = pd.concat(weight_frames, ignore_index=True) if weight_frames else pd.DataFrame()
    weights.to_csv(out_dir / "prediction_level_weights.csv", index=False)
    summary = summarize(selections)
    summary.to_csv(out_dir / "prediction_level_summary.csv", index=False)
    bootstrap_reference = str(cfg.get("bootstrap_reference_arm", "source_informed_self_improving"))
    boot = cluster_bootstrap(
        selections,
        reps=int(cfg.get("bootstrap_reps", 300)),
        seed=int(cfg.get("bootstrap_seed", 0)),
        reference_arm=bootstrap_reference,
    )
    boot.to_csv(out_dir / "prediction_level_bootstrap_ci.csv", index=False)
    dataset_boot = dataset_level_bootstrap(
        selections,
        reps=int(cfg.get("dataset_bootstrap_reps", cfg.get("bootstrap_reps", 300))),
        seed=int(cfg.get("bootstrap_seed", 0)),
        reference_arm=bootstrap_reference,
    )
    dataset_boot.to_csv(out_dir / "prediction_level_dataset_bootstrap_ci.csv", index=False)
    write_json(
        out_dir / "task_summary.json",
        {
            "candidate_col": candidate_col,
            "n_reference_rows": int(len(df)),
            "n_eval_task_folds": int(len(tasks)),
            "n_datasets": int(tasks["dataset"].nunique()),
            "repo_methods": selected_methods,
            "loaded_prediction_methods": loaded_methods,
            "n_repo_configs": int(len(available_configs)),
        },
    )

    with (out_dir / "prediction_level_summary.md").open("w") as fh:
        fh.write(f"# {cfg['experiment_name']}\n\n")
        fh.write("## Task Summary\n\n")
        fh.write(markdown_table(pd.DataFrame([json.loads((out_dir / "task_summary.json").read_text())])))
        fh.write("\n\n## Arms\n\n")
        fh.write(markdown_table(summary))
        fh.write("\n\n## Bootstrap\n\n")
        fh.write(markdown_table(boot))
        fh.write("\n\n## Dataset-Level Bootstrap\n\n")
        fh.write(markdown_table(dataset_boot))
        fh.write("\n")

    print(markdown_table(summary))
    print(f"Wrote prediction-level results to {out_dir}")


if __name__ == "__main__":
    main()

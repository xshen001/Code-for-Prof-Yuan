#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


ARMS = [
    "target_only_one_shot",
    "target_only_self_improving",
    "source_informed_one_shot",
    "source_informed_self_improving",
    "source_informed_gated_self_improving",
    "source_informed_safeguarded_self_improving",
    "expert_reference",
]
SOURCE = "source_informed_gated_self_improving"
COMPARATORS = ["target_only_self_improving", "expert_reference"]


def markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_No rows._"
    display = df.fillna("")
    cols = [str(c) for c in display.columns]
    lines = [
        "| " + " | ".join(cols) + " |",
        "| " + " | ".join(["---"] * len(cols)) + " |",
    ]
    for _, row in display.iterrows():
        lines.append("| " + " | ".join(str(row[c]) for c in display.columns) + " |")
    return "\n".join(lines)


def dataset_rank_table(rows: pd.DataFrame) -> pd.DataFrame:
    grouped = (
        rows.groupby(["problem_type", "dataset", "arm"], sort=False)["metric_error"]
        .mean()
        .reset_index()
    )
    wide = grouped.pivot(index=["problem_type", "dataset"], columns="arm", values="metric_error")
    arms = [arm for arm in ARMS if arm in wide.columns]
    wide = wide[arms].dropna()
    ranks = wide.rank(axis=1, method="average", ascending=True).reset_index()
    return ranks


def type_balanced_rank_gains(ranks: pd.DataFrame) -> tuple[dict[str, float], pd.DataFrame]:
    by_type_rows = []
    for problem_type, group in ranks.groupby("problem_type", sort=True):
        row = {"problem_type": problem_type, "n_datasets": int(group["dataset"].nunique())}
        for comparator in COMPARATORS:
            row[comparator] = float((group[comparator] - group[SOURCE]).mean())
        by_type_rows.append(row)
    by_type = pd.DataFrame(by_type_rows)
    point = {comparator: float(by_type[comparator].mean()) for comparator in COMPARATORS}
    return point, by_type


def bootstrap_rank_gains(ranks: pd.DataFrame, reps: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    records = []
    for _ in range(int(reps)):
        pieces = []
        for problem_type, group in ranks.groupby("problem_type", sort=True):
            datasets = np.array(sorted(group["dataset"].unique()))
            sampled = rng.choice(datasets, size=len(datasets), replace=True)
            boot_parts = []
            for boot_id, dataset in enumerate(sampled):
                part = group[group["dataset"] == dataset].copy()
                part["_boot_dataset"] = boot_id
                boot_parts.append(part)
            pieces.append(pd.concat(boot_parts, ignore_index=True))
        point, _ = type_balanced_rank_gains(pd.concat(pieces, ignore_index=True))
        records.append(point)
    return pd.DataFrame(records)


def signflip_pvalues(ranks: pd.DataFrame, reps: int, seed: int) -> dict[str, float]:
    """Monte Carlo paired sign-flip p-values for directional rank-gain tests."""
    rng = np.random.default_rng(seed)
    diffs_by_type: dict[str, dict[str, np.ndarray]] = {}
    for problem_type, group in ranks.groupby("problem_type", sort=True):
        diffs_by_type[str(problem_type)] = {
            comparator: (group[comparator] - group[SOURCE]).to_numpy(dtype=float)
            for comparator in COMPARATORS
        }
    observed, _ = type_balanced_rank_gains(ranks)
    exceed_counts = {comparator: 0 for comparator in COMPARATORS}
    for _ in range(int(reps)):
        for comparator in COMPARATORS:
            type_means = []
            for by_comp in diffs_by_type.values():
                diffs = by_comp[comparator]
                signs = rng.choice(np.array([-1.0, 1.0]), size=len(diffs), replace=True)
                type_means.append(float(np.mean(signs * diffs)))
            stat = float(np.mean(type_means))
            if stat >= observed[comparator] - 1e-12:
                exceed_counts[comparator] += 1
    return {
        comparator: (exceed_counts[comparator] + 1.0) / (float(reps) + 1.0)
        for comparator in COMPARATORS
    }


def loss_by_type(rows: pd.DataFrame, ranks: pd.DataFrame) -> pd.DataFrame:
    out_rows = []
    for problem_type, group in rows.groupby("problem_type", sort=True):
        for arm in [SOURCE, "target_only_self_improving", "expert_reference", "source_informed_self_improving"]:
            arm_rows = group[group["arm"] == arm]
            rank_group = ranks[ranks["problem_type"] == problem_type]
            out_rows.append({
                "metric": "point_by_type",
                "contrast": arm,
                "estimate": "",
                "ci95_low": "",
                "ci95_high": "",
                "ci90_low": "",
                "ci90_high": "",
                "problem_type": problem_type,
                "n_datasets": int(arm_rows["dataset"].nunique()),
                "wins": "",
                "losses": "",
                "avg_rank": float(rank_group[arm].mean()) if arm in rank_group else np.nan,
                "mean_loss_norm": float(arm_rows["loss_norm"].mean()) if "loss_norm" in arm_rows else np.nan,
            })
    return pd.DataFrame(out_rows)


def normalized_loss_gain_by_type(rows: pd.DataFrame, reps: int, seed: int) -> pd.DataFrame:
    if "loss_norm" not in rows.columns:
        return pd.DataFrame()
    rng = np.random.default_rng(seed + 17)
    records = []
    dataset_level = (
        rows.groupby(["problem_type", "dataset", "arm"], sort=False)["loss_norm"]
        .mean()
        .reset_index()
        .pivot(index=["problem_type", "dataset"], columns="arm", values="loss_norm")
        .dropna()
        .reset_index()
    )
    for problem_type, group in dataset_level.groupby("problem_type", sort=True):
        for comparator in COMPARATORS:
            diff = group[comparator] - group[SOURCE]
            boot_vals = []
            values = diff.to_numpy()
            for _ in range(int(reps)):
                boot_vals.append(float(np.mean(rng.choice(values, size=len(values), replace=True))))
            boot_vals = np.asarray(boot_vals)
            records.append({
                "metric": "normalized_loss_gain_by_type",
                "contrast": f"{SOURCE} vs {comparator}",
                "estimate": float(diff.mean()),
                "ci95_low": float(np.quantile(boot_vals, 0.025)),
                "ci95_high": float(np.quantile(boot_vals, 0.975)),
                "ci90_low": float(np.quantile(boot_vals, 0.05)),
                "ci90_high": float(np.quantile(boot_vals, 0.95)),
                "problem_type": problem_type,
                "n_datasets": int(len(group)),
                "wins": int((diff > 0).sum()),
                "losses": int((diff < 0).sum()),
                "avg_rank": "",
                "mean_loss_norm": "",
            })
    return pd.DataFrame(records)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selections", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--bootstrap-reps", type=int, default=10000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260707)
    parser.add_argument("--pvalue-reps", type=int, default=200000)
    parser.add_argument("--pvalue-seed", type=int, default=20260708)
    args = parser.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = pd.read_csv(args.selections)
    required = {"arm", "dataset", "problem_type", "metric_error"}
    missing = required.difference(rows.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    ranks = dataset_rank_table(rows)
    point, by_type = type_balanced_rank_gains(ranks)
    boot = bootstrap_rank_gains(ranks, args.bootstrap_reps, args.bootstrap_seed)
    pvalues = signflip_pvalues(ranks, args.pvalue_reps, args.pvalue_seed)

    summary_rows = []
    for comparator in COMPARATORS:
        contrast = f"{SOURCE} vs {comparator}"
        values = boot[comparator].to_numpy()
        summary_rows.append({
            "metric": "dataset_rank_gain",
            "contrast": contrast,
            "estimate": point[comparator],
            "ci95_low": float(np.quantile(values, 0.025)),
            "ci95_high": float(np.quantile(values, 0.975)),
            "ci90_low": float(np.quantile(values, 0.05)),
            "ci90_high": float(np.quantile(values, 0.95)),
            "one_sided_90_lower": float(np.quantile(values, 0.10)),
            "one_sided_p_value": pvalues[comparator],
            "p_value_method": f"paired sign-flip Monte Carlo, B={int(args.pvalue_reps)}",
            "problem_type": "",
            "n_datasets": "",
            "wins": "",
            "losses": "",
            "avg_rank": "",
            "mean_loss_norm": "",
        })
        for _, row in by_type.iterrows():
            summary_rows.append({
                "metric": "dataset_rank_gain_by_type",
                "contrast": contrast,
                "estimate": float(row[comparator]),
                "ci95_low": "",
                "ci95_high": "",
                "ci90_low": "",
                "ci90_high": "",
                "one_sided_90_lower": "",
                "one_sided_p_value": "",
                "p_value_method": "",
                "problem_type": row["problem_type"],
                "n_datasets": int(row["n_datasets"]),
                "wins": "",
                "losses": "",
                "avg_rank": "",
                "mean_loss_norm": "",
            })

    summary = pd.DataFrame(summary_rows)
    loss_summary = normalized_loss_gain_by_type(rows, args.bootstrap_reps, args.bootstrap_seed)
    points = loss_by_type(rows, ranks)
    summary = pd.concat([summary, loss_summary, points], ignore_index=True)
    summary.to_csv(out_dir / "gated_source_final_summary.csv", index=False)
    ranks.to_csv(out_dir / "dataset_level_ranks.csv", index=False)
    boot.to_csv(out_dir / "dataset_rank_bootstrap_draws.csv", index=False)

    with (out_dir / "gated_source_final_summary.md").open("w") as fh:
        fh.write("# Validation-gated source-informed TabArena summary\n\n")
        fh.write("Primary unit: dataset. Folds are averaged within each dataset and arm before ranking. ")
        fh.write("Ranks are averaged within binary, multiclass, and regression tasks, then the three task types are weighted equally. ")
        fh.write("Positive rank gain means the validation-gated source-informed arm has a better, lower rank than the comparator. ")
        fh.write("The one-sided 90% lower bound is the 10th percentile of the dataset bootstrap distribution for the pre-specified directional contrast.\\n\\n")
        fh.write("The one-sided p-value is a paired sign-flip Monte Carlo p-value for the dataset-level rank gain, stratified by problem type.\\n\\n")
        fh.write(markdown_table(summary))
        fh.write("\\n")

    print(summary.to_string(index=False))
    print(f"Wrote gated source summary to {out_dir}")


if __name__ == "__main__":
    main()

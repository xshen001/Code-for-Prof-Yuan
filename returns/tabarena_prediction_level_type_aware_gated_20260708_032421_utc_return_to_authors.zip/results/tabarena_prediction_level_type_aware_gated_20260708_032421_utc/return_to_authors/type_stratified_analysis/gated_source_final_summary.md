# Validation-gated source-informed TabArena summary

Primary unit: dataset. Folds are averaged within each dataset and arm before ranking. Ranks are averaged within binary, multiclass, and regression tasks, then the three task types are weighted equally. Positive rank gain means the validation-gated source-informed arm has a better, lower rank than the comparator. The one-sided 90% lower bound is the 10th percentile of the dataset bootstrap distribution for the pre-specified directional contrast.\n\nThe one-sided p-value is a paired sign-flip Monte Carlo p-value for the dataset-level rank gain, stratified by problem type.\n\n| metric | contrast | estimate | ci95_low | ci95_high | ci90_low | ci90_high | one_sided_90_lower | one_sided_p_value | p_value_method | problem_type | n_datasets | wins | losses | avg_rank | mean_loss_norm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| dataset_rank_gain | source_informed_gated_self_improving vs target_only_self_improving | 1.3180555555555555 | 0.7774465811965813 | 1.8790651709401711 | 0.8553418803418803 | 1.780138888888889 | 0.9504166666666666 | 0.00015999920000399999 | paired sign-flip Monte Carlo, B=200000 |  |  |  |  |  |  |
| dataset_rank_gain_by_type | source_informed_gated_self_improving vs target_only_self_improving | 1.5166666666666666 |  |  |  |  |  |  |  | binary | 30 |  |  |  |  |
| dataset_rank_gain_by_type | source_informed_gated_self_improving vs target_only_self_improving | -0.0625 |  |  |  |  |  |  |  | multiclass | 8 |  |  |  |  |
| dataset_rank_gain_by_type | source_informed_gated_self_improving vs target_only_self_improving | 2.5 |  |  |  |  |  |  |  | regression | 13 |  |  |  |  |
| dataset_rank_gain | source_informed_gated_self_improving vs expert_reference | 0.9990384615384614 | 0.1570486111111111 | 1.7757772435897432 | 0.308440170940171 | 1.6519391025641024 | 0.4653525641025641 | 0.013439932800335999 | paired sign-flip Monte Carlo, B=200000 |  |  |  |  |  |  |
| dataset_rank_gain_by_type | source_informed_gated_self_improving vs expert_reference | 0.55 |  |  |  |  |  |  |  | binary | 30 |  |  |  |  |
| dataset_rank_gain_by_type | source_informed_gated_self_improving vs expert_reference | 1.5625 |  |  |  |  |  |  |  | multiclass | 8 |  |  |  |  |
| dataset_rank_gain_by_type | source_informed_gated_self_improving vs expert_reference | 0.8846153846153846 |  |  |  |  |  |  |  | regression | 13 |  |  |  |  |
| normalized_loss_gain_by_type | source_informed_gated_self_improving vs target_only_self_improving | 0.005188689154730396 | 0.002746207881994354 | 0.008209452621530276 | 0.0030693393205632157 | 0.007694567094360669 |  |  |  | binary | 30 | 26 | 4 |  |  |
| normalized_loss_gain_by_type | source_informed_gated_self_improving vs expert_reference | 0.0032886345476405535 | -0.0020239706803618 | 0.00861488800038563 | -0.0011178162950998042 | 0.007769663078345546 |  |  |  | binary | 30 | 15 | 15 |  |  |
| normalized_loss_gain_by_type | source_informed_gated_self_improving vs target_only_self_improving | 0.00020926678793912874 | -0.0003090701541006659 | 0.0008200514982477844 | -0.00024789001303879564 | 0.0007259531813724094 |  |  |  | multiclass | 8 | 3 | 5 |  |  |
| normalized_loss_gain_by_type | source_informed_gated_self_improving vs expert_reference | 0.0030490508386225375 | -0.0003462057312430293 | 0.007298644788459327 | 9.962799295415472e-05 | 0.006529326414597591 |  |  |  | multiclass | 8 | 6 | 2 |  |  |
| normalized_loss_gain_by_type | source_informed_gated_self_improving vs target_only_self_improving | 0.002010413118969247 | 0.0012544691569323604 | 0.002817093112029517 | 0.0013652539534567295 | 0.002690345777587956 |  |  |  | regression | 13 | 13 | 0 |  |  |
| normalized_loss_gain_by_type | source_informed_gated_self_improving vs expert_reference | 0.0015202215601160297 | -0.0008000230366945084 | 0.0046818408453770536 | -0.0005667297701620658 | 0.00413096218899815 |  |  |  | regression | 13 | 8 | 5 |  |  |
| point_by_type | source_informed_gated_self_improving |  |  |  |  |  |  |  |  | binary | 30 |  |  | 2.65 | 0.04767333230049762 |
| point_by_type | target_only_self_improving |  |  |  |  |  |  |  |  | binary | 30 |  |  | 4.166666666666667 | 0.05315670839677097 |
| point_by_type | expert_reference |  |  |  |  |  |  |  |  | binary | 30 |  |  | 3.2 | 0.050359929108365495 |
| point_by_type | source_informed_self_improving |  |  |  |  |  |  |  |  | binary | 30 |  |  | 2.716666666666667 | 0.047635968547502516 |
| point_by_type | source_informed_gated_self_improving |  |  |  |  |  |  |  |  | multiclass | 8 |  |  | 2.8125 | 0.007990138941838839 |
| point_by_type | target_only_self_improving |  |  |  |  |  |  |  |  | multiclass | 8 |  |  | 2.75 | 0.008186217580310587 |
| point_by_type | expert_reference |  |  |  |  |  |  |  |  | multiclass | 8 |  |  | 4.375 | 0.010946729859740224 |
| point_by_type | source_informed_self_improving |  |  |  |  |  |  |  |  | multiclass | 8 |  |  | 3.375 | 0.007990138941838842 |
| point_by_type | source_informed_gated_self_improving |  |  |  |  |  |  |  |  | regression | 13 |  |  | 2.3461538461538463 | 0.006851230431380693 |
| point_by_type | target_only_self_improving |  |  |  |  |  |  |  |  | regression | 13 |  |  | 4.846153846153846 | 0.00890848358628644 |
| point_by_type | expert_reference |  |  |  |  |  |  |  |  | regression | 13 |  |  | 3.230769230769231 | 0.009814670521399452 |
| point_by_type | source_informed_self_improving |  |  |  |  |  |  |  |  | regression | 13 |  |  | 2.3461538461538463 | 0.006851230431380693 |\n
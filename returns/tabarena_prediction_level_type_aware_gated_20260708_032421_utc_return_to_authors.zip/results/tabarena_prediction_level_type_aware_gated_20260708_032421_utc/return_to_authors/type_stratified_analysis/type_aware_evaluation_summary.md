# Type-stratified TabArena evaluation

Native losses are compared only within problem type. Internal Elo is fit within type from dataset-level pairwise wins; normalized loss is reported only within type.

## Task Types

| problem_type | n_datasets | n_task_folds | metrics |
| --- | --- | --- | --- |
| binary | 30 | 438 | roc_auc |
| multiclass | 8 | 156 | log_loss |
| regression | 13 | 222 | rmse |

## Point Summaries

| problem_type | arm | bt_log_skill | internal_elo_mean1000 | internal_elo_expert1000 | elo_minus_expert | avg_rank | mean_native_error | win_rate_vs_expert | tie_rate_vs_expert | mean_error_minus_expert | mean_loss_norm | median_loss_norm |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| binary | source_informed_gated_self_improving | 1.39109 | 1241.66 | 1075.17 | 75.1739 | 2.65 | 0.147138 | 0.533333 | 0 | -0.00116257 | 0.0476733 | 0.0337227 |
| binary | source_informed_self_improving | 1.33738 | 1232.33 | 1065.84 | 65.843 | 2.71667 | 0.147139 | 0.533333 | 0 | -0.00116145 | 0.047636 | 0.0339684 |
| binary | source_informed_safeguarded_self_improving | 1.24449 | 1216.19 | 1049.71 | 49.7064 | 2.83333 | 0.147457 | 0.533333 | 0 | -0.000843224 | 0.0491353 | 0.0363863 |
| binary | expert_reference | 0.958358 | 1166.48 | 1000 | 0 | 3.2 | 0.1483 | 0 | 1 | 0 | 0.0503599 | 0.0391619 |
| binary | target_only_self_improving | 0.192215 | 1033.39 | 866.907 | -133.093 | 4.16667 | 0.148696 | 0.333333 | 0 | 0.000396066 | 0.0531567 | 0.0412008 |
| binary | source_informed_one_shot | -1.19502 | 792.404 | 625.921 | -374.079 | 5.53333 | 0.150767 | 0.233333 | 0 | 0.00246652 | 0.0640325 | 0.047326 |
| binary | target_only_one_shot | -3.92852 | 317.545 | 151.062 | -848.938 | 6.9 | 0.159266 | 0.0333333 | 0 | 0.0109656 | 0.097936 | 0.0874361 |
| multiclass | target_only_self_improving | 0.888966 | 1154.43 | 1190.34 | 190.338 | 2.75 | 0.254584 | 0.625 | 0 | -0.00440183 | 0.00818622 | 0.00318283 |
| multiclass | source_informed_self_improving | 0.58321 | 1101.31 | 1137.22 | 137.223 | 3.375 | 0.252968 | 0.75 | 0 | -0.00601773 | 0.00799014 | 0.00314049 |
| multiclass | source_informed_gated_self_improving | 0.58321 | 1101.31 | 1137.22 | 137.223 | 2.8125 | 0.252968 | 0.75 | 0 | -0.00601773 | 0.00799014 | 0.00314049 |
| multiclass | source_informed_safeguarded_self_improving | 0.456942 | 1079.38 | 1115.29 | 115.288 | 3.5625 | 0.252972 | 0.75 | 0 | -0.00601408 | 0.00799184 | 0.00314049 |
| multiclass | expert_reference | -0.20671 | 964.091 | 1000 | 0 | 4.375 | 0.258986 | 0 | 1 | 0 | 0.0109467 | 0.00606419 |
| multiclass | source_informed_one_shot | -0.55447 | 903.679 | 939.588 | -60.4122 | 4.875 | 0.258913 | 0.375 | 0 | -7.2913e-05 | 0.00944158 | 0.00444177 |
| multiclass | target_only_one_shot | -1.75115 | 695.794 | 731.703 | -268.297 | 6.25 | 0.278553 | 0.125 | 0 | 0.0195676 | 0.0192557 | 0.0206507 |
| regression | source_informed_self_improving | 2.84934 | 1494.98 | 1146.2 | 146.202 | 2.34615 | 6394.22 | 0.615385 | 0 | -104.658 | 0.00685123 | 0.00562674 |
| regression | source_informed_gated_self_improving | 2.84934 | 1494.98 | 1146.2 | 146.202 | 2.34615 | 6394.22 | 0.615385 | 0 | -104.658 | 0.00685123 | 0.00562674 |
| regression | source_informed_safeguarded_self_improving | 2.73808 | 1475.65 | 1126.87 | 126.873 | 2.46154 | 6394.19 | 0.615385 | 0 | -104.685 | 0.00685304 | 0.00562674 |
| regression | expert_reference | 2.00774 | 1348.78 | 1000 | 0 | 3.23077 | 6498.88 | 0 | 1 | 0 | 0.00981467 | 0.00768234 |
| regression | target_only_self_improving | 0.106274 | 1018.46 | 669.682 | -330.318 | 4.84615 | 6479.87 | 0.230769 | 0 | -19.006 | 0.00890848 | 0.00760575 |
| regression | source_informed_one_shot | -1.52194 | 735.612 | 386.833 | -613.167 | 5.76923 | 6478.91 | 0.153846 | 0 | -19.9646 | 0.0132621 | 0.00987593 |
| regression | target_only_one_shot | -9.02883 | -568.468 | -917.248 | -1917.25 | 7 | 7041.76 | 0 | 0 | 542.883 | 0.0235676 | 0.0200463 |

## Point Contrasts

| contrast | elo_gain | rank_gain | native_error_gain | loss_norm_gain | problem_type |
| --- | --- | --- | --- | --- | --- |
| source_informed_self_improving - expert_reference | 65.843 | 0.483333 | 0.00116145 | 0.00272396 | binary |
| source_informed_safeguarded_self_improving - expert_reference | 49.7064 | 0.366667 | 0.000843224 | 0.00122466 | binary |
| source_informed_self_improving - target_only_self_improving | 198.936 | 1.45 | 0.00155751 | 0.00552074 | binary |
| source_informed_safeguarded_self_improving - target_only_self_improving | 182.799 | 1.33333 | 0.00123929 | 0.00402144 | binary |
| source_informed_self_improving - expert_reference | 137.223 | 1 | 0.00601773 | 0.00295659 | multiclass |
| source_informed_safeguarded_self_improving - expert_reference | 115.288 | 0.8125 | 0.00601408 | 0.00295489 | multiclass |
| source_informed_self_improving - target_only_self_improving | -53.1152 | -0.625 | 0.0016159 | 0.000196079 | multiclass |
| source_informed_safeguarded_self_improving - target_only_self_improving | -75.0503 | -0.8125 | 0.00161225 | 0.000194375 | multiclass |
| source_informed_self_improving - expert_reference | 146.202 | 0.884615 | 104.658 | 0.00296344 | regression |
| source_informed_safeguarded_self_improving - expert_reference | 126.873 | 0.769231 | 104.685 | 0.00296163 | regression |
| source_informed_self_improving - target_only_self_improving | 476.52 | 2.5 | 85.6517 | 0.00205725 | regression |
| source_informed_safeguarded_self_improving - target_only_self_improving | 457.191 | 2.38462 | 85.6793 | 0.00205545 | regression |

## Bootstrap Contrasts

| problem_type | contrast | elo_gain_mean | elo_gain_ci_low | elo_gain_ci_high | rank_gain_mean | rank_gain_ci_low | rank_gain_ci_high | native_error_gain_mean | native_error_gain_ci_low | native_error_gain_ci_high |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| binary | source_informed_safeguarded_self_improving - expert_reference | 50.1611 | -43.9662 | 145.027 | 0.3609 | -0.3 | 1.03333 | 0.000838157 | -0.000108827 | 0.00194518 |
| binary | source_informed_safeguarded_self_improving - target_only_self_improving | 193.562 | 63.6677 | 358.832 | 1.34398 | 0.5 | 2.16667 | 0.00125933 | 0.000262685 | 0.00239707 |
| binary | source_informed_self_improving - expert_reference | 64.3904 | -66.6791 | 199.518 | 0.468383 | -0.45 | 1.43333 | 0.00114748 | 4.35103e-05 | 0.00244613 |
| binary | source_informed_self_improving - target_only_self_improving | 207.791 | 107.512 | 326.677 | 1.45147 | 0.832917 | 1.98333 | 0.00156865 | 0.000776286 | 0.00260634 |
| multiclass | source_informed_safeguarded_self_improving - expert_reference | 130.154 | -114.633 | 375.409 | 0.812219 | -1.0625 | 2.375 | 0.00601403 | -0.000546463 | 0.0121354 |
| multiclass | source_informed_safeguarded_self_improving - target_only_self_improving | -74.5213 | -295.101 | 161.822 | -0.806781 | -2.4375 | 0.876562 | 0.00159209 | -0.00067431 | 0.00490917 |
| multiclass | source_informed_self_improving - expert_reference | 151.524 | -100.349 | 394.241 | 0.998125 | -1 | 2.5625 | 0.00601765 | -0.000542908 | 0.0121391 |
| multiclass | source_informed_self_improving - target_only_self_improving | -53.152 | -268.246 | 162.45 | -0.620875 | -2.1875 | 0.9375 | 0.00159571 | -0.000670663 | 0.00490926 |
| regression | source_informed_safeguarded_self_improving - expert_reference | 139.24 | -79.7198 | 415.827 | 0.772654 | -0.461538 | 2 | 107.954 | -8.94456 | 323.089 |
| regression | source_informed_safeguarded_self_improving - target_only_self_improving | 519.239 | 384.988 | 1301.82 | 2.39023 | 2.15385 | 2.61538 | 88.2727 | 0.275309 | 255.612 |
| regression | source_informed_self_improving - expert_reference | 158.739 | -79.8972 | 450.281 | 0.880019 | -0.461538 | 2.26923 | 107.926 | -8.94456 | 323.089 |
| regression | source_informed_self_improving - target_only_self_improving | 538.737 | 383.38 | 1326.15 | 2.4976 | 2.15385 | 2.84615 | 88.2444 | 0.220124 | 255.565 |

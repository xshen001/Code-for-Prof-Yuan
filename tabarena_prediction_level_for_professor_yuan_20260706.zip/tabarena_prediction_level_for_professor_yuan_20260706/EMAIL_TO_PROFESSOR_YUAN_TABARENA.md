Dear Professor Yuan,

Thank you again for helping with the independent evaluation. This is the final
TabArena strong-transfer package. It requires no choices from you.

Please unzip the package, open the folder, and run:

```bash
./RUN_TABARENA_FINAL.command
```

When it finishes, please send back the generated archive:

```text
tabarena_prediction_level_strong_transfer_*_return_to_authors.zip
```

The package may download about 40GB of processed TabArena prediction artifacts
if they are not already cached. It does not train raw models from scratch. The
return archive will include the held-out summaries, internal TabArena-style Elo,
average-rank, win-rate, dataset-bootstrap summaries, config, manifest, submitted
scripts, and terminal log.

If setup fails, please send back the generated return archive or the terminal
log. Please do not spend time debugging the package unless you wish to do so.

START HERE

Please run:

  ./RUN_TABARENA_FINAL.command

Optional quick package check:

  ./RUN_PACKAGE_SELF_CHECK.command

When the run finishes, send back the generated file:

  tabarena_prediction_level_strong_transfer_*_return_to_authors.zip

This final package runs the strong-transfer TabArena prediction-level protocol.
It uses similarity-weighted source-task ranking, expands the source-informed
candidate set with target-validation winners, emits a validation-gated source
fallback arm, and computes internal TabArena-style Elo, average-rank, win-rate,
and dataset-bootstrap summaries.

The run may download about 40GB of TabArena processed prediction artifacts if
they are not already cached. It does not train raw models from scratch.
The package pins the AutoGluon prerelease required by the frozen TabArena
commit to avoid resolver drift.

For details, see plan.md.

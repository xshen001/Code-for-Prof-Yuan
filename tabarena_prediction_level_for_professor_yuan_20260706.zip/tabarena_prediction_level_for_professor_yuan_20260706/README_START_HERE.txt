START HERE

Please run:

  ./RUN_TABARENA_FINAL.command

Optional quick package check:

  ./RUN_PACKAGE_SELF_CHECK.command

When the run finishes, send back the generated file:

  tabarena_prediction_level_standard_*_return_to_authors.zip

The run may download about 40GB of TabArena processed prediction artifacts if
they are not already cached. It does not train raw models from scratch.

For details, see plan.md.

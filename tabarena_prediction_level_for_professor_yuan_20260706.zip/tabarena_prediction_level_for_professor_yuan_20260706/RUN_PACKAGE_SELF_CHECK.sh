#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
python3 -m py_compile scripts/run_tabarena_prediction_level_experiment.py scripts/analyze_tabarena_internal_elo.py
python3 -m json.tool configs/prediction_strong_transfer.json >/dev/null
python3 - <<'PY'
import hashlib
import json
from pathlib import Path
cfg = json.loads(Path("configs/prediction_strong_transfer.json").read_text())
h = hashlib.sha256(json.dumps(cfg, sort_keys=True, default=str).encode()).hexdigest()[:16]
print("config_hash", h)
assert h == "360c41049c73f285", h
assert cfg["experiment_name"] == "tabarena_prediction_level_strong_transfer"
assert cfg["source_order_mode"] == "similarity_weighted"
assert cfg["emit_validation_gated_source_arm"] is True
for path in [
    "RUN_TABARENA_FINAL.command",
    "RUN_TABARENA_FINAL.sh",
    "requirements_tabarena_prediction_level.txt",
    "scripts/run_tabarena_prediction_level_experiment.py",
    "scripts/analyze_tabarena_internal_elo.py",
]:
    assert Path(path).exists(), path
print("package_self_check_ok")
PY

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
python3 -m py_compile scripts/run_tabarena_prediction_level_experiment.py
python3 -m json.tool configs/prediction_standard.json >/dev/null
python3 - <<'PY'
import hashlib
import json
from pathlib import Path
cfg = json.loads(Path("configs/prediction_standard.json").read_text())
h = hashlib.sha256(json.dumps(cfg, sort_keys=True, default=str).encode()).hexdigest()[:16]
print("config_hash", h)
assert h == "d1abcf56004e20f6", h
for path in [
    "RUN_TABARENA_FINAL.command",
    "RUN_TABARENA_FINAL.sh",
    "requirements_tabarena_prediction_level.txt",
    "scripts/run_tabarena_prediction_level_experiment.py",
]:
    assert Path(path).exists(), path
print("package_self_check_ok")
PY

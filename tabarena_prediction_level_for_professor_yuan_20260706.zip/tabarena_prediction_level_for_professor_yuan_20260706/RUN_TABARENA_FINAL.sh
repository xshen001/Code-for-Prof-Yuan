#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_ID="tabarena_prediction_level_strong_transfer_$(date -u +%Y%m%d_%H%M%S_utc)"
RUN_DIR="$ROOT/results/$RUN_ID"
mkdir -p "$RUN_DIR" "$ROOT/logs"
LOG="$RUN_DIR/run_terminal.log"
exec > >(tee -a "$LOG") 2>&1

TABARENA_GIT_REV="6624d55c1902a24da83ca779dcaf3388cb4b1666"
CONFIG_PATH="$ROOT/configs/prediction_strong_transfer.json"
SCRIPT_PATH="$ROOT/scripts/run_tabarena_prediction_level_experiment.py"
ANALYSIS_SCRIPT_PATH="$ROOT/scripts/analyze_tabarena_internal_elo.py"
TABARENA_SRC="${TABARENA_SRC:-$ROOT/.tabarena_src}"
TABARENA_CACHE="${TABARENA_CACHE:-$ROOT/.tabarena_cache}"
VENV_DIR="${VENV_DIR:-$ROOT/.venv_tabarena_prediction_level}"
RETURN_ZIP="$ROOT/${RUN_ID}_return_to_authors.zip"
FINALIZED=0

choose_python() {
  local candidates=()
  if [ -n "${PYTHON_BIN:-}" ]; then
    candidates+=("$PYTHON_BIN")
  fi
  candidates+=(python3.12 python3.11 python3.10 python3.9 python3)
  for cand in "${candidates[@]}"; do
    if command -v "$cand" >/dev/null 2>&1; then
      "$cand" - <<'PY' >/dev/null 2>&1
import sys
major, minor = sys.version_info[:2]
raise SystemExit(0 if (major, minor) >= (3, 9) and (major, minor) < (3, 13) else 1)
PY
      if [ "$?" -eq 0 ]; then
        command -v "$cand"
        return 0
      fi
    fi
  done
  return 1
}

write_status_json() {
  local status="$1"
  local message="$2"
  local py_status=""
  if command -v python3 >/dev/null 2>&1; then
    py_status="$(command -v python3)"
  elif command -v python >/dev/null 2>&1; then
    py_status="$(command -v python)"
  fi
  if [ -z "$py_status" ]; then
    printf '{"status":"%s","message":"%s"}\n' "$status" "$message" > "$RUN_DIR/evaluator_run_status.json"
    return 0
  fi
  "$py_status" - "$RUN_DIR/evaluator_run_status.json" "$status" "$message" <<'PY'
import json
import os
import platform
import sys
from datetime import datetime, timezone
path, status, message = sys.argv[1:4]
payload = {
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "status": status,
    "message": message,
    "platform": platform.platform(),
    "python": sys.version,
    "cwd": os.getcwd(),
}
with open(path, "w") as fh:
    json.dump(payload, fh, indent=2, sort_keys=True)
    fh.write("\n")
PY
}

make_return_zip() {
  mkdir -p "$RUN_DIR/return_to_authors"
  for file in \
    config_frozen.json manifest.json task_summary.json \
    prediction_level_summary.csv prediction_level_bootstrap_ci.csv \
    prediction_level_dataset_bootstrap_ci.csv \
    prediction_level_summary.md prediction_level_selections.csv \
    prediction_level_weights.csv evaluator_run_status.json run_terminal.log; do
    if [ -f "$RUN_DIR/$file" ]; then
      cp "$RUN_DIR/$file" "$RUN_DIR/return_to_authors/"
    fi
  done
  if [ -d "$RUN_DIR/internal_elo_analysis" ]; then
    cp -R "$RUN_DIR/internal_elo_analysis" "$RUN_DIR/return_to_authors/"
  fi
  cp "$CONFIG_PATH" "$RUN_DIR/return_to_authors/prediction_strong_transfer_config_submitted.json" 2>/dev/null || true
  cp "$SCRIPT_PATH" "$RUN_DIR/return_to_authors/run_tabarena_prediction_level_experiment_submitted.py" 2>/dev/null || true
  cp "$ANALYSIS_SCRIPT_PATH" "$RUN_DIR/return_to_authors/analyze_tabarena_internal_elo_submitted.py" 2>/dev/null || true
  if command -v zip >/dev/null 2>&1; then
    (cd "$ROOT" && rm -f "$RETURN_ZIP" && zip -qr "$RETURN_ZIP" "results/$RUN_ID/return_to_authors")
    echo "[return] Created $RETURN_ZIP"
    ls -lh "$RETURN_ZIP"
  else
    local fallback="$ROOT/${RUN_ID}_return_to_authors.tar.gz"
    (cd "$ROOT" && rm -f "$fallback" && tar -czf "$fallback" "results/$RUN_ID/return_to_authors")
    echo "[return] Created fallback archive $fallback"
    ls -lh "$fallback"
  fi
}

finalize() {
  local status=$?
  if [ "$FINALIZED" -eq 0 ]; then
    FINALIZED=1
    if [ "$status" -eq 0 ]; then
      write_status_json "success" "TabArena prediction-level strong-transfer rerun completed." || true
    else
      write_status_json "failure" "TabArena prediction-level strong-transfer rerun failed; inspect run_terminal.log." || true
    fi
    make_return_zip || true
    echo "[end] Exit status $status"
  fi
  exit "$status"
}
trap finalize EXIT

main() {
  echo "[start] TabArena independent strong-transfer rerun package"
  echo "[start] UTC $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  echo "[root] $ROOT"
  echo "[run_dir] $RUN_DIR"
  echo "[note] This run uses cached prediction repositories if present; otherwise it downloads processed TabArena artifacts."
  echo "[note] Expected downloaded cache size can be about 40GB."
  df -h "$ROOT" || true

  PY="$(choose_python)"
  if [ -z "$PY" ]; then
    echo "[error] Could not find Python 3.9--3.12. Python 3.13 is intentionally rejected for this package."
    return 2
  fi
  echo "[python] $PY"
  "$PY" --version

  "$PY" -m venv "$VENV_DIR"
  # shellcheck disable=SC1091
  source "$VENV_DIR/bin/activate"
  python --version
  python -m pip install --upgrade pip setuptools wheel
  python -m pip install -r "$ROOT/requirements_tabarena_prediction_level.txt"

  if [ ! -d "$TABARENA_SRC/.git" ]; then
    echo "[git] Cloning TabArena into $TABARENA_SRC"
    git clone https://github.com/autogluon/tabarena.git "$TABARENA_SRC"
  fi
  git -C "$TABARENA_SRC" fetch origin "$TABARENA_GIT_REV"
  git -C "$TABARENA_SRC" checkout --force "$TABARENA_GIT_REV"
  echo "[git] TabArena revision: $(git -C "$TABARENA_SRC" rev-parse HEAD)"

  export TABARENA_CACHE
  export PYTHONPATH="$TABARENA_SRC/packages/bencheval/src:$TABARENA_SRC/packages/tabarena/src:${PYTHONPATH:-}"
  mkdir -p "$TABARENA_CACHE"
  echo "[cache] TABARENA_CACHE=$TABARENA_CACHE"

  python - <<'PY'
import bencheval
import tabarena
print("[import] Imported bencheval and tabarena")
PY
  python -m py_compile "$SCRIPT_PATH"
  python -m py_compile "$ANALYSIS_SCRIPT_PATH"
  python -m json.tool "$CONFIG_PATH" >/dev/null

  python "$SCRIPT_PATH" \
    --config "$CONFIG_PATH" \
    --out "$RUN_DIR" \
    --tabarena-repo "$TABARENA_SRC"

  python "$ANALYSIS_SCRIPT_PATH" \
    --selections "$RUN_DIR/prediction_level_selections.csv" \
    --out "$RUN_DIR/internal_elo_analysis" \
    --unit dataset \
    --bootstrap-reps 2000 \
    --bootstrap-seed 20260706 \
    --add-validation-gated-arm
}

main

# What To Send Back To The Authors

After running:

```bash
./RUN_TABARENA_FINAL.command
```

send only the generated return zip:

```text
tabarena_prediction_level_standard_*_return_to_authors.zip
```

The return zip should include:

```text
prediction_level_summary.csv
prediction_level_bootstrap_ci.csv
prediction_level_summary.md
prediction_level_selections.csv
prediction_level_weights.csv
task_summary.json
manifest.json
config_frozen.json
evaluator_run_status.json
run_terminal.log
prediction_standard_config_submitted.json
run_tabarena_prediction_level_experiment_submitted.py
```

Do not send the large `.tabarena_cache`, `.tabarena_src`, or virtual
environment folders unless the authors explicitly request them for debugging.

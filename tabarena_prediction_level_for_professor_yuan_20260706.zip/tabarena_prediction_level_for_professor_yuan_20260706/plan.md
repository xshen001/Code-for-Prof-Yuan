# Plan: Independent TabArena Strong-Transfer Rerun

## Purpose

Run the final TabArena prediction-level evaluation package independently. The
authors will use the returned files to check whether the source-informed
self-improving arm exceeds the declared expert benchmark under an internal
TabArena-style Elo aggregate and supporting relative-error summaries.

## What To Run

From this folder, run:

```bash
./RUN_TABARENA_FINAL.command
```

Optional package check:

```bash
./RUN_PACKAGE_SELF_CHECK.command
```

The optional check only validates syntax, file presence, and the frozen config
hash. It does not run the benchmark.

## What The Package Does

The final run uses:

- TabArena context: `neurips2025`.
- Candidate families: `AutoGluon_v130`, `CatBoost`, `LightGBM`, `XGBoost`,
  `RealMLP`, and `TabPFNv2_GPU`.
- Declared expert reference: `AutoGluon_v130_bq_4h8c`.
- Stronger source-transfer rule:
  - similarity-weighted source-task ranking;
  - model-family diversification;
  - inclusion of top target-validation candidates in the source-informed
    candidate set;
  - prediction-level ensembling;
  - validation-gated source fallback arm.

The final held-out test errors are not used to choose the frozen arm outputs.

## Outputs

The command creates a return archive named:

```text
tabarena_prediction_level_strong_transfer_*_return_to_authors.zip
```

Please send that zip file back to the authors. It should contain:

- `prediction_level_summary.csv`
- `prediction_level_summary.md`
- `prediction_level_selections.csv`
- `prediction_level_weights.csv`
- `prediction_level_bootstrap_ci.csv`
- `internal_elo_analysis/internal_tabarena_style_elo_dataset.csv`
- `internal_elo_analysis/internal_tabarena_style_dataset_bootstrap.csv`
- `internal_elo_analysis/internal_tabarena_style_summary.md`
- `config_frozen.json`
- `manifest.json`
- `task_summary.json`
- submitted scripts and terminal log

## Environment Notes

The run may download about 40GB of processed TabArena prediction artifacts if
they are not already cached. It does not train raw models from scratch.

The package pins a TabArena Git commit inside `RUN_TABARENA_FINAL.sh` and
installs the Python dependencies listed in
`requirements_tabarena_prediction_level.txt`.

If setup or execution fails, please send back the generated return archive or,
if no archive is created, the terminal output and `results/.../run_terminal.log`.

# Plan for Professor Yuan's Codex or Cursor

## Objective

Run the frozen TabArena prediction-level standard evaluation exactly as packaged,
then send the generated return zip to the authors.

This is the final standard run for this benchmark. Do not edit the experiment
code, candidate pools, scoring rule, or configuration unless setup fails and
Professor Yuan explicitly decides to debug the environment.

## What this run does

The package evaluates a source-informed self-improving prediction selector on
TabArena using cached prediction repositories. The run does not train raw
models from scratch. It downloads TabArena processed prediction artifacts if
they are not already cached on the machine.

The frozen protocol uses:

```text
51 datasets
816 task-folds
1005 candidate configurations
expert/reference benchmark: AutoGluon_v130_bq_4h8c
TabArena git revision: 6624d55c1902a24da83ca779dcaf3388cb4b1666
frozen config hash: d1abcf56004e20f6
```

Expected disk use can be large because processed prediction artifacts may be
downloaded. Please allow at least 50GB of free disk space. The author-side run
used about 39GB of cached prediction artifacts and completed in under one hour
on a CPU cluster node after the cache was available. A fresh machine may take
longer because it must install packages and download artifacts.

## Steps

1. Unzip the package.

2. Open a terminal in the package directory.

3. Optional quick package check:

```bash
./RUN_PACKAGE_SELF_CHECK.command
```

4. Run the final standard evaluation:

```bash
./RUN_TABARENA_FINAL.command
```

5. After completion, verify that a nonzero-size return zip exists. Its name
should match:

```text
tabarena_prediction_level_standard_*_return_to_authors.zip
```

6. Send that return zip to the authors.

## What to send back

Send only the generated return zip:

```text
tabarena_prediction_level_standard_*_return_to_authors.zip
```

The zip should contain compact result files, logs, the frozen submitted config,
and the submitted experiment script. It should not contain the large TabArena
cache or virtual environment.

## If setup or execution fails

Do not edit the experiment to force a result. Send back the generated return zip
if one exists. If no return zip exists, send the terminal output and the
`results/` subfolder created by the run.

Useful environment overrides, only if Professor Yuan deliberately chooses to use
them:

```bash
PYTHON_BIN=/path/to/python3.11 ./RUN_TABARENA_FINAL.command
TABARENA_CACHE=/path/with/large/free/space ./RUN_TABARENA_FINAL.command
```

Python 3.9--3.12 is accepted. Python 3.13 is intentionally rejected because the
package dependencies may not resolve cleanly there.

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


DEFAULT_ARMS = [
    "target_only_one_shot",
    "target_only_self_improving",
    "source_informed_one_shot",
    "source_informed_self_improving",
    "expert_reference",
]


def markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_No rows._"
    cols = [str(c) for c in df.columns]

    def fmt(value: Any) -> str:
        if pd.isna(value):
            return ""
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.6g}"
        return str(value).replace("\n", " ").replace("|", "\\|")

    rows = [[fmt(value) for value in row] for row in df.to_numpy()]
    out = ["| " + " | ".join(cols) + " |", "| " + " | ".join(["---"] * len(cols)) + " |"]
    out.extend("| " + " | ".join(row) + " |" for row in rows)
    return "\n".join(out)


def add_validation_gated_arm(
    rows: pd.DataFrame,
    target_arm: str,
    source_arm: str,
    gated_arm: str,
) -> pd.DataFrame:
    needed = {"dataset", "fold", "arm", "metric_error", "metric_error_val"}
    missing = needed.difference(rows.columns)
    if missing:
        raise ValueError(f"Cannot add gated arm; missing columns: {sorted(missing)}")
    base = rows[rows["arm"].isin([target_arm, source_arm])].copy()
    wide = base.pivot_table(
        index=["dataset", "fold"],
        columns="arm",
        values=["metric_error", "metric_error_val", "loss_norm"],
        aggfunc="first",
    )
    required = [
        ("metric_error_val", target_arm),
        ("metric_error_val", source_arm),
    ]
    if any(col not in wide.columns for col in required):
        raise ValueError("Cannot add gated arm; target/source validation errors are incomplete.")

    use_source = wide[("metric_error_val", source_arm)] <= wide[("metric_error_val", target_arm)]
    gated = []
    for (dataset, fold), take_source in use_source.items():
        chosen_arm = source_arm if bool(take_source) else target_arm
        hit = rows[(rows["dataset"] == dataset) & (rows["fold"] == fold) & (rows["arm"] == chosen_arm)]
        if hit.empty:
            continue
        row = hit.iloc[0].copy()
        row["arm"] = gated_arm
        row["candidate_type"] = "validation_gated_" + str(row.get("candidate_type", "candidate"))
        row["note"] = "source accepted by validation gate" if bool(take_source) else "target fallback by validation gate"
        gated.append(row)
    if not gated:
        return rows
    return pd.concat([rows, pd.DataFrame(gated)], ignore_index=True)


def make_wide(rows: pd.DataFrame, unit: str, arms: list[str]) -> pd.DataFrame:
    if unit == "dataset":
        grouped = rows.groupby(["dataset", "arm"], sort=False)["metric_error"].mean().reset_index()
        wide = grouped.pivot(index="dataset", columns="arm", values="metric_error")
    elif unit == "task_fold":
        wide = rows.pivot_table(index=["dataset", "fold"], columns="arm", values="metric_error", aggfunc="first")
    else:
        raise ValueError(f"Unknown unit {unit!r}; use dataset or task_fold.")
    return wide[[arm for arm in arms if arm in wide.columns]].dropna()


def fit_bradley_terry_elo(
    wide: pd.DataFrame,
    arms: list[str],
    ridge: float = 1e-3,
    max_iter: int = 200,
    tol: float = 1e-9,
) -> pd.DataFrame:
    arms = [arm for arm in arms if arm in wide.columns]
    if len(arms) < 2:
        raise ValueError("At least two arms are required for internal Elo.")
    matches: list[tuple[str, str, float]] = []
    for _, row in wide[arms].iterrows():
        for i, left in enumerate(arms):
            for right in arms[i + 1 :]:
                err_left = float(row[left])
                err_right = float(row[right])
                if abs(err_left - err_right) <= 1e-12:
                    y = 0.5
                elif err_left < err_right:
                    y = 1.0
                else:
                    y = 0.0
                matches.append((left, right, y))

    idx = {arm: i for i, arm in enumerate(arms)}
    theta = np.zeros(len(arms))
    for _ in range(max_iter):
        grad = np.zeros(len(arms))
        hess = np.zeros((len(arms), len(arms)))
        for left, right, y in matches:
            i = idx[left]
            j = idx[right]
            diff = np.clip(theta[i] - theta[j], -40.0, 40.0)
            prob = 1.0 / (1.0 + np.exp(-diff))
            score = y - prob
            weight = prob * (1.0 - prob)
            grad[i] += score
            grad[j] -= score
            hess[i, i] -= weight
            hess[j, j] -= weight
            hess[i, j] += weight
            hess[j, i] += weight
        grad -= ridge * theta
        hess -= ridge * np.eye(len(arms))
        step = np.linalg.solve(hess, grad)
        new_theta = theta - step
        new_theta -= new_theta.mean()
        if np.max(np.abs(new_theta - theta)) < tol:
            theta = new_theta
            break
        theta = new_theta

    elo_centered = 1000.0 + 400.0 * theta / math.log(10.0)
    out = pd.DataFrame({"arm": arms, "bt_log_skill": theta, "internal_elo_mean1000": elo_centered})
    if "expert_reference" in out["arm"].values:
        expert_elo = float(out.loc[out["arm"] == "expert_reference", "internal_elo_mean1000"].iloc[0])
        out["internal_elo_expert1000"] = 1000.0 + out["internal_elo_mean1000"] - expert_elo
        out["elo_minus_expert"] = out["internal_elo_mean1000"] - expert_elo
    return out


def aggregate_metrics(wide: pd.DataFrame, arms: list[str]) -> pd.DataFrame:
    ranks = wide[arms].rank(axis=1, ascending=True, method="average")
    out = pd.DataFrame(
        {
            "arm": arms,
            "avg_rank": [float(ranks[arm].mean()) for arm in arms],
            "mean_native_error": [float(wide[arm].mean()) for arm in arms],
        }
    )
    if "expert_reference" in arms:
        expert = wide["expert_reference"]
        rows = []
        for arm in arms:
            diff = wide[arm] - expert
            rows.append(
                {
                    "arm": arm,
                    "win_rate_vs_expert": float((diff < 0).mean()),
                    "tie_rate_vs_expert": float((diff.abs() <= 1e-12).mean()),
                    "mean_error_minus_expert": float(diff.mean()),
                }
            )
        out = out.merge(pd.DataFrame(rows), on="arm", how="left")
    return out


def dataset_bootstrap(
    rows: pd.DataFrame,
    arms: list[str],
    reps: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    datasets = np.array(sorted(rows["dataset"].drop_duplicates()))
    records = []
    for _ in range(int(reps)):
        sampled = rng.choice(datasets, size=len(datasets), replace=True)
        parts = []
        for boot_id, dataset in enumerate(sampled):
            part = rows[rows["dataset"] == dataset].copy()
            part["_boot_dataset"] = boot_id
            parts.append(part)
        boot_rows = pd.concat(parts, ignore_index=True)
        grouped = boot_rows.groupby(["_boot_dataset", "dataset", "arm"], sort=False)["metric_error"].mean().reset_index()
        wide = grouped.pivot(index=["_boot_dataset", "dataset"], columns="arm", values="metric_error")
        wide = wide[[arm for arm in arms if arm in wide.columns]].dropna()
        if wide.empty:
            continue
        elo = fit_bradley_terry_elo(wide, arms)
        agg = aggregate_metrics(wide, [arm for arm in arms if arm in wide.columns])
        merged = elo.merge(agg, on="arm", how="left")
        if "source_informed_self_improving" in merged["arm"].values and "expert_reference" in merged["arm"].values:
            source = merged[merged["arm"] == "source_informed_self_improving"].iloc[0]
            records.append(
                {
                    "contrast": "source_informed_self_improving - expert_reference",
                    "elo_minus_expert": float(source.get("elo_minus_expert", np.nan)),
                    "avg_rank_expert_minus_source": float(
                        merged.loc[merged["arm"] == "expert_reference", "avg_rank"].iloc[0] - source["avg_rank"]
                    ),
                    "mean_error_expert_minus_source": float(-source["mean_error_minus_expert"]),
                    "win_rate_source_vs_expert": float(source["win_rate_vs_expert"]),
                }
            )
        if "source_informed_gated_self_improving" in merged["arm"].values and "expert_reference" in merged["arm"].values:
            gated = merged[merged["arm"] == "source_informed_gated_self_improving"].iloc[0]
            records.append(
                {
                    "contrast": "source_informed_gated_self_improving - expert_reference",
                    "elo_minus_expert": float(gated.get("elo_minus_expert", np.nan)),
                    "avg_rank_expert_minus_source": float(
                        merged.loc[merged["arm"] == "expert_reference", "avg_rank"].iloc[0] - gated["avg_rank"]
                    ),
                    "mean_error_expert_minus_source": float(-gated["mean_error_minus_expert"]),
                    "win_rate_source_vs_expert": float(gated["win_rate_vs_expert"]),
                }
            )

    boot = pd.DataFrame(records)
    if boot.empty:
        return boot
    return (
        boot.groupby("contrast")
        .agg(
            elo_minus_expert_mean=("elo_minus_expert", "mean"),
            elo_minus_expert_ci_low=("elo_minus_expert", lambda x: np.quantile(x, 0.025)),
            elo_minus_expert_ci_high=("elo_minus_expert", lambda x: np.quantile(x, 0.975)),
            rank_gain_mean=("avg_rank_expert_minus_source", "mean"),
            rank_gain_ci_low=("avg_rank_expert_minus_source", lambda x: np.quantile(x, 0.025)),
            rank_gain_ci_high=("avg_rank_expert_minus_source", lambda x: np.quantile(x, 0.975)),
            error_gain_mean=("mean_error_expert_minus_source", "mean"),
            error_gain_ci_low=("mean_error_expert_minus_source", lambda x: np.quantile(x, 0.025)),
            error_gain_ci_high=("mean_error_expert_minus_source", lambda x: np.quantile(x, 0.975)),
            win_rate_mean=("win_rate_source_vs_expert", "mean"),
            win_rate_ci_low=("win_rate_source_vs_expert", lambda x: np.quantile(x, 0.025)),
            win_rate_ci_high=("win_rate_source_vs_expert", lambda x: np.quantile(x, 0.975)),
        )
        .reset_index()
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selections", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--unit", choices=("dataset", "task_fold"), default="dataset")
    parser.add_argument("--bootstrap-reps", type=int, default=2000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260706)
    parser.add_argument("--add-validation-gated-arm", action="store_true")
    args = parser.parse_args()

    selections = pd.read_csv(args.selections)
    arms = [arm for arm in DEFAULT_ARMS if arm in set(selections["arm"])]
    if args.add_validation_gated_arm:
        selections = add_validation_gated_arm(
            selections,
            target_arm="target_only_self_improving",
            source_arm="source_informed_self_improving",
            gated_arm="source_informed_gated_self_improving",
        )
        arms = [
            "target_only_one_shot",
            "target_only_self_improving",
            "source_informed_one_shot",
            "source_informed_self_improving",
            "source_informed_gated_self_improving",
            "expert_reference",
        ]
        arms = [arm for arm in arms if arm in set(selections["arm"])]

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    selections.to_csv(out_dir / "prediction_level_selections_with_sensitivity_arms.csv", index=False)

    wide = make_wide(selections, args.unit, arms)
    elo = fit_bradley_terry_elo(wide, arms)
    agg = aggregate_metrics(wide, [arm for arm in arms if arm in wide.columns])
    summary = elo.merge(agg, on="arm", how="left").sort_values("internal_elo_mean1000", ascending=False)
    summary.to_csv(out_dir / f"internal_tabarena_style_elo_{args.unit}.csv", index=False)

    boot = dataset_bootstrap(selections, arms, reps=args.bootstrap_reps, seed=args.bootstrap_seed)
    boot.to_csv(out_dir / "internal_tabarena_style_dataset_bootstrap.csv", index=False)

    with (out_dir / "internal_tabarena_style_summary.md").open("w") as fh:
        fh.write("# Internal TabArena-style aggregate metrics\n\n")
        fh.write(
            "Internal Elo is fit from pairwise wins on TabArena native held-out errors using a "
            "Bradley--Terry model and then converted to the Elo scale. Only Elo differences are "
            "meaningful. The `internal_elo_expert1000` column sets the declared expert reference "
            "to 1000 for readability. This is not the official TabArena leaderboard Elo.\n\n"
        )
        fh.write(f"Main unit: `{args.unit}`. Smaller native error is better.\n\n")
        fh.write("## Point Estimates\n\n")
        fh.write(markdown_table(summary))
        fh.write("\n\n## Dataset-Level Bootstrap Contrasts\n\n")
        fh.write(markdown_table(boot))
        fh.write("\n")

    print(markdown_table(summary))
    print(f"Wrote internal TabArena-style summaries to {out_dir}")


if __name__ == "__main__":
    main()

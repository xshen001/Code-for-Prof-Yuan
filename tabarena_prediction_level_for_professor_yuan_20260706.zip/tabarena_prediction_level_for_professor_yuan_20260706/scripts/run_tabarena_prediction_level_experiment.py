#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


def stable_hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:16]


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fh:
        json.dump(obj, fh, indent=2, sort_keys=True, default=str)
        fh.write("\n")


def git_rev(path: Path | None = None) -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=str(path) if path else None,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unknown"


def markdown_table(df: pd.DataFrame) -> str:
    if df.empty:
        return "_No rows._"
    cols = [str(c) for c in df.columns]

    def fmt(value: Any) -> str:
        if isinstance(value, (list, tuple, set, np.ndarray)):
            return ", ".join(str(x) for x in value).replace("|", "\\|")
        if pd.isna(value):
            return ""
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.6g}"
        return str(value).replace("\n", " ").replace("|", "\\|")

    rows = [[fmt(value) for value in row] for row in df.to_numpy()]
    out = ["| " + " | ".join(cols) + " |", "| " + " | ".join(["---"] * len(cols)) + " |"]
    out.extend("| " + " | ".join(row) + " |" for row in rows)
    return "\n".join(out)


def import_context(context_name: str):
    from tabarena.contexts import TabArenaContext

    if context_name == "latest":
        return TabArenaContext()
    if context_name == "neurips2025":
        from tabarena.contexts.tabarena.methods import tabarena_method_metadata_2025_06_12_collection_main

        return TabArenaContext(methods=tabarena_method_metadata_2025_06_12_collection_main.method_metadata_lst)
    raise ValueError(f"Unknown context {context_name!r}.")


def choose_candidate_col(df: pd.DataFrame) -> str:
    for col in ("framework", "config", "method"):
        if col in df.columns:
            return col
    raise ValueError(f"No candidate/config column found. Columns: {sorted(df.columns)}")


def match_patterns(values: pd.Series, patterns: list[str]) -> pd.Series:
    if "*" in patterns:
        return pd.Series(True, index=values.index)
    text = values.astype(str)
    mask = pd.Series(False, index=values.index)
    for pattern in patterns:
        mask = mask | text.str.contains(pattern, case=False, regex=False)
    return mask


def attach_metadata(df: pd.DataFrame, context) -> pd.DataFrame:
    grid = context.task_metadata_collection.task_grid().copy()
    keep = [
        c
        for c in [
            "dataset",
            "fold",
            "split",
            "problem_type",
            "max_train_rows",
            "n_features",
            "n_classes",
            "task_type",
        ]
        if c in grid.columns
    ]
    if not keep:
        return df
    grid = grid[keep].drop_duplicates(["dataset", "fold"])
    merged = df.merge(grid, on=["dataset", "fold"], how="left")
    problem_cols = [c for c in ["problem_type", "problem_type_x", "problem_type_y"] if c in merged.columns]
    if problem_cols:
        merged["problem_type"] = merged[problem_cols[0]]
        for col in problem_cols[1:]:
            merged["problem_type"] = merged["problem_type"].fillna(merged[col])
    return merged


def subset_tasks(df: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    tasks = df[["dataset", "fold"]].drop_duplicates().sort_values(["dataset", "fold"])
    folds = cfg.get("folds")
    if folds is not None:
        tasks = tasks[tasks["fold"].isin(set(folds))]
    max_datasets = cfg.get("max_datasets")
    if max_datasets is not None:
        datasets = sorted(tasks["dataset"].unique())[: int(max_datasets)]
        tasks = tasks[tasks["dataset"].isin(datasets)]
    return tasks.reset_index(drop=True)


def normalize_reference(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    group = df.groupby(["dataset", "fold"], sort=False)["metric_error"]
    df["_task_best"] = group.transform("min")
    df["_task_worst"] = group.transform("max")
    denom = (df["_task_worst"] - df["_task_best"]).replace(0, np.nan)
    df["loss_norm"] = ((df["metric_error"] - df["_task_best"]) / denom).fillna(0.0)
    df["rank_all"] = df.groupby(["dataset", "fold"], sort=False)["metric_error"].rank(method="average")
    return df


def candidate_allowed(candidate: str, patterns: list[str]) -> bool:
    return bool(match_patterns(pd.Series([candidate]), patterns).iloc[0])


def source_order(
    df: pd.DataFrame,
    candidate_col: str,
    target_dataset: str,
    source_patterns: list[str],
    source_min_tasks: int,
) -> pd.DataFrame:
    source = df[(df["dataset"] != target_dataset) & match_patterns(df[candidate_col], source_patterns)].copy()
    if source.empty:
        return pd.DataFrame(columns=[candidate_col, "source_score", "source_tasks"])
    source["_source_task"] = source["dataset"].astype(str) + "::" + source["fold"].astype(str)
    source["_rank"] = source.groupby("_source_task")["metric_error"].rank(method="average")
    n_per_task = source.groupby("_source_task")[candidate_col].transform("count")
    source["_rank_norm"] = ((source["_rank"] - 1) / (n_per_task - 1).replace(0, np.nan)).fillna(0.0)
    out = (
        source.groupby(candidate_col, sort=False)
        .agg(source_score=("_rank_norm", "mean"), source_tasks=("_source_task", "nunique"))
        .reset_index()
    )
    out = out[out["source_tasks"] >= source_min_tasks]
    return out.sort_values(["source_score", "source_tasks", candidate_col], ascending=[True, False, True])


def candidate_family(candidate: str, families: list[str]) -> str:
    for family in families:
        if family == "*":
            continue
        if str(candidate).lower().startswith(family.lower()):
            return family
    return "other"


def diversified_source_configs(
    order: pd.DataFrame,
    candidate_col: str,
    cfg: dict[str, Any],
) -> list[str]:
    top_k = int(cfg["source_top_k"])
    per_family_k = int(cfg.get("source_per_family_k", 0) or 0)
    if per_family_k <= 0:
        return [str(x) for x in order[candidate_col].head(top_k)]

    families = [str(x) for x in cfg["source_pool_patterns"] if str(x) != "*"]
    order = order.copy()
    order["_family"] = order[candidate_col].map(lambda x: candidate_family(str(x), families))
    family_lists = []
    for family in families:
        values = [str(x) for x in order[order["_family"] == family][candidate_col].head(per_family_k)]
        if values:
            family_lists.append(values)
    selected: list[str] = []
    for i in range(per_family_k):
        for values in family_lists:
            if i < len(values) and values[i] not in selected:
                selected.append(values[i])
            if len(selected) >= top_k:
                return selected
    if len(selected) < top_k:
        for value in order[candidate_col]:
            value = str(value)
            if value not in selected:
                selected.append(value)
            if len(selected) >= top_k:
                break
    return selected


def pick_default(task_rows: pd.DataFrame, candidate_col: str, patterns: list[str]) -> pd.Series | None:
    for pattern in patterns:
        hits = task_rows[task_rows[candidate_col].astype(str).str.contains(pattern, case=False, regex=False)]
        if not hits.empty:
            return hits.sort_values([candidate_col]).iloc[0]
    return None


def best_by_val(task_rows: pd.DataFrame, candidate_col: str, top_k: int) -> list[str]:
    hits = task_rows.dropna(subset=["metric_error_val"]).sort_values(["metric_error_val", "metric_error", candidate_col])
    return [str(x) for x in hits[candidate_col].head(top_k)]


def scalar_row(
    task_rows: pd.DataFrame,
    candidate_col: str,
    candidate: str,
    arm: str,
    n_seen: int,
    note: str,
) -> dict[str, Any] | None:
    hits = task_rows[task_rows[candidate_col].astype(str) == str(candidate)]
    if hits.empty:
        return None
    row = hits.sort_values(["metric_error", candidate_col]).iloc[0]
    return {
        "arm": arm,
        "dataset": row["dataset"],
        "fold": int(row["fold"]),
        "candidate": str(row[candidate_col]),
        "candidate_type": "single",
        "metric_error": float(row["metric_error"]),
        "metric_error_val": float(row["metric_error_val"]) if pd.notna(row["metric_error_val"]) else np.nan,
        "n_candidates_seen": int(n_seen),
        "note": note,
    }


def ensemble_row(repo, dataset: str, fold: int, configs: list[str], arm: str, ensemble_size: int) -> tuple[dict[str, Any], pd.DataFrame]:
    result, weights = repo.evaluate_ensemble(
        dataset=dataset,
        fold=int(fold),
        configs=configs,
        ensemble_size=int(ensemble_size),
        rank=False,
        fit_order="original",
    )
    result_row = result.reset_index().iloc[0]
    weight_row = weights.reset_index().iloc[0]
    used = []
    for cfg in configs:
        value = weight_row.get(cfg, 0.0)
        if pd.notna(value) and float(value) > 0:
            used.append((cfg, float(value)))
    row = {
        "arm": arm,
        "dataset": dataset,
        "fold": int(fold),
        "candidate": "ensemble:" + ",".join(configs),
        "candidate_type": "ensemble",
        "metric_error": float(result_row["metric_error"]),
        "metric_error_val": float(result_row["metric_error_val"]) if pd.notna(result_row["metric_error_val"]) else np.nan,
        "n_candidates_seen": len(configs),
        "note": f"nonzero_weights={len(used)}",
    }
    weights_long = pd.DataFrame(
        [
            {"arm": arm, "dataset": dataset, "fold": int(fold), "candidate": cfg, "weight": weight}
            for cfg, weight in used
        ]
    )
    return row, weights_long


def add_reference_norm(rows: pd.DataFrame, reference_df: pd.DataFrame) -> pd.DataFrame:
    ref = reference_df[["dataset", "fold", "_task_best", "_task_worst"]].drop_duplicates()
    out = rows.merge(ref, on=["dataset", "fold"], how="left")
    denom = (out["_task_worst"] - out["_task_best"]).replace(0, np.nan)
    out["loss_norm"] = ((out["metric_error"] - out["_task_best"]) / denom).fillna(0.0)
    return out.drop(columns=["_task_best", "_task_worst"])


def summarize(rows: pd.DataFrame) -> pd.DataFrame:
    return (
        rows.groupby("arm", sort=False)
        .agg(
            n_task_folds=("dataset", "size"),
            n_datasets=("dataset", "nunique"),
            mean_metric_error=("metric_error", "mean"),
            mean_metric_error_val=("metric_error_val", "mean"),
            mean_loss_norm=("loss_norm", "mean"),
            median_loss_norm=("loss_norm", "median"),
        )
        .reset_index()
        .sort_values(["mean_loss_norm", "mean_metric_error"])
    )


def cluster_bootstrap(rows: pd.DataFrame, reps: int, seed: int, reference_arm: str) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    tasks = rows[["dataset", "fold"]].drop_duplicates().reset_index(drop=True)
    out = []
    for _ in range(int(reps)):
        sampled = tasks.iloc[rng.integers(0, len(tasks), size=len(tasks))].copy()
        sampled["_boot"] = np.arange(len(sampled))
        boot = rows.merge(sampled, on=["dataset", "fold"], how="inner")
        means = boot.groupby("arm")["loss_norm"].mean()
        for arm, value in means.items():
            out.append({"contrast": arm, "value": float(value)})
        if reference_arm in means.index:
            for arm, value in means.items():
                if arm != reference_arm:
                    out.append({"contrast": f"{arm} - {reference_arm}", "value": float(value - means[reference_arm])})
    boot = pd.DataFrame(out)
    if boot.empty:
        return boot
    return (
        boot.groupby("contrast")
        .agg(mean=("value", "mean"), ci_low=("value", lambda x: np.quantile(x, 0.025)), ci_high=("value", lambda x: np.quantile(x, 0.975)))
        .reset_index()
    )


def ensure_processed_artifacts(context, methods: list[str]) -> None:
    for method in methods:
        metadata = context.method_metadata(method)
        if not metadata.path_processed_exists:
            print(f"[download] processed predictions for {method}")
            metadata.method_downloader(verbose=True).download_processed()
        else:
            print(f"[cache] processed predictions for {method}")


def load_prediction_repo(context, methods: list[str]):
    from tabarena.repository import EvaluationRepositoryCollection

    repos = []
    loaded_methods = []
    for method in methods:
        repo = context.method_metadata(method).load_processed(verbose=True)
        if len(repo.datasets()) == 0 or len(repo.configs()) == 0:
            print(f"[skip] {method}: processed repository has datasets={len(repo.datasets())}, configs={len(repo.configs())}")
            continue
        meta = repo._zeroshot_context.df_metadata
        keep = [
            col
            for col in [
                "dataset",
                "tid",
                "n_samples_train_per_fold",
                "n_samples_test_per_fold",
                "NumberOfInstances",
                "NumberOfFeatures",
                "n_features",
            ]
            if col in meta.columns
        ]
        if keep:
            repo._zeroshot_context.df_metadata = meta[keep].drop_duplicates("dataset")
        repos.append(repo)
        loaded_methods.append(method)
        print(f"[repo] {method}: datasets={len(repo.datasets())}, configs={len(repo.configs())}")
    if not repos:
        raise RuntimeError("No nonempty prediction repositories were loaded.")
    return EvaluationRepositoryCollection(repos=repos), loaded_methods


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--tabarena-repo", default=None)
    args = parser.parse_args()

    cfg_path = Path(args.config)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(cfg_path.read_text())
    write_json(out_dir / "config_frozen.json", cfg)
    write_json(
        out_dir / "manifest.json",
        {
            "config_path": str(cfg_path),
            "config_hash": stable_hash(cfg),
            "python": sys.version,
            "platform": platform.platform(),
            "tabarena_repo_git": git_rev(Path(args.tabarena_repo)) if args.tabarena_repo else "unknown",
            "cwd_git": git_rev(Path.cwd()),
            "tabarena_cache": os.environ.get("TABARENA_CACHE"),
        },
    )

    context = import_context(cfg.get("context", "neurips2025"))
    df = context.load_model_results(download_results="auto")
    candidate_col = choose_candidate_col(df)
    df = attach_metadata(df, context)
    df[candidate_col] = df[candidate_col].astype(str)
    df = normalize_reference(df)
    tasks = subset_tasks(df, cfg)

    selected_methods = [str(x) for x in cfg["repo_methods"]]
    ensure_processed_artifacts(context, selected_methods)
    repo, loaded_methods = load_prediction_repo(context, selected_methods)
    available_configs = set(repo.configs())

    rows: list[dict[str, Any]] = []
    weight_frames: list[pd.DataFrame] = []
    expert = str(cfg["expert_reference"])

    for task in tasks.itertuples(index=False):
        task_rows = df[(df["dataset"] == task.dataset) & (df["fold"] == task.fold)].copy()
        if task_rows.empty:
            continue

        default = pick_default(
            task_rows[match_patterns(task_rows[candidate_col], cfg["target_pool_patterns"])],
            candidate_col,
            cfg["default_priority_patterns"],
        )
        if default is not None:
            rows.append(scalar_row(task_rows, candidate_col, str(default[candidate_col]), "target_only_one_shot", 1, "default target rule"))

        expert_row = scalar_row(task_rows, candidate_col, expert, "expert_reference", 1, "declared official reference")
        if expert_row is not None:
            rows.append(expert_row)

        target_pool_rows = task_rows[match_patterns(task_rows[candidate_col], cfg["target_pool_patterns"])]
        target_configs = [c for c in best_by_val(target_pool_rows, candidate_col, int(cfg["target_top_k"])) if c in available_configs]
        if target_configs:
            try:
                row, weights = ensemble_row(repo, task.dataset, task.fold, target_configs, "target_only_self_improving", int(cfg["ensemble_size"]))
                rows.append(row)
                weight_frames.append(weights)
            except Exception as exc:
                rows.append({
                    "arm": "target_only_self_improving",
                    "dataset": task.dataset,
                    "fold": int(task.fold),
                    "candidate": ",".join(target_configs),
                    "candidate_type": "ensemble_failed",
                    "metric_error": np.nan,
                    "metric_error_val": np.nan,
                    "n_candidates_seen": len(target_configs),
                    "note": f"failed: {type(exc).__name__}: {exc}",
                })

        order = source_order(
            df=df,
            candidate_col=candidate_col,
            target_dataset=task.dataset,
            source_patterns=cfg["source_pool_patterns"],
            source_min_tasks=int(cfg["source_min_tasks"]),
        )
        source_configs = diversified_source_configs(order, candidate_col, cfg)
        if cfg.get("always_include_expert", True) and expert not in source_configs:
            source_configs = [expert] + source_configs
        source_configs = [c for c in source_configs if c in available_configs]

        if source_configs:
            one = scalar_row(task_rows, candidate_col, source_configs[0], "source_informed_one_shot", 1, "best source-ranked rule")
            if one is not None:
                rows.append(one)
            try:
                row, weights = ensemble_row(repo, task.dataset, task.fold, source_configs, "source_informed_self_improving", int(cfg["ensemble_size"]))
                rows.append(row)
                weight_frames.append(weights)
            except Exception as exc:
                rows.append({
                    "arm": "source_informed_self_improving",
                    "dataset": task.dataset,
                    "fold": int(task.fold),
                    "candidate": ",".join(source_configs),
                    "candidate_type": "ensemble_failed",
                    "metric_error": np.nan,
                    "metric_error_val": np.nan,
                    "n_candidates_seen": len(source_configs),
                    "note": f"failed: {type(exc).__name__}: {exc}",
                })

    selections = pd.DataFrame(rows)
    selections = selections.dropna(subset=["metric_error"])
    selections = add_reference_norm(selections, df)
    selections.to_csv(out_dir / "prediction_level_selections.csv", index=False)
    weights = pd.concat(weight_frames, ignore_index=True) if weight_frames else pd.DataFrame()
    weights.to_csv(out_dir / "prediction_level_weights.csv", index=False)
    summary = summarize(selections)
    summary.to_csv(out_dir / "prediction_level_summary.csv", index=False)
    boot = cluster_bootstrap(
        selections,
        reps=int(cfg.get("bootstrap_reps", 300)),
        seed=int(cfg.get("bootstrap_seed", 0)),
        reference_arm="source_informed_self_improving",
    )
    boot.to_csv(out_dir / "prediction_level_bootstrap_ci.csv", index=False)
    write_json(
        out_dir / "task_summary.json",
        {
            "candidate_col": candidate_col,
            "n_reference_rows": int(len(df)),
            "n_eval_task_folds": int(len(tasks)),
            "n_datasets": int(tasks["dataset"].nunique()),
            "repo_methods": selected_methods,
            "loaded_prediction_methods": loaded_methods,
            "n_repo_configs": int(len(available_configs)),
        },
    )

    with (out_dir / "prediction_level_summary.md").open("w") as fh:
        fh.write(f"# {cfg['experiment_name']}\n\n")
        fh.write("## Task Summary\n\n")
        fh.write(markdown_table(pd.DataFrame([json.loads((out_dir / "task_summary.json").read_text())])))
        fh.write("\n\n## Arms\n\n")
        fh.write(markdown_table(summary))
        fh.write("\n\n## Bootstrap\n\n")
        fh.write(markdown_table(boot))
        fh.write("\n")

    print(markdown_table(summary))
    print(f"Wrote prediction-level results to {out_dir}")


if __name__ == "__main__":
    main()

START HERE

Please run:

  ./RUN_TABARENA_FINAL.command

Optional quick package check:

  ./RUN_PACKAGE_SELF_CHECK.command

When the run finishes, send back the generated file:

  tabarena_prediction_level_type_aware_gated_*_return_to_authors.zip

This package runs the current TabArena prediction-level protocol used in the
manuscript. It uses type-aware source-task transfer, a larger source-informed
regression candidate pool, prediction-level ensembling, and a validation gate:
the source-informed ensemble is accepted only when target validation favors it
over the target-only ensemble. The return archive includes the primary
type-balanced dataset-rank summary, including the one-sided 90% lower bound for
the directional expert contrast.

The run may download about 40GB of TabArena processed prediction artifacts if
they are not already cached. It does not train raw models from scratch. The
package pins the AutoGluon prerelease required by the frozen TabArena commit to
avoid resolver drift.

For details, see plan.md.

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
python3 -m py_compile \
  scripts/run_tabarena_prediction_level_experiment.py \
  scripts/analyze_tabarena_internal_elo.py \
  scripts/analyze_tabarena_by_type.py \
  scripts/summarize_gated_tabarena_result.py
python3 -m json.tool configs/prediction_type_aware_xlarge_regression_transfer.json >/dev/null
python3 - <<'PY'
import hashlib
import json
from pathlib import Path
cfg = json.loads(Path("configs/prediction_type_aware_xlarge_regression_transfer.json").read_text())
h = hashlib.sha256(json.dumps(cfg, sort_keys=True, default=str).encode()).hexdigest()[:16]
print("config_hash", h)
assert h == "3ff1722b43852eec", h
assert cfg["experiment_name"] == "tabarena_prediction_level_type_aware_xlarge_regression_transfer"
assert cfg["source_order_mode"] == "similarity_weighted"
assert cfg["source_restrict_problem_type"] is True
assert cfg["emit_validation_gated_source_arm"] is True
assert cfg["emit_safeguarded_source_expert_arm"] is True
assert cfg["bootstrap_reference_arm"] == "source_informed_safeguarded_self_improving"
assert cfg["target_top_k_by_problem_type"]["regression"] == 48
assert cfg["source_top_k_by_problem_type"]["regression"] == 576
for path in [
    "RUN_TABARENA_FINAL.command",
    "RUN_TABARENA_FINAL.sh",
    "requirements_tabarena_prediction_level.txt",
    "scripts/run_tabarena_prediction_level_experiment.py",
    "scripts/analyze_tabarena_internal_elo.py",
    "scripts/analyze_tabarena_by_type.py",
    "scripts/summarize_gated_tabarena_result.py",
]:
    assert Path(path).exists(), path
print("package_self_check_ok")
PY

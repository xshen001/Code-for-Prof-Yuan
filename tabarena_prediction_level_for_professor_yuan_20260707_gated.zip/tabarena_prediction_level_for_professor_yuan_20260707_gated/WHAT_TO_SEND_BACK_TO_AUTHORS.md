# What To Send Back

Please send back the generated archive:

```text
tabarena_prediction_level_type_aware_gated_*_return_to_authors.zip
```

The archive should include:

- `prediction_level_summary.csv`
- `prediction_level_summary.md`
- `prediction_level_selections.csv`
- `prediction_level_weights.csv`
- `prediction_level_bootstrap_ci.csv`
- `prediction_level_dataset_bootstrap_ci.csv`
- `internal_elo_analysis/internal_tabarena_style_elo_dataset.csv`
- `internal_elo_analysis/internal_tabarena_style_dataset_bootstrap.csv`
- `internal_elo_analysis/internal_tabarena_style_summary.md`
- `type_stratified_analysis/gated_source_final_summary.csv`
- `type_stratified_analysis/gated_source_final_summary.md`
- `type_stratified_analysis/dataset_level_ranks.csv`
- `type_stratified_analysis/dataset_rank_bootstrap_draws.csv`
- `config_frozen.json`
- `manifest.json`
- `task_summary.json`
- `evaluator_run_status.json`
- `run_terminal.log`
- submitted config and scripts

If the package fails before creating a return zip, please send the terminal
output or the `results/.../run_terminal.log` file.

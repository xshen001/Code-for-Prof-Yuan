# Plan: Independent TabArena Type-Aware Gated-Transfer Rerun

## Purpose

Run the final TabArena prediction-level evaluation package independently. The
authors will use the returned files to check the current validation-gated
source-informed result: whether the source-informed self-improving arm exceeds
target-only self-improvement and the declared expert benchmark on the primary
type-balanced dataset-level rank metric.

## What To Run

From this folder, run:

```bash
./RUN_TABARENA_FINAL.command
```

Optional package check:

```bash
./RUN_PACKAGE_SELF_CHECK.command
```

The optional check validates syntax, file presence, and the frozen config hash.
It does not run the benchmark.

## What The Package Does

The final run uses:

- TabArena context: `neurips2025`.
- Candidate families: `AutoGluon_v130`, `CatBoost`, `LightGBM`, `XGBoost`,
  `RealMLP`, and `TabPFNv2_GPU`.
- Declared expert reference: `AutoGluon_v130_bq_4h8c`.
- Type-aware source-transfer rule:
  - source tasks are restricted to the same problem type: binary
    classification, multiclass classification, or regression;
  - source-task ranking is similarity-weighted;
  - the source-informed candidate set includes top target-validation winners;
  - regression receives a larger source-informed candidate pool;
  - prediction-level ensembling is used;
  - a validation gate accepts the source-informed ensemble only when target
    validation favors it over the target-only ensemble.

Held-out test errors are not used to choose the frozen arm outputs.

## Primary Returned Analysis

The package writes `type_stratified_analysis/gated_source_final_summary.csv`.
The primary statistic is:

1. average folds within each dataset and arm;
2. rank the seven arms within each dataset, with rank 1 best;
3. average rank gains within binary, multiclass, and regression tasks;
4. weight the three task types equally.

Positive rank gain means that the validation-gated source-informed arm has a
better, lower average rank than the comparator. The file also reports the
one-sided 90% lower confidence bound and a paired sign-flip one-sided p-value
for the pre-specified directional expert contrast.

## Outputs

The command creates a return archive named:

```text
tabarena_prediction_level_type_aware_gated_*_return_to_authors.zip
```

Please send that zip file back to the authors. It should contain:

- `prediction_level_summary.csv`
- `prediction_level_summary.md`
- `prediction_level_selections.csv`
- `prediction_level_weights.csv`
- `prediction_level_bootstrap_ci.csv`
- `prediction_level_dataset_bootstrap_ci.csv`
- `internal_elo_analysis/internal_tabarena_style_elo_dataset.csv`
- `internal_elo_analysis/internal_tabarena_style_dataset_bootstrap.csv`
- `internal_elo_analysis/internal_tabarena_style_summary.md`
- `type_stratified_analysis/gated_source_final_summary.csv`
- `type_stratified_analysis/gated_source_final_summary.md`
- `type_stratified_analysis/dataset_level_ranks.csv`
- `type_stratified_analysis/dataset_rank_bootstrap_draws.csv`
- `config_frozen.json`
- `manifest.json`
- `task_summary.json`
- submitted scripts and terminal log

## Environment Notes

The run may download about 40GB of processed TabArena prediction artifacts if
they are not already cached. It does not train raw models from scratch.

The package pins a TabArena Git commit inside `RUN_TABARENA_FINAL.sh` and
installs the Python dependencies listed in
`requirements_tabarena_prediction_level.txt`. The AutoGluon tabular dependency
is pinned to the prerelease used by the frozen TabArena commit, because the
stable 1.5.0 build lacks symbols imported by that commit.

Frozen config hash:

```text
3ff1722b43852eec
```

If setup or execution fails, please send back the generated return archive or,
if no archive is created, the terminal output and `results/.../run_terminal.log`.

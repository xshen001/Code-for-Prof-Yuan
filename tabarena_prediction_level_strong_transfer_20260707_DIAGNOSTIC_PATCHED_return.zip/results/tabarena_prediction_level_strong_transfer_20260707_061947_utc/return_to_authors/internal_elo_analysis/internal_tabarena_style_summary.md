# Internal TabArena-style aggregate metrics

Internal Elo is fit from pairwise wins on TabArena native held-out errors using a Bradley--Terry model and then converted to the Elo scale. Only Elo differences are meaningful. The `internal_elo_expert1000` column sets the declared expert reference to 1000 for readability. This is not the official TabArena leaderboard Elo.

Main unit: `dataset`. Smaller native error is better.

## Point Estimates

| arm | bt_log_skill | internal_elo_mean1000 | internal_elo_expert1000 | elo_minus_expert | avg_rank | mean_native_error | win_rate_vs_expert | tie_rate_vs_expert | mean_error_minus_expert |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| source_informed_self_improving | 1.12793 | 1195.94 | 1045.09 | 45.0935 | 2.81373 | 1616.56 | 0.509804 | 0 | -40.1455 |
| source_informed_gated_self_improving | 1.10535 | 1192.02 | 1041.17 | 41.1706 | 2.84314 | 1616.56 | 0.509804 | 0 | -40.1461 |
| source_informed_safeguarded_self_improving | 1.08285 | 1188.11 | 1037.26 | 37.2611 | 2.87255 | 1616.54 | 0.509804 | 0 | -40.1621 |
| expert_reference | 0.868355 | 1150.85 | 1000 | 0 | 3.15686 | 1656.7 | 0 | 1 | 0 |
| target_only_self_improving | 0.204738 | 1035.57 | 884.718 | -115.282 | 4.03922 | 1650.33 | 0.352941 | 0 | -6.37361 |
| source_informed_one_shot | -1.07798 | 812.736 | 661.887 | -338.113 | 5.45098 | 1651.62 | 0.235294 | 0 | -5.08759 |
| target_only_one_shot | -3.31125 | 424.777 | 273.929 | -726.071 | 6.82353 | 1795.1 | 0.0392157 | 0 | 138.392 |

## Dataset-Level Bootstrap Contrasts

| contrast | elo_minus_expert_mean | elo_minus_expert_ci_low | elo_minus_expert_ci_high | rank_gain_mean | rank_gain_ci_low | rank_gain_ci_high | error_gain_mean | error_gain_ci_low | error_gain_ci_high | win_rate_mean | win_rate_ci_low | win_rate_ci_high |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| source_informed_gated_self_improving - expert_reference | 40.35 | -64.411 | 142.292 | 0.308098 | -0.461029 | 1.07868 | 40.5365 | -2.49274 | 123.096 | 0.508804 | 0.372549 | 0.647059 |
| source_informed_safeguarded_self_improving - expert_reference | 37.3752 | -37.835 | 115.977 | 0.282799 | -0.284559 | 0.862745 | 40.5529 | -2.49598 | 123.095 | 0.509804 | 0.372549 | 0.647059 |
| source_informed_self_improving - expert_reference | 44.5165 | -59.4845 | 146.194 | 0.33873 | -0.421569 | 1.10784 | 40.536 | -2.49429 | 123.096 | 0.508804 | 0.372549 | 0.647059 |

# tabarena_prediction_level_strong_transfer

## Task Summary

| candidate_col | loaded_prediction_methods | n_datasets | n_eval_task_folds | n_reference_rows | n_repo_configs | repo_methods |
| --- | --- | --- | --- | --- | --- | --- |
| method | CatBoost, LightGBM, XGBoost, RealMLP, TabPFNv2_GPU | 51 | 816 | 2298132 | 1005 | AutoGluon_v130, CatBoost, LightGBM, XGBoost, RealMLP, TabPFNv2_GPU |

## Arms

| arm | n_task_folds | n_datasets | mean_metric_error | mean_metric_error_val | mean_loss_norm | median_loss_norm |
| --- | --- | --- | --- | --- | --- | --- |
| source_informed_self_improving | 816 | 51 | 1044.97 | 1036.03 | 0.0294031 | 0.011145 |
| source_informed_gated_self_improving | 816 | 51 | 1044.97 | 1036.03 | 0.0294561 | 0.0111423 |
| source_informed_safeguarded_self_improving | 816 | 51 | 1044.97 |  | 0.0298569 | 0.0122641 |
| expert_reference | 816 | 51 | 1066.46 |  | 0.0317944 | 0.0142701 |
| target_only_self_improving | 816 | 51 | 1064.06 | 1077.99 | 0.0326772 | 0.0122151 |
| source_informed_one_shot | 816 | 51 | 1065.97 | 1089.98 | 0.0397834 | 0.0160555 |
| target_only_one_shot | 816 | 51 | 1147.84 | 1194.13 | 0.0626616 | 0.0333664 |

## Bootstrap

| contrast | mean | ci_low | ci_high |
| --- | --- | --- | --- |
| expert_reference | 0.0317603 | 0.0289022 | 0.0345104 |
| expert_reference - source_informed_safeguarded_self_improving | 0.0019291 | 0.000411763 | 0.00365514 |
| source_informed_gated_self_improving | 0.029424 | 0.026562 | 0.0323351 |
| source_informed_gated_self_improving - source_informed_safeguarded_self_improving | -0.000407166 | -0.000992616 | 7.73727e-05 |
| source_informed_one_shot | 0.0397519 | 0.036009 | 0.0431744 |
| source_informed_one_shot - source_informed_safeguarded_self_improving | 0.00992076 | 0.00829676 | 0.0113448 |
| source_informed_safeguarded_self_improving | 0.0298312 | 0.0269933 | 0.0326084 |
| source_informed_self_improving | 0.0293699 | 0.0264861 | 0.0322435 |
| source_informed_self_improving - source_informed_safeguarded_self_improving | -0.000461272 | -0.0010355 | 1.06134e-05 |
| target_only_one_shot | 0.0625846 | 0.0580287 | 0.0669757 |
| target_only_one_shot - source_informed_safeguarded_self_improving | 0.0327534 | 0.0296762 | 0.0356192 |
| target_only_self_improving | 0.0326433 | 0.0295195 | 0.0356114 |
| target_only_self_improving - source_informed_safeguarded_self_improving | 0.00281219 | 0.0020357 | 0.00363037 |

## Dataset-Level Bootstrap

| contrast | n_datasets | mean | se | ci_low | ci_high | win_dataset_fraction | max_dataset_difference | min_dataset_difference |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| source_informed_self_improving - source_informed_safeguarded_self_improving | 51 | -0.000305134 | 0.000359106 | -0.00103852 | 0.000334669 | 0.254902 | 0.00413222 | -0.00978856 |
| source_informed_gated_self_improving - source_informed_safeguarded_self_improving | 51 | -0.000276861 | 0.00036483 | -0.00102383 | 0.00038459 | 0.294118 | 0.00443394 | -0.00978856 |
| expert_reference - source_informed_safeguarded_self_improving | 51 | 0.00199448 | 0.00154763 | -0.000949994 | 0.00502847 | 0.490196 | 0.0443542 | -0.0385372 |
| target_only_self_improving - source_informed_safeguarded_self_improving | 51 | 0.00301551 | 0.000816391 | 0.00150787 | 0.00466465 | 0.27451 | 0.0251313 | -0.00693055 |
| source_informed_one_shot - source_informed_safeguarded_self_improving | 51 | 0.00872789 | 0.00157196 | 0.00581175 | 0.01194 | 0.137255 | 0.0436191 | -0.00419363 |
| target_only_one_shot - source_informed_safeguarded_self_improving | 51 | 0.0300482 | 0.00486893 | 0.0211324 | 0.0403419 | 0.0196078 | 0.145629 | -0.00174438 |
